import { i18n as Hn, useCmsData as Gn, toast as Ke, withStorageBatch as Kn, uploadFile as vt, fileToBase64 as Zn, getCurrentPublishContext as Xn, basePathFromBaseUrl as Yn } from "@agent-cms/runtime";
import { jsxs as j, jsx as E } from "react/jsx-runtime";
import { useState as Ne, useEffect as it, useRef as Qn } from "react";
import { useTranslation as Xt } from "react-i18next";
const _n = '# Agent3D scene — AgentCMS plugin\n\nEmbed 3D scenes made with [Agent3D](https://github.com/fleox/agent3d) (animated banners, heroes, characters, landscapes, product showcases, mini games) in AgentCMS posts and pages.\n\n- **Settings → Agent3D scenes** uploads an Agent3D export folder (`dist/embed`, written by `agent3d export`) to `agent3d/` on the site\'s hosting and lists the scenes it contains.\n- The **Agent3D scene** editor block ("+" or `/`, category Embed) picks an uploaded scene or takes the URL of any `scene.json`, with an accessible label and an optional caption. The editor shows the poster and can play the live scene.\n- Published pages get the `<agent3d-scene>` Web Component and the runtime module script: no third-party request, lazy start, pause off-screen, reduced-motion support, poster fallback without WebGL. Sites hosted in a sub-folder are handled.\n\n## Install\n\n1. Get `agent3d-scene.zip` (in `integrations/agentcms/` of the Agent3D repository, or build it: `npm install && npm run build`).\n2. In the AgentCMS admin: **Plugins → Install**, drop the ZIP. Or, for a site the AgentCMS CLI manages:\n   ```bash\n   npx -y @agent-cms/agentcms@0.3.13 ext install agent3d-scene.zip --site <alias> --json          # plan\n   npx -y @agent-cms/agentcms@0.3.13 ext install agent3d-scene.zip --site <alias> --yes --json    # install\n   ```\n3. Reload the admin.\n\n## Use\n\n1. Make a scene with Agent3D and export it: `npx -y @fleox/agent3d@0.2.0 export --project my-banner --json` → `my-banner/dist/embed/`.\n2. **Settings → Agent3D scenes** → pick that `embed` folder. Every file except the demo page is uploaded to `agent3d/` (the runtime once, then one folder per scene).\n3. In a post or page, insert **Agent3D scene**, choose the scene in the Block tab, write the accessible label, publish.\n\nAlready uploaded the export some other way (git, bucket)? Paste its `scene.json` URL in the block (e.g. `/assets/3d/my-banner/scene.json`); the poster and runtime URLs default to the export layout (`poster.webp` next to `scene.json`, `../agent3d-runtime/agent3d-runtime.js`) and can be overridden.\n\n## Published HTML\n\n```html\n<figure class="agent3d-scene-block">\n  <script type="module" src="/agent3d/agent3d-runtime/agent3d-runtime.js"><\/script>\n  <agent3d-scene src="/agent3d/my-banner/scene.json" aspect="4:1" role="img" aria-label="…" style="display:block;width:100%;aspect-ratio:4 / 1">\n    <img slot="poster" src="/agent3d/my-banner/poster.webp" alt="…" decoding="async">\n  </agent3d-scene>\n  <figcaption>…</figcaption>\n</figure>\n```\n\nThe poster is real markup (visible before the runtime loads, indexable) and the aspect ratio is reserved up front, so the page does not jump when the scene starts. Uploaded scenes get their aspect from `target.aspect` in their `scene.json`; for a pasted URL, set it in the block\'s **Aspect ratio** field. Exports made with `--cache-bust` (`agent3d-runtime-<hash>/`) are detected too; `EMBED.md`, `head.html` and the `frameworks/` wrappers stay local.\n\nSeveral blocks on a page share the runtime (browsers run a module URL once). Content-Security-Policy, if the site sets one: `script-src \'self\'`, `connect-src \'self\'`, `img-src \'self\' blob:` (+ `style-src \'unsafe-inline\'` for scenes with a HUD, and `script-src \'wasm-unsafe-eval\'` only for scenes exported with meshopt-compressed models, `export --optimize`).\n\n## Develop\n\n```bash\nnpm install\nnpm run build        # tsc + vite build + pack → agent3d-scene.zip\nnpm run check        # validates the package like the admin, renders a demo site\nnpm run preview      # demo site + screenshots\n```\n\nSource: `src/render.ts` (attributes, URL safety, published HTML), `src/scene-block.tsx` (Tiptap node, node view, inspector), `src/settings.tsx` (folder upload), `src/manifest.tsx`.\n', er = {
  en: {
    block: {
      title: "Agent3D scene",
      noScene: "No scene selected",
      prompt: "URL of the scene.json (or keep the sample and pick an uploaded scene in the Block tab)",
      play: "Play preview",
      uploaded: "Uploaded scene",
      custom: "Custom URL…",
      src: "Scene URL (scene.json)",
      label: "Accessible label",
      labelPlaceholder: "One sentence describing the scene",
      caption: "Caption",
      aspect: "Aspect ratio (W:H)",
      poster: "Poster image URL",
      runtime: "Runtime URL",
      help: "Export the scene with `agent3d export` and upload the folder in Settings → Agent3D scenes, or paste the URL of a scene.json already on this site. Poster and runtime default to the export layout."
    },
    settings: {
      navLabel: "Agent3D scenes",
      intro: "Upload the folder written by `agent3d export` (dist/embed of the project). Its files go to the folder below on this site's hosting; the scenes it contains become available in the Agent3D scene block.",
      folder: "Upload folder on the site",
      pick: "Agent3D export folder",
      uploading: "Uploading {{done}} / {{total}}…",
      done: "{{count}} scene(s) uploaded ({{files}} files).",
      failed: "Upload failed:",
      noScene: "No <name>/scene.json in this folder: pick the export folder itself (dist/embed).",
      scenes: "Uploaded scenes",
      empty: "No scene uploaded yet.",
      forget: "Forget",
      regenerate: "Re-uploading a scene updates published pages immediately. After changing the folder, regenerate the pages that use the block (Regenerate → All HTML pages)."
    }
  },
  fr: {
    block: {
      title: "Scène Agent3D",
      noScene: "Aucune scène choisie",
      prompt: "URL du scene.json (ou gardez l'exemple et choisissez une scène envoyée dans l'onglet Bloc)",
      play: "Lire l'aperçu",
      uploaded: "Scène envoyée",
      custom: "URL personnalisée…",
      src: "URL de la scène (scene.json)",
      label: "Libellé accessible",
      labelPlaceholder: "Une phrase qui décrit la scène",
      caption: "Légende",
      aspect: "Format (L:H)",
      poster: "URL de l'image d'attente",
      runtime: "URL du runtime",
      help: "Exportez la scène avec `agent3d export` et envoyez le dossier dans Réglages → Scènes Agent3D, ou collez l'URL d'un scene.json déjà présent sur le site. L'image d'attente et le runtime suivent par défaut la structure de l'export."
    },
    settings: {
      navLabel: "Scènes Agent3D",
      intro: "Envoyez le dossier écrit par `agent3d export` (dist/embed du projet). Ses fichiers sont copiés dans le dossier ci-dessous sur l'hébergement du site ; ses scènes deviennent disponibles dans le bloc Scène Agent3D.",
      folder: "Dossier d'envoi sur le site",
      pick: "Dossier d'export Agent3D",
      uploading: "Envoi {{done}} / {{total}}…",
      done: "{{count}} scène(s) envoyée(s) ({{files}} fichiers).",
      failed: "Échec de l'envoi :",
      noScene: "Aucun <nom>/scene.json dans ce dossier : choisissez le dossier d'export lui-même (dist/embed).",
      scenes: "Scènes envoyées",
      empty: "Aucune scène envoyée pour l'instant.",
      forget: "Oublier",
      regenerate: "Renvoyer une scène met à jour les pages publiées immédiatement. Après un changement de dossier, régénérez les pages qui utilisent le bloc (Régénérer → Toutes les pages HTML)."
    }
  }
}, ce = "agent3d-scene", st = "agent3d-scene/scene", de = "agent3dSceneScene", tr = "agent3d", Be = { folder: tr, scenes: [] }, le = { src: "", poster: "", runtime: "", label: "", caption: "", aspect: "" };
function nr(r) {
  const e = new TextEncoder().encode(JSON.stringify(r));
  let t = "";
  for (const n of e) t += String.fromCharCode(n);
  return btoa(t);
}
function Yt(r) {
  if (!r) return { ...le };
  try {
    const e = new TextDecoder().decode(Uint8Array.from(atob(r), (n) => n.charCodeAt(0))), t = JSON.parse(e);
    return {
      src: String(t.src ?? ""),
      poster: String(t.poster ?? ""),
      runtime: String(t.runtime ?? ""),
      label: String(t.label ?? ""),
      caption: String(t.caption ?? ""),
      aspect: String(t.aspect ?? "")
    };
  } catch {
    return { ...le };
  }
}
function U(r) {
  return r.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Ze(r) {
  const e = r.trim();
  return e && (/^https:\/\/[^\s"'<>]+$/i.test(e) || /^(\/(?!\/)|\.\.?\/)[^\s"'<>:]*$/.test(e) || /^[A-Za-z0-9_-][^\s"'<>:]*$/.test(e)) ? e : "";
}
function qe(r) {
  const e = /^\s*(\d+(?:\.\d+)?)\s*[:/x]\s*(\d+(?:\.\d+)?)\s*$/.exec(r ?? "");
  return e && Number(e[1]) > 0 && Number(e[2]) > 0 ? `${e[1]}:${e[2]}` : "";
}
function rr(r) {
  var e;
  try {
    const t = JSON.parse(r);
    return typeof ((e = t.target) == null ? void 0 : e.aspect) == "string" ? qe(t.target.aspect) : "";
  } catch {
    return "";
  }
}
function ir(r) {
  return r.replace(/[^/]*$/, "");
}
function sr(r) {
  const e = /^(.*\/)[^/]+\/$/.exec(r);
  return e && !/(^|\/)\.\.?\/$/.test(r) ? e[1] : `${r}../`;
}
function Ce(r) {
  const e = Ze(r.src), t = e ? ir(e) : "";
  return {
    ...r,
    src: e,
    poster: Ze(r.poster) || (t ? `${t}poster.webp` : ""),
    runtime: Ze(r.runtime) || (t ? `${sr(t)}agent3d-runtime/agent3d-runtime.js` : "")
  };
}
function Xe(r, e) {
  if (!e || !r.startsWith("/") || r.startsWith("//")) return r;
  const t = e.replace(/\/+$/, "");
  return r === t || r.startsWith(t + "/") ? r : t + r;
}
function or(r, e = "") {
  const t = Ce(r);
  if (!t.src) return "";
  const n = U(Xe(t.src, e)), i = U(t.label.trim() || "3D scene"), s = qe(t.aspect), o = s ? `;aspect-ratio:${s.replace(":", " / ")}` : "", l = s ? ` aspect="${s}"` : "", a = t.poster ? `<img slot="poster" src="${U(Xe(t.poster, e))}" alt="${i}" decoding="async" style="display:block;width:100%;height:100%;object-fit:cover">` : "", c = t.caption.trim() ? `<figcaption style="margin-top:.5rem;font-size:.875em;opacity:.75;text-align:center">${U(t.caption.trim())}</figcaption>` : "";
  return `<figure class="agent3d-scene-block" style="margin:1.5rem 0">${t.runtime ? `<script type="module" src="${U(Xe(t.runtime, e))}"><\/script>` : ""}<agent3d-scene src="${n}"${l} role="img" aria-label="${i}" style="display:block;width:100%${o}">${a}</agent3d-scene>${c}</figure>`;
}
const lr = /<div\s+([^>]*data-cms-block="agent3d-scene\/scene"[^>]*)>\s*<\/div>/g;
function ar(r, e = "") {
  return r.replace(lr, (t, n) => {
    var i;
    return or(Yt((i = /data-attrs="([^"]*)"/.exec(n)) == null ? void 0 : i[1]), e);
  });
}
const Ct = /^agent3d-runtime(?:-[A-Za-z0-9]+)?$/;
function cr(r, e, t = {}) {
  const n = `/${e.replace(/^\/+|\/+$/g, "")}`, i = r.map((s) => {
    var o;
    return (o = /^([^/]+)\/agent3d-runtime\.js$/.exec(s)) == null ? void 0 : o[1];
  }).find((s) => !!s && Ct.test(s));
  return r.map((s) => {
    var o;
    return (o = /^([^/]+)\/scene\.json$/.exec(s)) == null ? void 0 : o[1];
  }).filter((s) => !!s && !Ct.test(s)).map((s) => {
    const o = {
      name: s,
      src: `${n}/${s}/scene.json`,
      poster: r.includes(`${s}/poster.webp`) ? `${n}/${s}/poster.webp` : "",
      runtime: i ? `${n}/${i}/agent3d-runtime.js` : "",
      label: ""
    }, l = qe(t[s]);
    return l && (o.aspect = l), o;
  });
}
function fr(r) {
  const e = r.split("/");
  return e.length > 1 ? e.slice(1).join("/") : r;
}
const ur = /* @__PURE__ */ new Set(["index.html", "snippet.html", "head.html", "EMBED.md"]);
function hr(r) {
  return !r || r.split("/").some((e) => e.startsWith(".") || e === "..") ? !1 : !ur.has(r) && !r.startsWith("frameworks/");
}
function N(r) {
  this.content = r;
}
N.prototype = {
  constructor: N,
  find: function(r) {
    for (var e = 0; e < this.content.length; e += 2)
      if (this.content[e] === r) return e;
    return -1;
  },
  // :: (string) → ?any
  // Retrieve the value stored under `key`, or return undefined when
  // no such key exists.
  get: function(r) {
    var e = this.find(r);
    return e == -1 ? void 0 : this.content[e + 1];
  },
  // :: (string, any, ?string) → OrderedMap
  // Create a new map by replacing the value of `key` with a new
  // value, or adding a binding to the end of the map. If `newKey` is
  // given, the key of the binding will be replaced with that key.
  update: function(r, e, t) {
    var n = t && t != r ? this.remove(t) : this, i = n.find(r), s = n.content.slice();
    return i == -1 ? s.push(t || r, e) : (s[i + 1] = e, t && (s[i] = t)), new N(s);
  },
  // :: (string) → OrderedMap
  // Return a map with the given key removed, if it existed.
  remove: function(r) {
    var e = this.find(r);
    if (e == -1) return this;
    var t = this.content.slice();
    return t.splice(e, 2), new N(t);
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the start of the map.
  addToStart: function(r, e) {
    return new N([r, e].concat(this.remove(r).content));
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the end of the map.
  addToEnd: function(r, e) {
    var t = this.remove(r).content.slice();
    return t.push(r, e), new N(t);
  },
  // :: (string, string, any) → OrderedMap
  // Add a key after the given key. If `place` is not found, the new
  // key is added to the end.
  addBefore: function(r, e, t) {
    var n = this.remove(e), i = n.content.slice(), s = n.find(r);
    return i.splice(s == -1 ? i.length : s, 0, e, t), new N(i);
  },
  // :: ((key: string, value: any))
  // Call the given function for each key/value pair in the map, in
  // order.
  forEach: function(r) {
    for (var e = 0; e < this.content.length; e += 2)
      r(this.content[e], this.content[e + 1]);
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by prepending the keys in this map that don't
  // appear in `map` before the keys in `map`.
  prepend: function(r) {
    return r = N.from(r), r.size ? new N(r.content.concat(this.subtract(r).content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by appending the keys in this map that don't
  // appear in `map` after the keys in `map`.
  append: function(r) {
    return r = N.from(r), r.size ? new N(this.subtract(r).content.concat(r.content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a map containing all the keys in this map that don't
  // appear in `map`.
  subtract: function(r) {
    var e = this;
    r = N.from(r);
    for (var t = 0; t < r.content.length; t += 2)
      e = e.remove(r.content[t]);
    return e;
  },
  // :: () → Object
  // Turn ordered map into a plain object.
  toObject: function() {
    var r = {};
    return this.forEach(function(e, t) {
      r[e] = t;
    }), r;
  },
  // :: number
  // The amount of keys in this map.
  get size() {
    return this.content.length >> 1;
  }
};
N.from = function(r) {
  if (r instanceof N) return r;
  var e = [];
  if (r) for (var t in r) e.push(t, r[t]);
  return new N(e);
};
function Qt(r, e, t) {
  for (let n = 0; ; n++) {
    if (n == r.childCount || n == e.childCount)
      return r.childCount == e.childCount ? null : t;
    let i = r.child(n), s = e.child(n);
    if (i == s) {
      t += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(s))
      return t;
    if (i.isText && i.text != s.text) {
      let o = i.text, l = s.text, a = 0;
      for (; o[a] == l[a]; a++)
        t++;
      return a && a < o.length && a < l.length && tn(o.charCodeAt(a - 1)) && en(o.charCodeAt(a)) && t--, t;
    }
    if (i.content.size || s.content.size) {
      let o = Qt(i.content, s.content, t + 1);
      if (o != null)
        return o;
    }
    t += i.nodeSize;
  }
}
function _t(r, e, t, n) {
  for (let i = r.childCount, s = e.childCount; ; ) {
    if (i == 0 || s == 0)
      return i == s ? null : { a: t, b: n };
    let o = r.child(--i), l = e.child(--s), a = o.nodeSize;
    if (o == l) {
      t -= a, n -= a;
      continue;
    }
    if (!o.sameMarkup(l))
      return { a: t, b: n };
    if (o.isText && o.text != l.text) {
      let c = o.text, f = l.text, u = c.length, d = f.length;
      for (; u > 0 && d > 0 && c[u - 1] == f[d - 1]; )
        u--, d--, t--, n--;
      return u && d && u < c.length && tn(c.charCodeAt(u - 1)) && en(c.charCodeAt(u)) && (t++, n++), { a: t, b: n };
    }
    if (o.content.size || l.content.size) {
      let c = _t(o.content, l.content, t - 1, n - 1);
      if (c)
        return c;
    }
    t -= a, n -= a;
  }
}
function en(r) {
  return r >= 56320 && r < 57344;
}
function tn(r) {
  return r >= 55296 && r < 56320;
}
class y {
  /**
  @internal
  */
  constructor(e, t) {
    if (this.content = e, this.size = t || 0, t == null)
      for (let n = 0; n < e.length; n++)
        this.size += e[n].nodeSize;
  }
  /**
  Invoke a callback for all descendant nodes between the given two
  positions (relative to start of this fragment). Doesn't descend
  into a node when the callback returns `false`.
  */
  nodesBetween(e, t, n, i = 0, s) {
    for (let o = 0, l = 0; l < t; o++) {
      let a = this.content[o], c = l + a.nodeSize;
      if (c > e && n(a, i + l, s || null, o) !== !1 && a.content.size) {
        let f = l + 1;
        a.nodesBetween(Math.max(0, e - f), Math.min(a.content.size, t - f), n, i + f);
      }
      l = c;
    }
  }
  /**
  Call the given callback for every descendant node. `pos` will be
  relative to the start of the fragment. The callback may return
  `false` to prevent traversal of a given node's children.
  */
  descendants(e) {
    this.nodesBetween(0, this.size, e);
  }
  /**
  Extract the text between `from` and `to`. See the same method on
  [`Node`](https://prosemirror.net/docs/ref/#model.Node.textBetween).
  */
  textBetween(e, t, n, i) {
    let s = "", o = !0;
    return this.nodesBetween(e, t, (l, a) => {
      let c = l.isText ? l.text.slice(Math.max(e, a) - a, t - a) : l.isLeaf ? i ? typeof i == "function" ? i(l) : i : l.type.spec.leafText ? l.type.spec.leafText(l) : "" : "";
      l.isBlock && (l.isLeaf && c || l.isTextblock) && n && (o ? o = !1 : s += n), s += c;
    }, 0), s;
  }
  /**
  Create a new fragment containing the combined content of this
  fragment and the other.
  */
  append(e) {
    if (!e.size)
      return this;
    if (!this.size)
      return e;
    let t = this.lastChild, n = e.firstChild, i = this.content.slice(), s = 0;
    for (t.isText && t.sameMarkup(n) && (i[i.length - 1] = t.withText(t.text + n.text), s = 1); s < e.content.length; s++)
      i.push(e.content[s]);
    return new y(i, this.size + e.size);
  }
  /**
  Cut out the sub-fragment between the two given positions.
  */
  cut(e, t = this.size) {
    if (e == 0 && t == this.size)
      return this;
    let n = [], i = 0;
    if (t > e)
      for (let s = 0, o = 0; o < t; s++) {
        let l = this.content[s], a = o + l.nodeSize;
        a > e && ((o < e || a > t) && (l.isText ? l = l.cut(Math.max(0, e - o), Math.min(l.text.length, t - o)) : l = l.cut(Math.max(0, e - o - 1), Math.min(l.content.size, t - o - 1))), n.push(l), i += l.nodeSize), o = a;
      }
    return new y(n, i);
  }
  /**
  @internal
  */
  cutByIndex(e, t) {
    return e == t ? y.empty : e == 0 && t == this.content.length ? this : new y(this.content.slice(e, t));
  }
  /**
  Create a new fragment in which the node at the given index is
  replaced by the given node.
  */
  replaceChild(e, t) {
    let n = this.content[e];
    if (n == t)
      return this;
    let i = this.content.slice(), s = this.size + t.nodeSize - n.nodeSize;
    return i[e] = t, new y(i, s);
  }
  /**
  Create a new fragment by prepending the given node to this
  fragment.
  */
  addToStart(e) {
    return new y([e].concat(this.content), this.size + e.nodeSize);
  }
  /**
  Create a new fragment by appending the given node to this
  fragment.
  */
  addToEnd(e) {
    return new y(this.content.concat(e), this.size + e.nodeSize);
  }
  /**
  Compare this fragment to another one.
  */
  eq(e) {
    if (this.content.length != e.content.length)
      return !1;
    for (let t = 0; t < this.content.length; t++)
      if (!this.content[t].eq(e.content[t]))
        return !1;
    return !0;
  }
  /**
  The first child of the fragment, or `null` if it is empty.
  */
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  /**
  The last child of the fragment, or `null` if it is empty.
  */
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  /**
  The number of child nodes in this fragment.
  */
  get childCount() {
    return this.content.length;
  }
  /**
  Get the child node at the given index. Raise an error when the
  index is out of range.
  */
  child(e) {
    let t = this.content[e];
    if (!t)
      throw new RangeError("Index " + e + " out of range for " + this);
    return t;
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content[e] || null;
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    for (let t = 0, n = 0; t < this.content.length; t++) {
      let i = this.content[t];
      e(i, n, t), n += i.nodeSize;
    }
  }
  /**
  Find the first position at which this fragment and another
  fragment differ, or `null` if they are the same.
  */
  findDiffStart(e, t = 0) {
    return Qt(this, e, t);
  }
  /**
  Find the first position, searching from the end, at which this
  fragment and the given fragment differ, or `null` if they are
  the same. Since this position will not be the same in both
  nodes, an object with two separate positions is returned.
  */
  findDiffEnd(e, t = this.size, n = e.size) {
    return _t(this, e, t, n);
  }
  /**
  Find the index and inner offset corresponding to a given relative
  position in this fragment. The result object will be reused
  (overwritten) the next time the function is called. @internal
  */
  findIndex(e) {
    if (e == 0)
      return Ae(0, e);
    if (e == this.size)
      return Ae(this.content.length, e);
    if (e > this.size || e < 0)
      throw new RangeError(`Position ${e} outside of fragment (${this})`);
    for (let t = 0, n = 0; ; t++) {
      let i = this.child(t), s = n + i.nodeSize;
      if (s >= e)
        return s == e ? Ae(t + 1, s) : Ae(t, n);
      n = s;
    }
  }
  /**
  Return a debugging string that describes this fragment.
  */
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  /**
  @internal
  */
  toStringInner() {
    return this.content.join(", ");
  }
  /**
  Create a JSON-serializeable representation of this fragment.
  */
  toJSON() {
    return this.content.length ? this.content.map((e) => e.toJSON()) : null;
  }
  /**
  Deserialize a fragment from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return y.empty;
    if (!Array.isArray(t))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return y.fromArray(t.map(e.nodeFromJSON));
  }
  /**
  Build a fragment from an array of nodes. Ensures that adjacent
  text nodes with the same marks are joined together.
  */
  static fromArray(e) {
    if (!e.length)
      return y.empty;
    let t, n = 0;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      n += s.nodeSize, i && s.isText && e[i - 1].sameMarkup(s) ? (t || (t = e.slice(0, i)), t[t.length - 1] = s.withText(t[t.length - 1].text + s.text)) : t && t.push(s);
    }
    return new y(t || e, n);
  }
  /**
  Create a fragment from something that can be interpreted as a
  set of nodes. For `null`, it returns the empty fragment. For a
  fragment, the fragment itself. For a node or array of nodes, a
  fragment containing those nodes.
  */
  static from(e) {
    if (!e)
      return y.empty;
    if (e instanceof y)
      return e;
    if (Array.isArray(e))
      return this.fromArray(e);
    if (e.attrs)
      return new y([e], e.nodeSize);
    throw new RangeError("Can not convert " + e + " to a Fragment" + (e.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
y.empty = new y([], 0);
const Ye = { index: 0, offset: 0 };
function Ae(r, e) {
  return Ye.index = r, Ye.offset = e, Ye;
}
function Fe(r, e) {
  if (r === e)
    return !0;
  if (!(r && typeof r == "object") || !(e && typeof e == "object"))
    return !1;
  let t = Array.isArray(r);
  if (Array.isArray(e) != t)
    return !1;
  if (t) {
    if (r.length != e.length)
      return !1;
    for (let n = 0; n < r.length; n++)
      if (!Fe(r[n], e[n]))
        return !1;
  } else {
    for (let n in r)
      if (!(n in e) || !Fe(r[n], e[n]))
        return !1;
    for (let n in e)
      if (!(n in r))
        return !1;
  }
  return !0;
}
class b {
  /**
  @internal
  */
  constructor(e, t) {
    this.type = e, this.attrs = t;
  }
  /**
  Given a set of marks, create a new set which contains this one as
  well, in the right position. If this mark is already in the set,
  the set itself is returned. If any marks that are set to be
  [exclusive](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) with this mark are present,
  those are replaced by this one.
  */
  addToSet(e) {
    let t, n = !1;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      if (this.eq(s))
        return e;
      if (this.type.excludes(s.type))
        t || (t = e.slice(0, i));
      else {
        if (s.type.excludes(this.type))
          return e;
        !n && s.type.rank > this.type.rank && (t || (t = e.slice(0, i)), t.push(this), n = !0), t && t.push(s);
      }
    }
    return t || (t = e.slice()), n || t.push(this), t;
  }
  /**
  Remove this mark from the given set, returning a new set. If this
  mark is not in the set, the set itself is returned.
  */
  removeFromSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return e.slice(0, t).concat(e.slice(t + 1));
    return e;
  }
  /**
  Test whether this mark is in the given set of marks.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return !0;
    return !1;
  }
  /**
  Test whether this mark has the same type and attributes as
  another mark.
  */
  eq(e) {
    return this == e || this.type == e.type && Fe(this.attrs, e.attrs);
  }
  /**
  Convert this mark to a JSON-serializeable representation.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return e;
  }
  /**
  Deserialize a mark from JSON.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let n = e.marks[t.type];
    if (!n)
      throw new RangeError(`There is no mark type ${t.type} in this schema`);
    return n.create(t.attrs);
  }
  /**
  Test whether two sets of marks are identical.
  */
  static sameSet(e, t) {
    if (e == t)
      return !0;
    if (e.length != t.length)
      return !1;
    for (let n = 0; n < e.length; n++)
      if (!e[n].eq(t[n]))
        return !1;
    return !0;
  }
  /**
  Create a properly sorted mark set from null, a single mark, or an
  unsorted array of marks.
  */
  static setFrom(e) {
    if (!e || Array.isArray(e) && e.length == 0)
      return b.none;
    if (e instanceof b)
      return [e];
    let t = e.slice();
    return t.sort((n, i) => n.type.rank - i.type.rank), t;
  }
}
b.none = [];
class ye extends Error {
}
class x {
  /**
  Create a slice. When specifying a non-zero open depth, you must
  make sure that there are nodes of at least that depth at the
  appropriate side of the fragment—i.e. if the fragment is an
  empty paragraph node, `openStart` and `openEnd` can't be greater
  than 1.
  
  It is not necessary for the content of open nodes to conform to
  the schema's content constraints, though it should be a valid
  start/end/middle for such a node, depending on which sides are
  open.
  */
  constructor(e, t, n) {
    this.content = e, this.openStart = t, this.openEnd = n;
  }
  /**
  The size this slice would add when inserted into a document.
  */
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  /**
  @internal
  */
  insertAt(e, t) {
    let n = rn(this.content, e + this.openStart, t, this.openStart + 1, this.openEnd + 1);
    return n && new x(n, this.openStart, this.openEnd);
  }
  /**
  @internal
  */
  removeBetween(e, t) {
    return new x(nn(this.content, e + this.openStart, t + this.openStart), this.openStart, this.openEnd);
  }
  /**
  Tests whether this slice is equal to another slice.
  */
  eq(e) {
    return this.content.eq(e.content) && this.openStart == e.openStart && this.openEnd == e.openEnd;
  }
  /**
  @internal
  */
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  /**
  Convert a slice to a JSON-serializable representation.
  */
  toJSON() {
    if (!this.content.size)
      return null;
    let e = { content: this.content.toJSON() };
    return this.openStart > 0 && (e.openStart = this.openStart), this.openEnd > 0 && (e.openEnd = this.openEnd), e;
  }
  /**
  Deserialize a slice from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return x.empty;
    let n = t.openStart || 0, i = t.openEnd || 0;
    if (typeof n != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new x(y.fromJSON(e, t.content), n, i);
  }
  /**
  Create a slice from a fragment by taking the maximum possible
  open value on both side of the fragment.
  */
  static maxOpen(e, t = !0) {
    let n = 0, i = 0;
    for (let s = e.firstChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.firstChild)
      n++;
    for (let s = e.lastChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.lastChild)
      i++;
    return new x(e, n, i);
  }
}
x.empty = new x(y.empty, 0, 0);
function nn(r, e, t) {
  let { index: n, offset: i } = r.findIndex(e), s = r.maybeChild(n), { index: o, offset: l } = r.findIndex(t);
  if (i == e || s.isText) {
    if (l != t && !r.child(o).isText)
      throw new RangeError("Removing non-flat range");
    return r.cut(0, e).append(r.cut(t));
  }
  if (n != o)
    throw new RangeError("Removing non-flat range");
  return r.replaceChild(n, s.copy(nn(s.content, e - i - 1, t - i - 1)));
}
function rn(r, e, t, n, i, s) {
  let { index: o, offset: l } = r.findIndex(e), a = r.maybeChild(o);
  if (l == e || a.isText)
    return s && n <= 0 && i <= 0 && !s.canReplace(o, o, t) ? null : r.cut(0, e).append(t).append(r.cut(e));
  let c = rn(a.content, e - l - 1, t, o == 0 ? n - 1 : 0, o == r.childCount - 1 ? i - 1 : 0, a);
  return c && r.replaceChild(o, a.copy(c));
}
function dr(r, e, t) {
  if (t.openStart > r.depth)
    throw new ye("Inserted content deeper than insertion position");
  if (r.depth - t.openStart != e.depth - t.openEnd)
    throw new ye("Inconsistent open depths");
  return sn(r, e, t, 0);
}
function sn(r, e, t, n) {
  let i = r.index(n), s = r.node(n);
  if (i == e.index(n) && n < r.depth - t.openStart) {
    let o = sn(r, e, t, n + 1);
    return s.copy(s.content.replaceChild(i, o));
  } else if (t.content.size)
    if (!t.openStart && !t.openEnd && r.depth == n && e.depth == n) {
      let o = r.parent, l = o.content;
      return Q(o, l.cut(0, r.parentOffset).append(t.content).append(l.cut(e.parentOffset)));
    } else {
      let { start: o, end: l } = pr(t, r);
      return Q(s, ln(r, o, l, e, n));
    }
  else return Q(s, Pe(r, e, n));
}
function on(r, e) {
  if (!e.type.compatibleContent(r.type))
    throw new ye("Cannot join " + e.type.name + " onto " + r.type.name);
}
function ot(r, e, t) {
  let n = r.node(t);
  return on(n, e.node(t)), n;
}
function Y(r, e) {
  let t = e.length - 1;
  t >= 0 && r.isText && r.sameMarkup(e[t]) ? e[t] = r.withText(e[t].text + r.text) : e.push(r);
}
function pe(r, e, t, n) {
  let i = (e || r).node(t), s = 0, o = e ? e.index(t) : i.childCount;
  r && (s = r.index(t), r.depth > t ? s++ : r.textOffset && (Y(r.nodeAfter, n), s++));
  for (let l = s; l < o; l++)
    Y(i.child(l), n);
  e && e.depth == t && e.textOffset && Y(e.nodeBefore, n);
}
function Q(r, e) {
  if (!r.type.validContent(e))
    throw new ye("Invalid content for node " + r.type.name);
  return r.copy(e);
}
function ln(r, e, t, n, i) {
  let s = r.depth > i && ot(r, e, i + 1), o = n.depth > i && ot(t, n, i + 1), l = [];
  return pe(null, r, i, l), s && o && e.index(i) == t.index(i) ? (on(s, o), Y(Q(s, ln(r, e, t, n, i + 1)), l)) : (s && Y(Q(s, Pe(r, e, i + 1)), l), pe(e, t, i, l), o && Y(Q(o, Pe(t, n, i + 1)), l)), pe(n, null, i, l), new y(l);
}
function Pe(r, e, t) {
  let n = [];
  if (pe(null, r, t, n), r.depth > t) {
    let i = ot(r, e, t + 1);
    Y(Q(i, Pe(r, e, t + 1)), n);
  }
  return pe(e, null, t, n), new y(n);
}
function pr(r, e) {
  let t = e.depth - r.openStart, i = e.node(t).copy(r.content);
  for (let s = t - 1; s >= 0; s--)
    i = e.node(s).copy(y.from(i));
  return {
    start: i.resolveNoCache(r.openStart + t),
    end: i.resolveNoCache(i.content.size - r.openEnd - t)
  };
}
class xe {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.pos = e, this.path = t, this.parentOffset = n, this.depth = t.length / 3 - 1;
  }
  /**
  @internal
  */
  resolveDepth(e) {
    return e == null ? this.depth : e < 0 ? this.depth + e : e;
  }
  /**
  The parent node that the position points into. Note that even if
  a position points into a text node, that node is not considered
  the parent—text nodes are ‘flat’ in this model, and have no content.
  */
  get parent() {
    return this.node(this.depth);
  }
  /**
  The root node in which the position was resolved.
  */
  get doc() {
    return this.node(0);
  }
  /**
  The ancestor node at the given level. `p.node(p.depth)` is the
  same as `p.parent`.
  */
  node(e) {
    return this.path[this.resolveDepth(e) * 3];
  }
  /**
  The index into the ancestor at the given level. If this points
  at the 3rd node in the 2nd paragraph on the top level, for
  example, `p.index(0)` is 1 and `p.index(1)` is 2.
  */
  index(e) {
    return this.path[this.resolveDepth(e) * 3 + 1];
  }
  /**
  The index pointing after this position into the ancestor at the
  given level.
  */
  indexAfter(e) {
    return e = this.resolveDepth(e), this.index(e) + (e == this.depth && !this.textOffset ? 0 : 1);
  }
  /**
  The (absolute) position at the start of the node at the given
  level.
  */
  start(e) {
    return e = this.resolveDepth(e), e == 0 ? 0 : this.path[e * 3 - 1] + 1;
  }
  /**
  The (absolute) position at the end of the node at the given
  level.
  */
  end(e) {
    return e = this.resolveDepth(e), this.start(e) + this.node(e).content.size;
  }
  /**
  The (absolute) position directly before the wrapping node at the
  given level, or, when `depth` is `this.depth + 1`, the original
  position.
  */
  before(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position before the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1];
  }
  /**
  The (absolute) position directly after the wrapping node at the
  given level, or the original position when `depth` is `this.depth + 1`.
  */
  after(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position after the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1] + this.path[e * 3].nodeSize;
  }
  /**
  When this position points into a text node, this returns the
  distance between the position and the start of the text node.
  Will be zero for positions that point between nodes.
  */
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  /**
  Get the node directly after the position, if any. If the position
  points into a text node, only the part of that node after the
  position is returned.
  */
  get nodeAfter() {
    let e = this.parent, t = this.index(this.depth);
    if (t == e.childCount)
      return null;
    let n = this.pos - this.path[this.path.length - 1], i = e.child(t);
    return n ? e.child(t).cut(n) : i;
  }
  /**
  Get the node directly before the position, if any. If the
  position points into a text node, only the part of that node
  before the position is returned.
  */
  get nodeBefore() {
    let e = this.index(this.depth), t = this.pos - this.path[this.path.length - 1];
    return t ? this.parent.child(e).cut(0, t) : e == 0 ? null : this.parent.child(e - 1);
  }
  /**
  Get the position at the given index in the parent node at the
  given depth (which defaults to `this.depth`).
  */
  posAtIndex(e, t) {
    t = this.resolveDepth(t);
    let n = this.path[t * 3], i = t == 0 ? 0 : this.path[t * 3 - 1] + 1;
    for (let s = 0; s < e; s++)
      i += n.child(s).nodeSize;
    return i;
  }
  /**
  Get the marks at this position, factoring in the surrounding
  marks' [`inclusive`](https://prosemirror.net/docs/ref/#model.MarkSpec.inclusive) property. If the
  position is at the start of a non-empty node, the marks of the
  node after it (if any) are returned.
  */
  marks() {
    let e = this.parent, t = this.index();
    if (e.content.size == 0)
      return b.none;
    if (this.textOffset)
      return e.child(t).marks;
    let n = e.maybeChild(t - 1), i = e.maybeChild(t);
    if (!n) {
      let l = n;
      n = i, i = l;
    }
    let s = n.marks;
    for (var o = 0; o < s.length; o++)
      s[o].type.spec.inclusive === !1 && (!i || !s[o].isInSet(i.marks)) && (s = s[o--].removeFromSet(s));
    return s;
  }
  /**
  Get the marks after the current position, if any, except those
  that are non-inclusive and not present at position `$end`. This
  is mostly useful for getting the set of marks to preserve after a
  deletion. Will return `null` if this position is at the end of
  its parent node or its parent node isn't a textblock (in which
  case no marks should be preserved).
  */
  marksAcross(e) {
    let t = this.parent.maybeChild(this.index());
    if (!t || !t.isInline)
      return null;
    let n = t.marks, i = e.parent.maybeChild(e.index());
    for (var s = 0; s < n.length; s++)
      n[s].type.spec.inclusive === !1 && (!i || !n[s].isInSet(i.marks)) && (n = n[s--].removeFromSet(n));
    return n;
  }
  /**
  The depth up to which this position and the given (non-resolved)
  position share the same parent nodes.
  */
  sharedDepth(e) {
    for (let t = this.depth; t > 0; t--)
      if (this.start(t) <= e && this.end(t) >= e)
        return t;
    return 0;
  }
  /**
  Returns a range based on the place where this position and the
  given position diverge around block content. If both point into
  the same textblock, for example, a range around that textblock
  will be returned. If they point into different blocks, the range
  around those blocks in their shared ancestor is returned. You can
  pass in an optional predicate that will be called with a parent
  node to see if a range into that parent is acceptable.
  */
  blockRange(e = this, t) {
    if (e.pos < this.pos)
      return e.blockRange(this);
    for (let n = this.depth - (this.parent.inlineContent || this.pos == e.pos ? 1 : 0); n >= 0; n--)
      if (e.pos <= this.end(n) && (!t || t(this.node(n))))
        return new De(this, e, n);
    return null;
  }
  /**
  Query whether the given position shares the same parent node.
  */
  sameParent(e) {
    return this.pos - this.parentOffset == e.pos - e.parentOffset;
  }
  /**
  Return the greater of this and the given position.
  */
  max(e) {
    return e.pos > this.pos ? e : this;
  }
  /**
  Return the smaller of this and the given position.
  */
  min(e) {
    return e.pos < this.pos ? e : this;
  }
  /**
  @internal
  */
  toString() {
    let e = "";
    for (let t = 1; t <= this.depth; t++)
      e += (e ? "/" : "") + this.node(t).type.name + "_" + this.index(t - 1);
    return e + ":" + this.parentOffset;
  }
  /**
  @internal
  */
  static resolve(e, t) {
    if (!(t >= 0 && t <= e.content.size))
      throw new RangeError("Position " + t + " out of range");
    let n = [], i = 0, s = t;
    for (let o = e; ; ) {
      let { index: l, offset: a } = o.content.findIndex(s), c = s - a;
      if (n.push(o, l, i + a), !c || (o = o.child(l), o.isText))
        break;
      s = c - 1, i += a + 1;
    }
    return new xe(t, n, s);
  }
  /**
  @internal
  */
  static resolveCached(e, t) {
    let n = Et.get(e);
    if (n)
      for (let s = 0; s < n.elts.length; s++) {
        let o = n.elts[s];
        if (o.pos == t)
          return o;
      }
    else
      Et.set(e, n = new mr());
    let i = n.elts[n.i] = xe.resolve(e, t);
    return n.i = (n.i + 1) % gr, i;
  }
}
class mr {
  constructor() {
    this.elts = [], this.i = 0;
  }
}
const gr = 12, Et = /* @__PURE__ */ new WeakMap();
class De {
  /**
  Construct a node range. `$from` and `$to` should point into the
  same node until at least the given `depth`, since a node range
  denotes an adjacent set of nodes in a single parent node.
  */
  constructor(e, t, n) {
    this.$from = e, this.$to = t, this.depth = n;
  }
  /**
  The position at the start of the range.
  */
  get start() {
    return this.$from.before(this.depth + 1);
  }
  /**
  The position at the end of the range.
  */
  get end() {
    return this.$to.after(this.depth + 1);
  }
  /**
  The parent node that the range points into.
  */
  get parent() {
    return this.$from.node(this.depth);
  }
  /**
  The start index of the range in the parent node.
  */
  get startIndex() {
    return this.$from.index(this.depth);
  }
  /**
  The end index of the range in the parent node.
  */
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const yr = /* @__PURE__ */ Object.create(null);
let _ = class lt {
  /**
  @internal
  */
  constructor(e, t, n, i = b.none) {
    this.type = e, this.attrs = t, this.marks = i, this.content = n || y.empty;
  }
  /**
  The array of this node's child nodes.
  */
  get children() {
    return this.content.content;
  }
  /**
  The size of this node, as defined by the integer-based [indexing
  scheme](https://prosemirror.net/docs/guide/#doc.indexing). For text nodes, this is the
  amount of characters. For other leaf nodes, it is one. For
  non-leaf nodes, it is the size of the content plus two (the
  start and end token).
  */
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  /**
  The number of children that the node has.
  */
  get childCount() {
    return this.content.childCount;
  }
  /**
  Get the child node at the given index. Raises an error when the
  index is out of range.
  */
  child(e) {
    return this.content.child(e);
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content.maybeChild(e);
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    this.content.forEach(e);
  }
  /**
  Invoke a callback for all descendant nodes recursively overlapping
  the given two positions that are relative to start of this
  node's content. This includes all ancestors of the nodes
  containing the two positions. The callback is invoked with the
  node, its position relative to the original node (method receiver),
  its parent node, and its child index. When the callback returns
  false for a given node, that node's children will not be
  recursed over. The last parameter can be used to specify a
  starting position to count from.
  */
  nodesBetween(e, t, n, i = 0) {
    this.content.nodesBetween(e, t, n, i, this);
  }
  /**
  Call the given callback for every descendant node. Doesn't
  descend into a node when the callback returns `false`.
  */
  descendants(e) {
    this.nodesBetween(0, this.content.size, e);
  }
  /**
  Concatenates all the text nodes found in this fragment and its
  children.
  */
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  /**
  Get all text between positions `from` and `to`. When
  `blockSeparator` is given, it will be inserted to separate text
  from different block nodes. If `leafText` is given, it'll be
  inserted for every non-text leaf node encountered, otherwise
  [`leafText`](https://prosemirror.net/docs/ref/#model.NodeSpec.leafText) will be used.
  */
  textBetween(e, t, n, i) {
    return this.content.textBetween(e, t, n, i);
  }
  /**
  Returns this node's first child, or `null` if there are no
  children.
  */
  get firstChild() {
    return this.content.firstChild;
  }
  /**
  Returns this node's last child, or `null` if there are no
  children.
  */
  get lastChild() {
    return this.content.lastChild;
  }
  /**
  Test whether two nodes represent the same piece of document.
  */
  eq(e) {
    return this == e || this.sameMarkup(e) && this.content.eq(e.content);
  }
  /**
  Compare the markup (type, attributes, and marks) of this node to
  those of another. Returns `true` if both have the same markup.
  */
  sameMarkup(e) {
    return this.hasMarkup(e.type, e.attrs, e.marks);
  }
  /**
  Check whether this node's markup correspond to the given type,
  attributes, and marks.
  */
  hasMarkup(e, t, n) {
    return this.type == e && Fe(this.attrs, t || e.defaultAttrs || yr) && b.sameSet(this.marks, n || b.none);
  }
  /**
  Create a new node with the same markup as this node, containing
  the given content (or empty, if no content is given).
  */
  copy(e = null) {
    return e == this.content ? this : new lt(this.type, this.attrs, e, this.marks);
  }
  /**
  Create a copy of this node, with the given set of marks instead
  of the node's own marks.
  */
  mark(e) {
    return e == this.marks ? this : new lt(this.type, this.attrs, this.content, e);
  }
  /**
  Create a copy of this node with only the content between the
  given positions. If `to` is not given, it defaults to the end of
  the node.
  */
  cut(e, t = this.content.size) {
    return e == 0 && t == this.content.size ? this : this.copy(this.content.cut(e, t));
  }
  /**
  Cut out the part of the document between the given positions, and
  return it as a `Slice` object.
  */
  slice(e, t = this.content.size, n = !1) {
    if (e == t)
      return x.empty;
    let i = this.resolve(e), s = this.resolve(t), o = n ? 0 : i.sharedDepth(t), l = i.start(o), c = i.node(o).content.cut(i.pos - l, s.pos - l);
    return new x(c, i.depth - o, s.depth - o);
  }
  /**
  Replace the part of the document between the given positions with
  the given slice. The slice must 'fit', meaning its open sides
  must be able to connect to the surrounding content, and its
  content nodes must be valid children for the node they are placed
  into. If any of this is violated, an error of type
  [`ReplaceError`](https://prosemirror.net/docs/ref/#model.ReplaceError) is thrown.
  */
  replace(e, t, n) {
    return dr(this.resolve(e), this.resolve(t), n);
  }
  /**
  Find the node directly after the given position.
  */
  nodeAt(e) {
    for (let t = this; ; ) {
      let { index: n, offset: i } = t.content.findIndex(e);
      if (t = t.maybeChild(n), !t)
        return null;
      if (i == e || t.isText)
        return t;
      e -= i + 1;
    }
  }
  /**
  Find the (direct) child node after the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childAfter(e) {
    let { index: t, offset: n } = this.content.findIndex(e);
    return { node: this.content.maybeChild(t), index: t, offset: n };
  }
  /**
  Find the (direct) child node before the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childBefore(e) {
    if (e == 0)
      return { node: null, index: 0, offset: 0 };
    let { index: t, offset: n } = this.content.findIndex(e);
    if (n < e)
      return { node: this.content.child(t), index: t, offset: n };
    let i = this.content.child(t - 1);
    return { node: i, index: t - 1, offset: n - i.nodeSize };
  }
  /**
  Resolve the given position in the document, returning an
  [object](https://prosemirror.net/docs/ref/#model.ResolvedPos) with information about its context.
  */
  resolve(e) {
    return xe.resolveCached(this, e);
  }
  /**
  @internal
  */
  resolveNoCache(e) {
    return xe.resolve(this, e);
  }
  /**
  Test whether a given mark or mark type occurs in this document
  between the two given positions.
  */
  rangeHasMark(e, t, n) {
    let i = !1;
    return t > e && this.nodesBetween(e, t, (s) => (n.isInSet(s.marks) && (i = !0), !i)), i;
  }
  /**
  True when this is a block (non-inline node)
  */
  get isBlock() {
    return this.type.isBlock;
  }
  /**
  True when this is a textblock node, a block node with inline
  content.
  */
  get isTextblock() {
    return this.type.isTextblock;
  }
  /**
  True when this node allows inline content.
  */
  get inlineContent() {
    return this.type.inlineContent;
  }
  /**
  True when this is an inline node (a text node or a node that can
  appear among text).
  */
  get isInline() {
    return this.type.isInline;
  }
  /**
  True when this is a text node.
  */
  get isText() {
    return this.type.isText;
  }
  /**
  True when this is a leaf node.
  */
  get isLeaf() {
    return this.type.isLeaf;
  }
  /**
  True when this is an atom, i.e. when it does not have directly
  editable content. This is usually the same as `isLeaf`, but can
  be configured with the [`atom` property](https://prosemirror.net/docs/ref/#model.NodeSpec.atom)
  on a node's spec (typically used when the node is displayed as
  an uneditable [node view](https://prosemirror.net/docs/ref/#view.NodeView)).
  */
  get isAtom() {
    return this.type.isAtom;
  }
  /**
  Return a string representation of this node for debugging
  purposes.
  */
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let e = this.type.name;
    return this.content.size && (e += "(" + this.content.toStringInner() + ")"), an(this.marks, e);
  }
  /**
  Get the content match in this node at the given index.
  */
  contentMatchAt(e) {
    let t = this.type.contentMatch.matchFragment(this.content, 0, e);
    if (!t)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return t;
  }
  /**
  Test whether replacing the range between `from` and `to` (by
  child index) with the given replacement fragment (which defaults
  to the empty fragment) would leave the node's content valid. You
  can optionally pass `start` and `end` indices into the
  replacement fragment.
  */
  canReplace(e, t, n = y.empty, i = 0, s = n.childCount) {
    let o = this.contentMatchAt(e).matchFragment(n, i, s), l = o && o.matchFragment(this.content, t);
    if (!l || !l.validEnd)
      return !1;
    for (let a = i; a < s; a++)
      if (!this.type.allowsMarks(n.child(a).marks))
        return !1;
    return !0;
  }
  /**
  Test whether replacing the range `from` to `to` (by index) with
  a node of the given type would leave the node's content valid.
  */
  canReplaceWith(e, t, n, i) {
    if (i && !this.type.allowsMarks(i))
      return !1;
    let s = this.contentMatchAt(e).matchType(n), o = s && s.matchFragment(this.content, t);
    return o ? o.validEnd : !1;
  }
  /**
  Test whether the given node's content could be appended to this
  node. If that node is empty, this will only return true if there
  is at least one node type that can appear in both nodes (to avoid
  merging completely incompatible nodes).
  */
  canAppend(e) {
    return e.content.size ? this.canReplace(this.childCount, this.childCount, e.content) : this.type.compatibleContent(e.type);
  }
  /**
  Check whether this node and its descendants conform to the
  schema, and raise an exception when they do not.
  */
  check() {
    this.type.checkContent(this.content), Mt(this.type.attrs, this.attrs, "node", this.type.name);
    let e = b.none;
    for (let t = 0; t < this.marks.length; t++) {
      let n = this.marks[t];
      Mt(n.type.attrs, n.attrs, "mark", n.type.name), e = n.addToSet(e);
    }
    if (!b.sameSet(e, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((t) => t.type.name)}`);
    this.content.forEach((t) => t.check());
  }
  /**
  Return a JSON-serializeable representation of this node.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return this.content.size && (e.content = this.content.toJSON()), this.marks.length && (e.marks = this.marks.map((t) => t.toJSON())), e;
  }
  /**
  Deserialize a node from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Node.fromJSON");
    let n;
    if (t.marks) {
      if (!Array.isArray(t.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      n = t.marks.map(e.markFromJSON);
    }
    if (t.type == "text") {
      if (typeof t.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return e.text(t.text, n);
    }
    let i = y.fromJSON(e, t.content);
    return e.nodeType(t.type).create(t.attrs, i, n);
  }
};
_.prototype.text = void 0;
const At = (() => {
  let { stack: r } = new Error("/");
  if (!r || !/\n\s*at\s/.test(r))
    return (t) => t;
  let e = /* @__PURE__ */ Object.create(null);
  return (t) => (e[t], t);
})();
class $e extends _ {
  /**
  @internal
  */
  constructor(e, t, n, i) {
    if (super(e, t, null, i), !n)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = n;
  }
  toString() {
    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : an(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(e, t) {
    return At(this.text.slice(e, t));
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(e) {
    return e == this.marks ? this : new $e(this.type, this.attrs, this.text, e);
  }
  withText(e) {
    return e == this.text ? this : new $e(this.type, this.attrs, e, this.marks);
  }
  cut(e = 0, t = this.text.length) {
    return e == 0 && t == this.text.length ? this : this.withText(At(this.text.slice(e, t)));
  }
  eq(e) {
    return this.sameMarkup(e) && this.text == e.text;
  }
  toJSON() {
    let e = super.toJSON();
    return e.text = this.text, e;
  }
}
function an(r, e) {
  for (let t = r.length - 1; t >= 0; t--)
    e = r[t].type.name + "(" + e + ")";
  return e;
}
function Mt(r, e, t, n) {
  for (let i in e)
    if (!(i in r))
      throw new RangeError(`Unsupported attribute ${i} for ${t} of type ${n}`);
  for (let i in r)
    r[i].validate && r[i].validate(e[i]);
}
class te {
  /**
  @internal
  */
  constructor(e) {
    this.validEnd = e, this.next = [], this.wrapCache = [];
  }
  /**
  @internal
  */
  static parse(e, t) {
    let n = new xr(e, t);
    if (n.next == null)
      return te.empty;
    let i = cn(n);
    n.next && n.err("Unexpected trailing text");
    let s = Er(Cr(i));
    return Ar(s, n), s;
  }
  /**
  Match a node type, returning a match after that node if
  successful.
  */
  matchType(e) {
    for (let t = 0; t < this.next.length; t++)
      if (this.next[t].type == e)
        return this.next[t].next;
    return null;
  }
  /**
  Try to match a fragment. Returns the resulting match when
  successful.
  */
  matchFragment(e, t = 0, n = e.childCount) {
    let i = this;
    for (let s = t; i && s < n; s++)
      i = i.matchType(e.child(s).type);
    return i;
  }
  /**
  @internal
  */
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  /**
  Get the first matching node type at this match position that can
  be generated.
  */
  get defaultType() {
    for (let e = 0; e < this.next.length; e++) {
      let { type: t } = this.next[e];
      if (!(t.isText || t.hasRequiredAttrs()))
        return t;
    }
    return null;
  }
  /**
  @internal
  */
  compatible(e) {
    for (let t = 0; t < this.next.length; t++)
      for (let n = 0; n < e.next.length; n++)
        if (this.next[t].type == e.next[n].type)
          return !0;
    return !1;
  }
  /**
  Try to match the given fragment, and if that fails, see if it can
  be made to match by inserting nodes in front of it. When
  successful, return a fragment of inserted nodes (which may be
  empty if nothing had to be inserted). When `toEnd` is true, only
  return a fragment if the resulting match goes to the end of the
  content expression.
  */
  fillBefore(e, t = !1, n = 0) {
    let i = [this];
    function s(o, l) {
      let a = o.matchFragment(e, n);
      if (a && (!t || a.validEnd))
        return y.from(l.map((c) => c.createAndFill()));
      for (let c = 0; c < o.next.length; c++) {
        let { type: f, next: u } = o.next[c];
        if (!(f.isText || f.hasRequiredAttrs()) && i.indexOf(u) == -1) {
          i.push(u);
          let d = s(u, l.concat(f));
          if (d)
            return d;
        }
      }
      return null;
    }
    return s(this, []);
  }
  /**
  Find a set of wrapping node types that would allow a node of the
  given type to appear at this position. The result may be empty
  (when it fits directly) and will be null when no such wrapping
  exists.
  */
  findWrapping(e) {
    for (let n = 0; n < this.wrapCache.length; n += 2)
      if (this.wrapCache[n] == e)
        return this.wrapCache[n + 1];
    let t = this.computeWrapping(e);
    return this.wrapCache.push(e, t), t;
  }
  /**
  @internal
  */
  computeWrapping(e) {
    let t = /* @__PURE__ */ Object.create(null), n = [{ match: this, type: null, via: null }];
    for (; n.length; ) {
      let i = n.shift(), s = i.match;
      if (s.matchType(e)) {
        let o = [];
        for (let l = i; l.type; l = l.via)
          o.push(l.type);
        return o.reverse();
      }
      for (let o = 0; o < s.next.length; o++) {
        let { type: l, next: a } = s.next[o];
        !l.isLeaf && !l.hasRequiredAttrs() && !(l.name in t) && (!i.type || a.validEnd) && (n.push({ match: l.contentMatch, type: l, via: i }), t[l.name] = !0);
      }
    }
    return null;
  }
  /**
  The number of outgoing edges this node has in the finite
  automaton that describes the content expression.
  */
  get edgeCount() {
    return this.next.length;
  }
  /**
  Get the _n_​th outgoing edge from this node in the finite
  automaton that describes the content expression.
  */
  edge(e) {
    if (e >= this.next.length)
      throw new RangeError(`There's no ${e}th edge in this content match`);
    return this.next[e];
  }
  /**
  @internal
  */
  toString() {
    let e = [];
    function t(n) {
      e.push(n);
      for (let i = 0; i < n.next.length; i++)
        e.indexOf(n.next[i].next) == -1 && t(n.next[i].next);
    }
    return t(this), e.map((n, i) => {
      let s = i + (n.validEnd ? "*" : " ") + " ";
      for (let o = 0; o < n.next.length; o++)
        s += (o ? ", " : "") + n.next[o].type.name + "->" + e.indexOf(n.next[o].next);
      return s;
    }).join(`
`);
  }
}
te.empty = new te(!0);
class xr {
  constructor(e, t) {
    this.string = e, this.nodeTypes = t, this.inline = null, this.pos = 0, this.tokens = e.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(e) {
    return this.next == e && (this.pos++ || !0);
  }
  err(e) {
    throw new SyntaxError(e + " (in content expression '" + this.string + "')");
  }
}
function cn(r) {
  let e = [];
  do
    e.push(wr(r));
  while (r.eat("|"));
  return e.length == 1 ? e[0] : { type: "choice", exprs: e };
}
function wr(r) {
  let e = [];
  do
    e.push(kr(r));
  while (r.next && r.next != ")" && r.next != "|");
  return e.length == 1 ? e[0] : { type: "seq", exprs: e };
}
function kr(r) {
  let e = vr(r);
  for (; ; )
    if (r.eat("+"))
      e = { type: "plus", expr: e };
    else if (r.eat("*"))
      e = { type: "star", expr: e };
    else if (r.eat("?"))
      e = { type: "opt", expr: e };
    else if (r.eat("{"))
      e = br(r, e);
    else
      break;
  return e;
}
function Tt(r) {
  /\D/.test(r.next) && r.err("Expected number, got '" + r.next + "'");
  let e = Number(r.next);
  return r.pos++, e;
}
function br(r, e) {
  let t = Tt(r), n = t;
  return r.eat(",") && (r.next != "}" ? n = Tt(r) : n = -1), r.eat("}") || r.err("Unclosed braced range"), { type: "range", min: t, max: n, expr: e };
}
function Sr(r, e) {
  let t = r.nodeTypes, n = t[e];
  if (n)
    return [n];
  let i = [];
  for (let s in t) {
    let o = t[s];
    o.isInGroup(e) && i.push(o);
  }
  return i.length == 0 && r.err("No node type or group '" + e + "' found"), i;
}
function vr(r) {
  if (r.eat("(")) {
    let e = cn(r);
    return r.eat(")") || r.err("Missing closing paren"), e;
  } else if (/\W/.test(r.next))
    r.err("Unexpected token '" + r.next + "'");
  else {
    let e = Sr(r, r.next).map((t) => (r.inline == null ? r.inline = t.isInline : r.inline != t.isInline && r.err("Mixing inline and block content"), { type: "name", value: t }));
    return r.pos++, e.length == 1 ? e[0] : { type: "choice", exprs: e };
  }
}
function Cr(r) {
  let e = [[]];
  return i(s(r, 0), t()), e;
  function t() {
    return e.push([]) - 1;
  }
  function n(o, l, a) {
    let c = { term: a, to: l };
    return e[o].push(c), c;
  }
  function i(o, l) {
    o.forEach((a) => a.to = l);
  }
  function s(o, l) {
    if (o.type == "choice")
      return o.exprs.reduce((a, c) => a.concat(s(c, l)), []);
    if (o.type == "seq")
      for (let a = 0; ; a++) {
        let c = s(o.exprs[a], l);
        if (a == o.exprs.length - 1)
          return c;
        i(c, l = t());
      }
    else if (o.type == "star") {
      let a = t();
      return n(l, a), i(s(o.expr, a), a), [n(a)];
    } else if (o.type == "plus") {
      let a = t();
      return i(s(o.expr, l), a), i(s(o.expr, a), a), [n(a)];
    } else {
      if (o.type == "opt")
        return [n(l)].concat(s(o.expr, l));
      if (o.type == "range") {
        let a = l;
        for (let c = 0; c < o.min; c++) {
          let f = t();
          i(s(o.expr, a), f), a = f;
        }
        if (o.max == -1)
          i(s(o.expr, a), a);
        else
          for (let c = o.min; c < o.max; c++) {
            let f = t();
            n(a, f), i(s(o.expr, a), f), a = f;
          }
        return [n(a)];
      } else {
        if (o.type == "name")
          return [n(l, void 0, o.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function fn(r, e) {
  return e - r;
}
function It(r, e) {
  let t = [];
  return n(e), t.sort(fn);
  function n(i) {
    let s = r[i];
    if (s.length == 1 && !s[0].term)
      return n(s[0].to);
    t.push(i);
    for (let o = 0; o < s.length; o++) {
      let { term: l, to: a } = s[o];
      !l && t.indexOf(a) == -1 && n(a);
    }
  }
}
function Er(r) {
  let e = /* @__PURE__ */ Object.create(null);
  return t(It(r, 0));
  function t(n) {
    let i = [];
    n.forEach((o) => {
      r[o].forEach(({ term: l, to: a }) => {
        if (!l)
          return;
        let c;
        for (let f = 0; f < i.length; f++)
          i[f][0] == l && (c = i[f][1]);
        It(r, a).forEach((f) => {
          c || i.push([l, c = []]), c.indexOf(f) == -1 && c.push(f);
        });
      });
    });
    let s = e[n.join(",")] = new te(n.indexOf(r.length - 1) > -1);
    for (let o = 0; o < i.length; o++) {
      let l = i[o][1].sort(fn);
      s.next.push({ type: i[o][0], next: e[l.join(",")] || t(l) });
    }
    return s;
  }
}
function Ar(r, e) {
  for (let t = 0, n = [r]; t < n.length; t++) {
    let i = n[t], s = !i.validEnd, o = [];
    for (let l = 0; l < i.next.length; l++) {
      let { type: a, next: c } = i.next[l];
      o.push(a.name), s && !(a.isText || a.hasRequiredAttrs()) && (s = !1), n.indexOf(c) == -1 && n.push(c);
    }
    s && e.err("Only non-generatable nodes (" + o.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function un(r) {
  let e = /* @__PURE__ */ Object.create(null);
  for (let t in r) {
    let n = r[t];
    if (!n.hasDefault)
      return null;
    e[t] = n.default;
  }
  return e;
}
function hn(r, e) {
  let t = /* @__PURE__ */ Object.create(null);
  for (let n in r) {
    let i = r[n], s = e && e[n];
    if (s === void 0)
      if (i.hasDefault)
        s = i.default;
      else
        throw new RangeError("No value supplied for attribute " + n);
    else i.validate && i.validate(s);
    t[n] = s;
  }
  return t;
}
function dn(r, e) {
  let t = /* @__PURE__ */ Object.create(null);
  if (e)
    for (let n in e)
      t[n] = new Tr(r, n, e[n]);
  return t;
}
class we {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.name = e, this.schema = t, this.spec = n, this.markSet = null, this.groups = n.group ? n.group.split(" ") : [], this.attrs = dn(e, n.attrs), this.defaultAttrs = un(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(n.inline || e == "text"), this.isText = e == "text";
  }
  /**
  True if this is an inline type.
  */
  get isInline() {
    return !this.isBlock;
  }
  /**
  True if this is a textblock type, a block that contains inline
  content.
  */
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  /**
  True for node types that allow no content.
  */
  get isLeaf() {
    return this.contentMatch == te.empty;
  }
  /**
  True when this node is an atom, i.e. when it does not have
  directly editable content.
  */
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  /**
  Return true when this node type is part of the given
  [group](https://prosemirror.net/docs/ref/#model.NodeSpec.group).
  */
  isInGroup(e) {
    return this.groups.indexOf(e) > -1;
  }
  /**
  The node type's [whitespace](https://prosemirror.net/docs/ref/#model.NodeSpec.whitespace) option.
  */
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  /**
  Tells you whether this node type has any required attributes.
  */
  hasRequiredAttrs() {
    for (let e in this.attrs)
      if (this.attrs[e].isRequired)
        return !0;
    return !1;
  }
  /**
  Indicates whether this node allows some of the same content as
  the given node type.
  */
  compatibleContent(e) {
    return this == e || this.contentMatch.compatible(e.contentMatch);
  }
  /**
  @internal
  */
  computeAttrs(e) {
    return !e && this.defaultAttrs ? this.defaultAttrs : hn(this.attrs, e);
  }
  /**
  Create a `Node` of this type. The given attributes are
  checked and defaulted (you can pass `null` to use the type's
  defaults entirely, if no required attributes exist). `content`
  may be a `Fragment`, a node, an array of nodes, or
  `null`. Similarly `marks` may be `null` to default to the empty
  set of marks.
  */
  create(e = null, t, n) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new _(this, this.computeAttrs(e), y.from(t), b.setFrom(n));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but check the given content
  against the node type's content restrictions, and throw an error
  if it doesn't match.
  */
  createChecked(e = null, t, n) {
    return t = y.from(t), this.checkContent(t), new _(this, this.computeAttrs(e), t, b.setFrom(n));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but see if it is
  necessary to add nodes to the start or end of the given fragment
  to make it fit the node. If no fitting wrapping can be found,
  return null. Note that, due to the fact that required nodes can
  always be created, this will always succeed if you pass null or
  `Fragment.empty` as content.
  */
  createAndFill(e = null, t, n) {
    if (e = this.computeAttrs(e), t = y.from(t), t.size) {
      let o = this.contentMatch.fillBefore(t);
      if (!o)
        return null;
      t = o.append(t);
    }
    let i = this.contentMatch.matchFragment(t), s = i && i.fillBefore(y.empty, !0);
    return s ? new _(this, e, t.append(s), b.setFrom(n)) : null;
  }
  /**
  Returns true if the given fragment is valid content for this node
  type.
  */
  validContent(e) {
    let t = this.contentMatch.matchFragment(e);
    if (!t || !t.validEnd)
      return !1;
    for (let n = 0; n < e.childCount; n++)
      if (!this.allowsMarks(e.child(n).marks))
        return !1;
    return !0;
  }
  /**
  Throws a RangeError if the given fragment is not valid content for this
  node type.
  @internal
  */
  checkContent(e) {
    if (!this.validContent(e))
      throw new RangeError(`Invalid content for node ${this.name}: ${e.toString().slice(0, 50)}`);
  }
  /**
  @internal no longer useful, but called by old prosemirror-view versions
  */
  checkAttrs(e) {
  }
  /**
  Check whether the given mark type is allowed in this node.
  */
  allowsMarkType(e) {
    return this.markSet == null || this.markSet.indexOf(e) > -1;
  }
  /**
  Test whether the given set of marks are allowed in this node.
  */
  allowsMarks(e) {
    if (this.markSet == null)
      return !0;
    for (let t = 0; t < e.length; t++)
      if (!this.allowsMarkType(e[t].type))
        return !1;
    return !0;
  }
  /**
  Removes the marks that are not allowed in this node from the given set.
  */
  allowedMarks(e) {
    if (this.markSet == null)
      return e;
    let t;
    for (let n = 0; n < e.length; n++)
      this.allowsMarkType(e[n].type) ? t && t.push(e[n]) : t || (t = e.slice(0, n));
    return t ? t.length ? t : b.none : e;
  }
  /**
  @internal
  */
  static compile(e, t) {
    let n = /* @__PURE__ */ Object.create(null);
    e.forEach((s, o) => n[s] = new we(s, t, o));
    let i = t.spec.topNode || "doc";
    if (!n[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!n.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let s in n.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return n;
  }
}
function Mr(r, e, t) {
  let n = t.split("|");
  return (i) => {
    let s = i === null ? "null" : typeof i;
    if (n.indexOf(s) < 0)
      throw new RangeError(`Expected value of type ${n} for attribute ${e} on type ${r}, got ${s}`);
  };
}
class Tr {
  constructor(e, t, n) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(n, "default"), this.default = n.default, this.validate = typeof n.validate == "string" ? Mr(e, t, n.validate) : n.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class ut {
  /**
  @internal
  */
  constructor(e, t, n, i) {
    this.name = e, this.rank = t, this.schema = n, this.spec = i, this.attrs = dn(e, i.attrs), this.excluded = null;
    let s = un(this.attrs);
    this.instance = s ? new b(this, s) : null;
  }
  /**
  Create a mark of this type. `attrs` may be `null` or an object
  containing only some of the mark's attributes. The others, if
  they have defaults, will be added.
  */
  create(e = null) {
    return !e && this.instance ? this.instance : new b(this, hn(this.attrs, e));
  }
  /**
  @internal
  */
  static compile(e, t) {
    let n = /* @__PURE__ */ Object.create(null), i = 0;
    return e.forEach((s, o) => n[s] = new ut(s, i++, t, o)), n;
  }
  /**
  When there is a mark of this type in the given set, a new set
  without it is returned. Otherwise, the input set is returned.
  */
  removeFromSet(e) {
    for (var t = 0; t < e.length; t++)
      e[t].type == this && (e = e.slice(0, t).concat(e.slice(t + 1)), t--);
    return e;
  }
  /**
  Tests whether there is a mark of this type in the given set.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (e[t].type == this)
        return e[t];
  }
  /**
  Queries whether a given mark type is
  [excluded](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) by this one.
  */
  excludes(e) {
    return this.excluded.indexOf(e) > -1;
  }
}
class Ir {
  /**
  Construct a schema from a schema [specification](https://prosemirror.net/docs/ref/#model.SchemaSpec).
  */
  constructor(e) {
    this.linebreakReplacement = null, this.cached = /* @__PURE__ */ Object.create(null);
    let t = this.spec = {};
    for (let i in e)
      t[i] = e[i];
    t.nodes = N.from(e.nodes), t.marks = N.from(e.marks || {}), this.nodes = we.compile(this.spec.nodes, this), this.marks = ut.compile(this.spec.marks, this);
    let n = /* @__PURE__ */ Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let s = this.nodes[i], o = s.spec.content || "", l = s.spec.marks;
      if (s.contentMatch = n[o] || (n[o] = te.parse(o, this.nodes)), s.inlineContent = s.contentMatch.inlineContent, s.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!s.isInline || !s.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = s;
      }
      s.markSet = l == "_" ? null : l ? Ot(this, l.split(" ")) : l == "" || !s.inlineContent ? [] : null;
    }
    for (let i in this.marks) {
      let s = this.marks[i], o = s.spec.excludes;
      s.excluded = o == null ? [s] : o == "" ? [] : Ot(this, o.split(" "));
    }
    this.nodeFromJSON = (i) => _.fromJSON(this, i), this.markFromJSON = (i) => b.fromJSON(this, i), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = /* @__PURE__ */ Object.create(null);
  }
  /**
  Create a node in this schema. The `type` may be a string or a
  `NodeType` instance. Attributes will be extended with defaults,
  `content` may be a `Fragment`, `null`, a `Node`, or an array of
  nodes.
  */
  node(e, t = null, n, i) {
    if (typeof e == "string")
      e = this.nodeType(e);
    else if (e instanceof we) {
      if (e.schema != this)
        throw new RangeError("Node type from different schema used (" + e.name + ")");
    } else throw new RangeError("Invalid node type: " + e);
    return e.createChecked(t, n, i);
  }
  /**
  Create a text node in the schema. Empty text nodes are not
  allowed.
  */
  text(e, t) {
    let n = this.nodes.text;
    return new $e(n, n.defaultAttrs, e, b.setFrom(t));
  }
  /**
  Create a mark with the given type and attributes.
  */
  mark(e, t) {
    return typeof e == "string" && (e = this.marks[e]), e.create(t);
  }
  /**
  @internal
  */
  nodeType(e) {
    let t = this.nodes[e];
    if (!t)
      throw new RangeError("Unknown node type: " + e);
    return t;
  }
}
function Ot(r, e) {
  let t = [];
  for (let n = 0; n < e.length; n++) {
    let i = e[n], s = r.marks[i], o = s;
    if (s)
      t.push(s);
    else
      for (let l in r.marks) {
        let a = r.marks[l];
        (i == "_" || a.spec.group && a.spec.group.split(" ").indexOf(i) > -1) && t.push(o = a);
      }
    if (!o)
      throw new SyntaxError("Unknown mark type: '" + e[n] + "'");
  }
  return t;
}
function Or(r) {
  return r.tag != null;
}
function Nr(r) {
  return r.style != null;
}
class oe {
  /**
  Create a parser that targets the given schema, using the given
  parsing rules.
  */
  constructor(e, t) {
    this.schema = e, this.rules = t, this.tags = [], this.styles = [];
    let n = this.matchedStyles = [];
    t.forEach((i) => {
      if (Or(i))
        this.tags.push(i);
      else if (Nr(i)) {
        let s = /[^=]*/.exec(i.style)[0];
        n.indexOf(s) < 0 && n.push(s), this.styles.push(i);
      }
    }), this.normalizeLists = !this.tags.some((i) => {
      if (!/^(ul|ol)\b/.test(i.tag) || !i.node)
        return !1;
      let s = e.nodes[i.node];
      return s.contentMatch.matchType(s);
    });
  }
  /**
  Parse a document from the content of a DOM node.
  */
  parse(e, t = {}) {
    let n = new Rt(this, t, !1);
    return n.addAll(e, b.none, t.from, t.to), n.finish();
  }
  /**
  Parses the content of the given DOM node, like
  [`parse`](https://prosemirror.net/docs/ref/#model.DOMParser.parse), and takes the same set of
  options. But unlike that method, which produces a whole node,
  this one returns a slice that is open at the sides, meaning that
  the schema constraints aren't applied to the start of nodes to
  the left of the input and the end of nodes at the end.
  */
  parseSlice(e, t = {}) {
    let n = new Rt(this, t, !0);
    return n.addAll(e, b.none, t.from, t.to), x.maxOpen(n.finish());
  }
  /**
  @internal
  */
  matchTag(e, t, n) {
    for (let i = n ? this.tags.indexOf(n) + 1 : 0; i < this.tags.length; i++) {
      let s = this.tags[i];
      if (Br(e, s.tag) && (s.namespace === void 0 || e.namespaceURI == s.namespace) && (!s.context || t.matchesContext(s.context))) {
        if (s.getAttrs) {
          let o = s.getAttrs(e);
          if (o === !1)
            continue;
          s.attrs = o || void 0;
        }
        return s;
      }
    }
  }
  /**
  @internal
  */
  matchStyle(e, t, n, i) {
    for (let s = i ? this.styles.indexOf(i) + 1 : 0; s < this.styles.length; s++) {
      let o = this.styles[s], l = o.style;
      if (!(l.indexOf(e) != 0 || o.context && !n.matchesContext(o.context) || // Test that the style string either precisely matches the prop,
      // or has an '=' sign after the prop, followed by the given
      // value.
      l.length > e.length && (l.charCodeAt(e.length) != 61 || l.slice(e.length + 1) != t))) {
        if (o.getAttrs) {
          let a = o.getAttrs(t);
          if (a === !1)
            continue;
          o.attrs = a || void 0;
        }
        return o;
      }
    }
  }
  /**
  @internal
  */
  static schemaRules(e) {
    let t = [];
    function n(i) {
      let s = i.priority == null ? 50 : i.priority, o = 0;
      for (; o < t.length; o++) {
        let l = t[o];
        if ((l.priority == null ? 50 : l.priority) < s)
          break;
      }
      t.splice(o, 0, i);
    }
    for (let i in e.marks) {
      let s = e.marks[i].spec.parseDOM;
      s && s.forEach((o) => {
        n(o = zt(o)), o.mark || o.ignore || o.clearMark || (o.mark = i);
      });
    }
    for (let i in e.nodes) {
      let s = e.nodes[i].spec.parseDOM;
      s && s.forEach((o) => {
        n(o = zt(o)), o.node || o.ignore || o.mark || (o.node = i);
      });
    }
    return t;
  }
  /**
  Construct a DOM parser using the parsing rules listed in a
  schema's [node specs](https://prosemirror.net/docs/ref/#model.NodeSpec.parseDOM), reordered by
  [priority](https://prosemirror.net/docs/ref/#model.GenericParseRule.priority).
  */
  static fromSchema(e) {
    return e.cached.domParser || (e.cached.domParser = new oe(e, oe.schemaRules(e)));
  }
}
const pn = {
  address: !0,
  article: !0,
  aside: !0,
  blockquote: !0,
  body: !0,
  canvas: !0,
  dd: !0,
  div: !0,
  dl: !0,
  fieldset: !0,
  figcaption: !0,
  figure: !0,
  footer: !0,
  form: !0,
  h1: !0,
  h2: !0,
  h3: !0,
  h4: !0,
  h5: !0,
  h6: !0,
  header: !0,
  hgroup: !0,
  hr: !0,
  li: !0,
  noscript: !0,
  ol: !0,
  output: !0,
  p: !0,
  pre: !0,
  section: !0,
  table: !0,
  tfoot: !0,
  ul: !0
}, Rr = {
  head: !0,
  noscript: !0,
  object: !0,
  script: !0,
  style: !0,
  title: !0
}, mn = { ol: !0, ul: !0 }, ke = 1, at = 2, me = 4;
function Nt(r, e, t) {
  return e != null ? (e ? ke : 0) | (e === "full" ? at : 0) : r && r.whitespace == "pre" ? ke | at : t & ~me;
}
class Me {
  constructor(e, t, n, i, s, o) {
    this.type = e, this.attrs = t, this.marks = n, this.solid = i, this.options = o, this.content = [], this.activeMarks = b.none, this.match = s || (o & me ? null : e.contentMatch);
  }
  findWrapping(e) {
    if (!this.match) {
      if (!this.type)
        return [];
      let t = this.type.contentMatch.fillBefore(y.from(e));
      if (t)
        this.match = this.type.contentMatch.matchFragment(t);
      else {
        let n = this.type.contentMatch, i;
        return (i = n.findWrapping(e.type)) ? (this.match = n, i) : null;
      }
    }
    return this.match.findWrapping(e.type);
  }
  finish(e) {
    if (!(this.options & ke)) {
      let n = this.content[this.content.length - 1], i;
      if (n && n.isText && (i = /[ \t\r\n\u000c]+$/.exec(n.text))) {
        let s = n;
        n.text.length == i[0].length ? this.content.pop() : this.content[this.content.length - 1] = s.withText(s.text.slice(0, s.text.length - i[0].length));
      }
    }
    let t = y.from(this.content);
    return !e && this.match && (t = t.append(this.match.fillBefore(y.empty, !0))), this.type ? this.type.create(this.attrs, t, this.marks) : t;
  }
  inlineContext(e) {
    return this.type ? this.type.inlineContent : this.content.length ? this.content[0].isInline : e.parentNode && !pn.hasOwnProperty(e.parentNode.nodeName.toLowerCase());
  }
}
class Rt {
  constructor(e, t, n) {
    this.parser = e, this.options = t, this.isOpen = n, this.open = 0, this.localPreserveWS = !1;
    let i = t.topNode, s, o = Nt(null, t.preserveWhitespace, 0) | (n ? me : 0);
    i ? s = new Me(i.type, i.attrs, b.none, !0, t.topMatch || i.type.contentMatch, o) : n ? s = new Me(null, null, b.none, !0, null, o) : s = new Me(e.schema.topNodeType, null, b.none, !0, null, o), this.nodes = [s], this.find = t.findPositions, this.needsBlock = !1;
  }
  get top() {
    return this.nodes[this.open];
  }
  // Add a DOM node to the content. Text is inserted as text node,
  // otherwise, the node is passed to `addElement` or, if it has a
  // `style` attribute, `addElementWithStyles`.
  addDOM(e, t) {
    e.nodeType == 3 ? this.addTextNode(e, t) : e.nodeType == 1 && this.addElement(e, t);
  }
  addTextNode(e, t) {
    let n = e.nodeValue, i = this.top, s = i.options & at ? "full" : this.localPreserveWS || (i.options & ke) > 0, { schema: o } = this.parser;
    if (s === "full" || i.inlineContext(e) || /[^ \t\r\n\u000c]/.test(n)) {
      if (s)
        if (s === "full")
          n = n.replace(/\r\n?/g, `
`);
        else if (o.linebreakReplacement && /[\r\n]/.test(n) && this.top.findWrapping(o.linebreakReplacement.create())) {
          let l = n.split(/\r?\n|\r/);
          for (let a = 0; a < l.length; a++)
            a && this.insertNode(o.linebreakReplacement.create(), t, !0), l[a] && this.insertNode(o.text(l[a]), t, !/\S/.test(l[a]));
          n = "";
        } else
          n = n.replace(/\r?\n|\r/g, " ");
      else if (n = n.replace(/[ \t\r\n\u000c]+/g, " "), /^[ \t\r\n\u000c]/.test(n) && this.open == this.nodes.length - 1) {
        let l = i.content[i.content.length - 1], a = e.previousSibling;
        (!l || a && a.nodeName == "BR" || l.isText && /[ \t\r\n\u000c]$/.test(l.text)) && (n = n.slice(1));
      }
      n && this.insertNode(o.text(n), t, !/\S/.test(n)), this.findInText(e);
    } else
      this.findInside(e);
  }
  // Try to find a handler for the given tag and use that to parse. If
  // none is found, the element's content nodes are added directly.
  addElement(e, t, n) {
    let i = this.localPreserveWS, s = this.top;
    (e.tagName == "PRE" || /pre/.test(e.style && e.style.whiteSpace)) && (this.localPreserveWS = !0);
    let o = e.nodeName.toLowerCase(), l;
    mn.hasOwnProperty(o) && this.parser.normalizeLists && zr(e);
    let a = this.options.ruleFromNode && this.options.ruleFromNode(e) || (l = this.parser.matchTag(e, this, n));
    e: if (a ? a.ignore : Rr.hasOwnProperty(o))
      this.findInside(e), this.ignoreFallback(e, t);
    else if (!a || a.skip || a.closeParent) {
      a && a.closeParent ? this.open = Math.max(0, this.open - 1) : a && a.skip.nodeType && (e = a.skip);
      let c, f = this.needsBlock;
      if (pn.hasOwnProperty(o))
        s.content.length && s.content[0].isInline && this.open && (this.open--, s = this.top), c = !0, s.type || (this.needsBlock = !0);
      else if (!e.firstChild) {
        this.leafFallback(e, t);
        break e;
      }
      let u = a && a.skip ? t : this.readStyles(e, t);
      u && this.addAll(e, u), c && this.sync(s), this.needsBlock = f;
    } else {
      let c = this.readStyles(e, t);
      c && this.addElementByRule(e, a, c, a.consuming === !1 ? l : void 0);
    }
    this.localPreserveWS = i;
  }
  // Called for leaf DOM nodes that would otherwise be ignored
  leafFallback(e, t) {
    e.nodeName == "BR" && this.top.type && this.top.type.inlineContent && this.addTextNode(e.ownerDocument.createTextNode(`
`), t);
  }
  // Called for ignored nodes
  ignoreFallback(e, t) {
    e.nodeName == "BR" && (!this.top.type || !this.top.type.inlineContent) && this.findPlace(this.parser.schema.text("-"), t, !0);
  }
  // Run any style parser associated with the node's styles. Either
  // return an updated array of marks, or null to indicate some of the
  // styles had a rule with `ignore` set.
  readStyles(e, t) {
    let n = e.style;
    if (n && n.length)
      for (let i = 0; i < this.parser.matchedStyles.length; i++) {
        let s = this.parser.matchedStyles[i], o = n.getPropertyValue(s);
        if (o)
          for (let l = void 0; ; ) {
            let a = this.parser.matchStyle(s, o, this, l);
            if (!a)
              break;
            if (a.ignore)
              return null;
            if (a.clearMark ? t = t.filter((c) => !a.clearMark(c)) : t = t.concat(this.parser.schema.marks[a.mark].create(a.attrs)), a.consuming === !1)
              l = a;
            else
              break;
          }
      }
    return t;
  }
  // Look up a handler for the given node. If none are found, return
  // false. Otherwise, apply it, use its return value to drive the way
  // the node's content is wrapped, and return true.
  addElementByRule(e, t, n, i) {
    let s, o;
    if (t.node)
      if (o = this.parser.schema.nodes[t.node], o.isLeaf)
        this.insertNode(o.create(t.attrs), n, e.nodeName == "BR") || this.leafFallback(e, n);
      else {
        let a = this.enter(o, t.attrs || null, n, t.preserveWhitespace);
        a && (s = !0, n = a);
      }
    else {
      let a = this.parser.schema.marks[t.mark];
      n = n.concat(a.create(t.attrs));
    }
    let l = this.top;
    if (o && o.isLeaf)
      this.findInside(e);
    else if (i)
      this.addElement(e, n, i);
    else if (t.getContent)
      this.findInside(e), t.getContent(e, this.parser.schema).forEach((a) => this.insertNode(a, n, !1));
    else {
      let a = e;
      typeof t.contentElement == "string" ? a = e.querySelector(t.contentElement) : typeof t.contentElement == "function" ? a = t.contentElement(e) : t.contentElement && (a = t.contentElement), this.findAround(e, a, !0), this.addAll(a, n), this.findAround(e, a, !1);
    }
    s && this.sync(l) && this.open--;
  }
  // Add all child nodes between `startIndex` and `endIndex` (or the
  // whole node, if not given). If `sync` is passed, use it to
  // synchronize after every block element.
  addAll(e, t, n, i) {
    let s = n || 0;
    for (let o = n ? e.childNodes[n] : e.firstChild, l = i == null ? null : e.childNodes[i]; o != l; o = o.nextSibling, ++s)
      this.findAtPoint(e, s), this.addDOM(o, t);
    this.findAtPoint(e, s);
  }
  // Try to find a way to fit the given node type into the current
  // context. May add intermediate wrappers and/or leave non-solid
  // nodes that we're in.
  findPlace(e, t, n) {
    let i, s;
    for (let o = this.open, l = 0; o >= 0; o--) {
      let a = this.nodes[o], c = a.findWrapping(e);
      if (c && (!i || i.length > c.length + l) && (i = c, s = a, !c.length))
        break;
      if (a.solid) {
        if (n)
          break;
        l += 2;
      }
    }
    if (!i)
      return null;
    this.sync(s);
    for (let o = 0; o < i.length; o++)
      t = this.enterInner(i[o], null, t, !1);
    return t;
  }
  // Try to insert the given node, adjusting the context when needed.
  insertNode(e, t, n) {
    if (e.isInline && this.needsBlock && !this.top.type) {
      let s = this.textblockFromContext();
      s && (t = this.enterInner(s, null, t));
    }
    let i = this.findPlace(e, t, n);
    if (i) {
      this.closeExtra();
      let s = this.top;
      s.match && (s.match = s.match.matchType(e.type));
      let o = b.none;
      for (let l of i.concat(e.marks))
        (s.type ? s.type.allowsMarkType(l.type) : Bt(l.type, e.type)) && (o = l.addToSet(o));
      return s.content.push(e.mark(o)), !0;
    }
    return !1;
  }
  // Try to start a node of the given type, adjusting the context when
  // necessary.
  enter(e, t, n, i) {
    let s = this.findPlace(e.create(t), n, !1);
    return s && (s = this.enterInner(e, t, n, !0, i)), s;
  }
  // Open a node of the given type
  enterInner(e, t, n, i = !1, s) {
    this.closeExtra();
    let o = this.top;
    o.match = o.match && o.match.matchType(e);
    let l = Nt(e, s, o.options);
    o.options & me && o.content.length == 0 && (l |= me);
    let a = b.none;
    return n = n.filter((c) => (o.type ? o.type.allowsMarkType(c.type) : Bt(c.type, e)) ? (a = c.addToSet(a), !1) : !0), this.nodes.push(new Me(e, t, a, i, null, l)), this.open++, n;
  }
  // Make sure all nodes above this.open are finished and added to
  // their parents
  closeExtra(e = !1) {
    let t = this.nodes.length - 1;
    if (t > this.open) {
      for (; t > this.open; t--)
        this.nodes[t - 1].content.push(this.nodes[t].finish(e));
      this.nodes.length = this.open + 1;
    }
  }
  finish() {
    return this.open = 0, this.closeExtra(this.isOpen), this.nodes[0].finish(!!(this.isOpen || this.options.topOpen));
  }
  sync(e) {
    for (let t = this.open; t >= 0; t--) {
      if (this.nodes[t] == e)
        return this.open = t, !0;
      this.localPreserveWS && (this.nodes[t].options |= ke);
    }
    return !1;
  }
  get currentPos() {
    this.closeExtra();
    let e = 0;
    for (let t = this.open; t >= 0; t--) {
      let n = this.nodes[t].content;
      for (let i = n.length - 1; i >= 0; i--)
        e += n[i].nodeSize;
      t && e++;
    }
    return e;
  }
  findAtPoint(e, t) {
    if (this.find)
      for (let n = 0; n < this.find.length; n++)
        this.find[n].node == e && this.find[n].offset == t && (this.find[n].pos = this.currentPos);
  }
  findInside(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].pos == null && e.nodeType == 1 && e.contains(this.find[t].node) && (this.find[t].pos = this.currentPos);
  }
  findAround(e, t, n) {
    if (e != t && this.find)
      for (let i = 0; i < this.find.length; i++)
        this.find[i].pos == null && e.nodeType == 1 && e.contains(this.find[i].node) && t.compareDocumentPosition(this.find[i].node) & (n ? 2 : 4) && (this.find[i].pos = this.currentPos);
  }
  findInText(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].node == e && (this.find[t].pos = this.currentPos - (e.nodeValue.length - this.find[t].offset));
  }
  // Determines whether the given context string matches this context.
  matchesContext(e) {
    if (e.indexOf("|") > -1)
      return e.split(/\s*\|\s*/).some(this.matchesContext, this);
    let t = e.split("/"), n = this.options.context, i = !this.isOpen && (!n || n.parent.type == this.nodes[0].type), s = -(n ? n.depth + 1 : 0) + (i ? 0 : 1), o = (l, a) => {
      for (; l >= 0; l--) {
        let c = t[l];
        if (c == "") {
          if (l == t.length - 1 || l == 0)
            continue;
          for (; a >= s; a--)
            if (o(l - 1, a))
              return !0;
          return !1;
        } else {
          let f = a > 0 || a == 0 && i ? this.nodes[a].type : n && a >= s ? n.node(a - s).type : null;
          if (!f || f.name != c && !f.isInGroup(c))
            return !1;
          a--;
        }
      }
      return !0;
    };
    return o(t.length - 1, this.open);
  }
  textblockFromContext() {
    let e = this.options.context;
    if (e)
      for (let t = e.depth; t >= 0; t--) {
        let n = e.node(t).contentMatchAt(e.indexAfter(t)).defaultType;
        if (n && n.isTextblock && n.defaultAttrs)
          return n;
      }
    for (let t in this.parser.schema.nodes) {
      let n = this.parser.schema.nodes[t];
      if (n.isTextblock && n.defaultAttrs)
        return n;
    }
  }
}
function zr(r) {
  for (let e = r.firstChild, t = null; e; e = e.nextSibling) {
    let n = e.nodeType == 1 ? e.nodeName.toLowerCase() : null;
    n && mn.hasOwnProperty(n) && t ? (t.appendChild(e), e = t) : n == "li" ? t = e : n && (t = null);
  }
}
function Br(r, e) {
  return (r.matches || r.msMatchesSelector || r.webkitMatchesSelector || r.mozMatchesSelector).call(r, e);
}
function zt(r) {
  let e = {};
  for (let t in r)
    e[t] = r[t];
  return e;
}
function Bt(r, e) {
  let t = e.schema.nodes;
  for (let n in t) {
    let i = t[n];
    if (!i.allowsMarkType(r))
      continue;
    let s = [], o = (l) => {
      s.push(l);
      for (let a = 0; a < l.edgeCount; a++) {
        let { type: c, next: f } = l.edge(a);
        if (c == e || s.indexOf(f) < 0 && o(f))
          return !0;
      }
    };
    if (o(i.contentMatch))
      return !0;
  }
}
const gn = 65535, yn = Math.pow(2, 16);
function Fr(r, e) {
  return r + e * yn;
}
function Ft(r) {
  return r & gn;
}
function Pr(r) {
  return (r - (r & gn)) / yn;
}
const xn = 1, wn = 2, Re = 4, kn = 8;
class Pt {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.pos = e, this.delInfo = t, this.recover = n;
  }
  /**
  Tells you whether the position was deleted, that is, whether the
  step removed the token on the side queried (via the `assoc`)
  argument from the document.
  */
  get deleted() {
    return (this.delInfo & kn) > 0;
  }
  /**
  Tells you whether the token before the mapped position was deleted.
  */
  get deletedBefore() {
    return (this.delInfo & (xn | Re)) > 0;
  }
  /**
  True when the token after the mapped position was deleted.
  */
  get deletedAfter() {
    return (this.delInfo & (wn | Re)) > 0;
  }
  /**
  Tells whether any of the steps mapped through deletes across the
  position (including both the token before and after the
  position).
  */
  get deletedAcross() {
    return (this.delInfo & Re) > 0;
  }
}
class D {
  /**
  Create a position map. The modifications to the document are
  represented as an array of numbers, in which each group of three
  represents a modified chunk as `[start, oldSize, newSize]`.
  */
  constructor(e, t = !1) {
    if (this.ranges = e, this.inverted = t, !e.length && D.empty)
      return D.empty;
  }
  /**
  @internal
  */
  recover(e) {
    let t = 0, n = Ft(e);
    if (!this.inverted)
      for (let i = 0; i < n; i++)
        t += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[n * 3] + t + Pr(e);
  }
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  map(e, t = 1) {
    return this._map(e, t, !0);
  }
  /**
  @internal
  */
  _map(e, t, n) {
    let i = 0, s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? i : 0);
      if (a > e)
        break;
      let c = this.ranges[l + s], f = this.ranges[l + o], u = a + c;
      if (e <= u) {
        let d = c ? e == a ? -1 : e == u ? 1 : t : t, h = a + i + (d < 0 ? 0 : f);
        if (n)
          return h;
        let g = e == (t < 0 ? a : u) ? null : Fr(l / 3, e - a), p = 0;
        return c && (p |= e == a ? wn : e == u ? xn : Re, (t < 0 ? e != a : e != u) && (p |= kn)), new Pt(h, p, g);
      }
      i += f - c;
    }
    return n ? e + i : new Pt(e + i, 0, null);
  }
  /**
  @internal
  */
  touches(e, t) {
    let n = 0, i = Ft(t), s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? n : 0);
      if (a > e)
        break;
      let c = this.ranges[l + s], f = a + c;
      if (e <= f && l == i * 3)
        return !0;
      n += this.ranges[l + o] - c;
    }
    return !1;
  }
  /**
  Calls the given function on each of the changed ranges included in
  this map.
  */
  forEach(e) {
    let t = this.inverted ? 2 : 1, n = this.inverted ? 1 : 2;
    for (let i = 0, s = 0; i < this.ranges.length; i += 3) {
      let o = this.ranges[i], l = o - (this.inverted ? s : 0), a = o + (this.inverted ? 0 : s), c = this.ranges[i + t], f = this.ranges[i + n];
      e(l, l + c, a, a + f), s += f - c;
    }
  }
  /**
  Create an inverted version of this map. The result can be used to
  map positions in the post-step document to the pre-step document.
  */
  invert() {
    return new D(this.ranges, !this.inverted);
  }
  /**
  @internal
  */
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  /**
  Create a map that moves all positions by offset `n` (which may be
  negative). This can be useful when applying steps meant for a
  sub-document to a larger document, or vice-versa.
  */
  static offset(e) {
    return e == 0 ? D.empty : new D(e < 0 ? [0, -e, 0] : [0, 0, e]);
  }
}
D.empty = new D([]);
const Qe = /* @__PURE__ */ Object.create(null);
class M {
  /**
  Get the step map that represents the changes made by this step,
  and which can be used to transform between positions in the old
  and the new document.
  */
  getMap() {
    return D.empty;
  }
  /**
  Try to merge this step with another one, to be applied directly
  after it. Returns the merged step when possible, null if the
  steps can't be merged.
  */
  merge(e) {
    return null;
  }
  /**
  Deserialize a step from its JSON representation. Will call
  through to the step class' own implementation of this method.
  */
  static fromJSON(e, t) {
    if (!t || !t.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let n = Qe[t.stepType];
    if (!n)
      throw new RangeError(`No step type ${t.stepType} defined`);
    return n.fromJSON(e, t);
  }
  /**
  To be able to serialize steps to JSON, each step needs a string
  ID to attach to its JSON representation. Use this method to
  register an ID for your step classes. Try to pick something
  that's unlikely to clash with steps from other modules.
  */
  static jsonID(e, t) {
    if (e in Qe)
      throw new RangeError("Duplicate use of step JSON ID " + e);
    return Qe[e] = t, t.prototype.jsonID = e, t;
  }
}
class A {
  /**
  @internal
  */
  constructor(e, t) {
    this.doc = e, this.failed = t;
  }
  /**
  Create a successful step result.
  */
  static ok(e) {
    return new A(e, null);
  }
  /**
  Create a failed step result.
  */
  static fail(e) {
    return new A(null, e);
  }
  /**
  Call [`Node.replace`](https://prosemirror.net/docs/ref/#model.Node.replace) with the given
  arguments. Create a successful result if it succeeds, and a
  failed one if it throws a `ReplaceError`.
  */
  static fromReplace(e, t, n, i) {
    try {
      return A.ok(e.replace(t, n, i));
    } catch (s) {
      if (s instanceof ye)
        return A.fail(s.message);
      throw s;
    }
  }
}
function ht(r, e, t) {
  let n = [];
  for (let i = 0; i < r.childCount; i++) {
    let s = r.child(i);
    s.content.size && (s = s.copy(ht(s.content, e, s))), s.isInline && (s = e(s, t, i)), n.push(s);
  }
  return y.fromArray(n);
}
class H extends M {
  /**
  Create a mark step.
  */
  constructor(e, t, n) {
    super(), this.from = e, this.to = t, this.mark = n;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), n = e.resolve(this.from), i = n.node(n.sharedDepth(this.to)), s = new x(ht(t.content, (o, l) => !o.isAtom || !l.type.allowsMarkType(this.mark.type) ? o : o.mark(this.mark.addToSet(o.marks)), i), t.openStart, t.openEnd);
    return A.fromReplace(e, this.from, this.to, s);
  }
  invert(e) {
    let t = [];
    return e.nodesBetween(this.from, this.to, (n, i) => {
      if (n.isInline && n.isAtom) {
        let s = this.mark.addToSet(n.marks);
        if (!b.sameSet(s, n.marks)) {
          let o = Math.max(this.from, i), l = Math.min(this.to, i + n.nodeSize);
          ct(K, o, l, this.mark, t);
          for (let a of n.marks)
            a.isInSet(s) || ct(H, o, l, a, t);
        }
      }
    }), t.length == 1 ? t[0] : new ee(t);
  }
  map(e) {
    let t = e.map(this.from, 1), n = e.map(this.to, -1);
    return t >= n ? null : new H(t, n, this.mark);
  }
  merge(e) {
    return e instanceof H && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new H(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new H(t.from, t.to, e.markFromJSON(t.mark));
  }
}
M.jsonID("addMark", H);
class K extends M {
  /**
  Create a mark-removing step.
  */
  constructor(e, t, n) {
    super(), this.from = e, this.to = t, this.mark = n;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), n = new x(ht(t.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), e), t.openStart, t.openEnd);
    return A.fromReplace(e, this.from, this.to, n);
  }
  invert(e) {
    let t = [];
    return e.nodesBetween(this.from, this.to, (n, i) => {
      n.isInline && n.isAtom && this.mark.isInSet(n.marks) && ct(H, Math.max(this.from, i), Math.min(this.to, i + n.nodeSize), this.mark, t);
    }), t.length == 1 ? t[0] : new ee(t);
  }
  map(e) {
    let t = e.map(this.from, 1), n = e.map(this.to, -1);
    return t >= n ? null : new K(t, n, this.mark);
  }
  merge(e) {
    return e instanceof K && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new K(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new K(t.from, t.to, e.markFromJSON(t.mark));
  }
}
M.jsonID("removeMark", K);
function ct(r, e, t, n, i) {
  let s = i.length ? i[i.length - 1] : null;
  s && s instanceof r && s.to == e && s.mark.eq(n) ? i[i.length - 1] = new r(s.from, t, n) : i.push(new r(e, t, n));
}
class ee extends M {
  constructor(e) {
    super(), this.steps = e;
  }
  apply(e) {
    for (let t of this.steps) {
      let n = t.apply(e);
      if (!n.doc)
        return n;
      e = n.doc;
    }
    return new A(e, null);
  }
  invert(e) {
    return new ee(this.steps.map((t) => t.invert(e)));
  }
  map(e) {
    let t = [];
    for (let n of this.steps) {
      let i = n.map(e);
      i && t.push(i);
    }
    return t.length ? new ee(t) : null;
  }
  toJSON() {
    return { stepType: "markSet", steps: this.steps.map((e) => e.toJSON()) };
  }
  static fromJSON(e, t) {
    if (!Array.isArray(t.steps) || !t.steps.every((n) => n.stepType == "addMark" || n.stepType == "removeMark"))
      throw new RangeError("Invalid JSON for MarkSetStep");
    return new ee(t.steps.map((n) => M.fromJSON(e, n)));
  }
}
M.jsonID("markSet", ee);
class Z extends M {
  /**
  Create a node mark step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return A.fail("No node at mark step's position");
    let n = t.type.create(t.attrs, null, this.mark.addToSet(t.marks));
    return A.fromReplace(e, this.pos, this.pos + 1, new x(y.from(n), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    if (t) {
      let n = this.mark.addToSet(t.marks);
      if (n.length == t.marks.length) {
        for (let i = 0; i < t.marks.length; i++)
          if (!t.marks[i].isInSet(n))
            return new Z(this.pos, t.marks[i]);
        return new Z(this.pos, this.mark);
      }
    }
    return new be(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new Z(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new Z(t.pos, e.markFromJSON(t.mark));
  }
}
M.jsonID("addNodeMark", Z);
class be extends M {
  /**
  Create a mark-removing step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return A.fail("No node at mark step's position");
    let n = t.type.create(t.attrs, null, this.mark.removeFromSet(t.marks));
    return A.fromReplace(e, this.pos, this.pos + 1, new x(y.from(n), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    return !t || !this.mark.isInSet(t.marks) ? this : new Z(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new be(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new be(t.pos, e.markFromJSON(t.mark));
  }
}
M.jsonID("removeNodeMark", be);
class F extends M {
  /**
  The given `slice` should fit the 'gap' between `from` and
  `to`—the depths must line up, and the surrounding nodes must be
  able to be joined with the open sides of the slice. When
  `structure` is true, the step will fail if the content between
  from and to is not just a sequence of closing and then opening
  tokens (this is to guard against rebased replace steps
  overwriting something they weren't supposed to).
  */
  constructor(e, t, n, i = !1) {
    super(), this.from = e, this.to = t, this.slice = n, this.structure = i;
  }
  apply(e) {
    return this.structure && ft(e, this.from, this.to) ? A.fail("Structure replace would overwrite content") : A.fromReplace(e, this.from, this.to, this.slice);
  }
  getMap() {
    return new D([this.from, this.to - this.from, this.slice.size]);
  }
  invert(e) {
    return new F(this.from, this.from + this.slice.size, e.slice(this.from, this.to));
  }
  map(e) {
    let t = e.mapResult(this.to, -1), n = this.from == this.to && F.MAP_BIAS < 0 ? t : e.mapResult(this.from, 1);
    return n.deletedAcross && t.deletedAcross ? null : new F(n.pos, Math.max(n.pos, t.pos), this.slice, this.structure);
  }
  merge(e) {
    if (!(e instanceof F) || e.structure || this.structure)
      return null;
    if (this.from + this.slice.size == e.from && !this.slice.openEnd && !e.slice.openStart) {
      let t = this.slice.size + e.slice.size == 0 ? x.empty : new x(this.slice.content.append(e.slice.content), this.slice.openStart, e.slice.openEnd);
      return new F(this.from, this.to + (e.to - e.from), t, this.structure);
    } else if (e.to == this.from && !this.slice.openStart && !e.slice.openEnd) {
      let t = this.slice.size + e.slice.size == 0 ? x.empty : new x(e.slice.content.append(this.slice.content), e.slice.openStart, this.slice.openEnd);
      return new F(e.from, this.to, t, this.structure);
    } else
      return null;
  }
  toJSON() {
    let e = { stepType: "replace", from: this.from, to: this.to };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new F(t.from, t.to, x.fromJSON(e, t.slice), !!t.structure);
  }
}
F.MAP_BIAS = 1;
M.jsonID("replace", F);
class P extends M {
  /**
  Create a replace-around step with the given range and gap.
  `insert` should be the point in the slice into which the content
  of the gap should be moved. `structure` has the same meaning as
  it has in the [`ReplaceStep`](https://prosemirror.net/docs/ref/#transform.ReplaceStep) class.
  */
  constructor(e, t, n, i, s, o, l = !1) {
    super(), this.from = e, this.to = t, this.gapFrom = n, this.gapTo = i, this.slice = s, this.insert = o, this.structure = l;
  }
  apply(e) {
    if (this.structure && (ft(e, this.from, this.gapFrom) || ft(e, this.gapTo, this.to)))
      return A.fail("Structure gap-replace would overwrite content");
    let t = e.slice(this.gapFrom, this.gapTo);
    if (t.openStart || t.openEnd)
      return A.fail("Gap is not a flat range");
    let n = this.slice.insertAt(this.insert, t.content);
    return n ? A.fromReplace(e, this.from, this.to, n) : A.fail("Content does not fit in gap");
  }
  getMap() {
    return new D([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert
    ]);
  }
  invert(e) {
    let t = this.gapTo - this.gapFrom;
    return new P(this.from, this.from + this.slice.size + t, this.from + this.insert, this.from + this.insert + t, e.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), n = e.mapResult(this.to, -1), i = this.from == this.gapFrom ? t.pos : e.map(this.gapFrom, -1), s = this.to == this.gapTo ? n.pos : e.map(this.gapTo, 1);
    return t.deletedAcross && n.deletedAcross || i < t.pos || s > n.pos || i > s ? null : new P(t.pos, n.pos, i, s, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let e = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert
    };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number" || typeof t.gapFrom != "number" || typeof t.gapTo != "number" || typeof t.insert != "number")
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new P(t.from, t.to, t.gapFrom, t.gapTo, x.fromJSON(e, t.slice), t.insert, !!t.structure);
  }
}
M.jsonID("replaceAround", P);
function ft(r, e, t) {
  let n = r.resolve(e), i = t - e, s = n.depth;
  for (; i > 0 && s > 0 && n.indexAfter(s) == n.node(s).childCount; )
    s--, i--;
  if (i > 0) {
    let o = n.node(s).maybeChild(n.indexAfter(s));
    for (; i > 0; ) {
      if (!o || o.isLeaf)
        return !0;
      o = o.firstChild, i--;
    }
  }
  return !1;
}
function Dr(r, e, t) {
  return (e == 0 || r.canReplace(e, r.childCount)) && (t == r.childCount || r.canReplace(0, t));
}
function fe(r) {
  let t = r.parent.content.cutByIndex(r.startIndex, r.endIndex);
  for (let n = r.depth, i = 0, s = 0; ; --n) {
    let o = r.$from.node(n), l = r.$from.index(n) + i, a = r.$to.indexAfter(n) - s;
    if (n < r.depth && o.canReplace(l, a, t))
      return n;
    if (n == 0 || o.type.spec.isolating || !Dr(o, l, a))
      break;
    l && (i = 1), a < o.childCount && (s = 1);
  }
  return null;
}
function bn(r, e, t = null, n = r) {
  let i = $r(r, e), s = i && Lr(n, e);
  return s ? i.map(Dt).concat({ type: e, attrs: t }).concat(s.map(Dt)) : null;
}
function Dt(r) {
  return { type: r, attrs: null };
}
function $r(r, e) {
  let { parent: t, startIndex: n, endIndex: i } = r, s = t.contentMatchAt(n).findWrapping(e);
  if (!s)
    return null;
  let o = s.length ? s[0] : e;
  return t.canReplaceWith(n, i, o) ? s : null;
}
function Lr(r, e) {
  let { parent: t, startIndex: n, endIndex: i } = r, s = t.child(n), o = e.contentMatch.findWrapping(s.type);
  if (!o)
    return null;
  let a = (o.length ? o[o.length - 1] : e).contentMatch;
  for (let c = n; a && c < i; c++)
    a = a.matchType(t.child(c).type);
  return !a || !a.validEnd ? null : o;
}
function q(r, e, t = 1, n) {
  let i = r.resolve(e), s = i.depth - t, o = n && n[n.length - 1] || i.parent;
  if (s < 0 || i.parent.type.spec.isolating || !i.parent.canReplace(i.index(), i.parent.childCount) || !o.type.validContent(i.parent.content.cutByIndex(i.index(), i.parent.childCount)))
    return !1;
  for (let c = i.depth - 1, f = t - 2; c > s; c--, f--) {
    let u = i.node(c), d = i.index(c);
    if (u.type.spec.isolating)
      return !1;
    let h = u.content.cutByIndex(d, u.childCount), g = n && n[f + 1];
    g && (h = h.replaceChild(0, g.type.create(g.attrs)));
    let p = n && n[f] || u;
    if (!u.canReplace(d + 1, u.childCount) || !p.type.validContent(h))
      return !1;
  }
  let l = i.indexAfter(s), a = n && n[0];
  return i.node(s).canReplaceWith(l, l, a ? a.type : i.node(s + 1).type);
}
function ne(r, e) {
  let t = r.resolve(e), n = t.index();
  return Sn(t.nodeBefore, t.nodeAfter) && t.parent.canReplace(n, n + 1);
}
function jr(r, e) {
  e.content.size || r.type.compatibleContent(e.type);
  let t = r.contentMatchAt(r.childCount), { linebreakReplacement: n } = r.type.schema;
  for (let i = 0; i < e.childCount; i++) {
    let s = e.child(i), o = s.type == n ? r.type.schema.nodes.text : s.type;
    if (t = t.matchType(o), !t || !r.type.allowsMarks(s.marks))
      return !1;
  }
  return t.validEnd;
}
function Sn(r, e) {
  return !!(r && e && !r.isLeaf && jr(r, e));
}
function He(r, e, t = -1) {
  let n = r.resolve(e);
  for (let i = n.depth; ; i--) {
    let s, o, l = n.index(i);
    if (i == n.depth ? (s = n.nodeBefore, o = n.nodeAfter) : t > 0 ? (s = n.node(i + 1), l++, o = n.node(i).maybeChild(l)) : (s = n.node(i).maybeChild(l - 1), o = n.node(i + 1)), s && !s.isTextblock && Sn(s, o) && n.node(i).canReplace(l, l + 1))
      return e;
    if (i == 0)
      break;
    e = t < 0 ? n.before(i) : n.after(i);
  }
}
function dt(r, e, t = e, n = x.empty) {
  if (e == t && !n.size)
    return null;
  let i = r.resolve(e), s = r.resolve(t);
  return Jr(i, s, n) ? new F(e, t, n) : new Wr(i, s, n).fit();
}
function Jr(r, e, t) {
  return !t.openStart && !t.openEnd && r.start() == e.start() && r.parent.canReplace(r.index(), e.index(), t.content);
}
class Wr {
  constructor(e, t, n) {
    this.$from = e, this.$to = t, this.unplaced = n, this.frontier = [], this.placed = y.empty;
    for (let i = 0; i <= e.depth; i++) {
      let s = e.node(i);
      this.frontier.push({
        type: s.type,
        match: s.contentMatchAt(e.indexAfter(i))
      });
    }
    for (let i = e.depth; i > 0; i--)
      this.placed = y.from(e.node(i).copy(this.placed));
  }
  get depth() {
    return this.frontier.length - 1;
  }
  fit() {
    for (; this.unplaced.size; ) {
      let c = this.findFittable();
      c ? this.placeNodes(c) : this.openMore() || this.dropNode();
    }
    let e = this.mustMoveInline(), t = this.placed.size - this.depth - this.$from.depth, n = this.$from, i = this.close(e < 0 ? this.$to : n.doc.resolve(e));
    if (!i)
      return null;
    let s = this.placed, o = n.depth, l = i.depth;
    for (; o && l && s.childCount == 1; )
      s = s.firstChild.content, o--, l--;
    let a = new x(s, o, l);
    return e > -1 ? new P(n.pos, e, this.$to.pos, this.$to.end(), a, t) : a.size || n.pos != this.$to.pos ? new F(n.pos, i.pos, a) : null;
  }
  // Find a position on the start spine of `this.unplaced` that has
  // content that can be moved somewhere on the frontier. Returns two
  // depths, one for the slice and one for the frontier.
  findFittable() {
    let e = this.unplaced.openStart;
    for (let t = this.unplaced.content, n = 0, i = this.unplaced.openEnd; n < e; n++) {
      let s = t.firstChild;
      if (t.childCount > 1 && (i = 0), s.type.spec.isolating && i <= n) {
        e = n;
        break;
      }
      t = s.content;
    }
    for (let t = 1; t <= 2; t++)
      for (let n = t == 1 ? e : this.unplaced.openStart; n >= 0; n--) {
        let i, s = null;
        n ? (s = $t(this.unplaced.content, n - 1).firstChild, i = s.content) : i = this.unplaced.content;
        let o = i.firstChild;
        for (let l = this.depth; l >= 0; l--) {
          let { type: a, match: c } = this.frontier[l], f, u = null;
          if (t == 1 && (o ? c.matchType(o.type) || (u = c.fillBefore(y.from(o), !1)) : s && a.compatibleContent(s.type)))
            return { sliceDepth: n, frontierDepth: l, parent: s, inject: u };
          if (t == 2 && o && (f = c.findWrapping(o.type)))
            return { sliceDepth: n, frontierDepth: l, parent: s, wrap: f };
          if (s && c.matchType(s.type))
            break;
        }
      }
  }
  openMore() {
    let { content: e, openStart: t, openEnd: n } = this.unplaced;
    return Lt(e, -1) <= t ? !1 : (this.unplaced.size > 1 && Lt(e, 1) > n && n++, this.unplaced = new x(e, t + 1, n), !0);
  }
  dropNode() {
    let { content: e, openStart: t, openEnd: n } = this.unplaced, i = $t(e, t);
    if (i.childCount <= 1 && t > 0) {
      let s = e.size - t <= t + i.size;
      this.unplaced = new x(ue(e, t - 1, 1), t - 1, s ? t - 1 : n);
    } else
      this.unplaced = new x(ue(e, t, 1), t, n);
  }
  // Move content from the unplaced slice at `sliceDepth` to the
  // frontier node at `frontierDepth`. Close that frontier node when
  // applicable.
  placeNodes({ sliceDepth: e, frontierDepth: t, parent: n, inject: i, wrap: s }) {
    for (; this.depth > t; )
      this.closeFrontierNode();
    if (s)
      for (let p = 0; p < s.length; p++)
        this.openFrontierNode(s[p]);
    let o = this.unplaced, l = n ? n.content : o.content, a = o.openStart - e, c = 0, f = [], { match: u, type: d } = this.frontier[t];
    if (i) {
      for (let p = 0; p < i.childCount; p++)
        f.push(i.child(p));
      u = u.matchFragment(i);
    }
    let h = l.size + e - (o.content.size - o.openEnd);
    for (; c < l.childCount; ) {
      let p = l.child(c), m = u.matchType(p.type);
      if (!m)
        break;
      c++, (c > 1 || a == 0 || p.content.size) && (u = m, f.push(vn(p.mark(d.allowedMarks(p.marks)), c == 1 ? a : 0, c == l.childCount ? h : -1)));
    }
    let g = c == l.childCount;
    g || (h = -1), this.placed = he(this.placed, t, y.from(f)), this.frontier[t].match = u, g && h < 0 && n && n.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
    for (let p = 0, m = f[f.length - 1]; m && p < h; p++)
      this.frontier.push({ type: m.type, match: m.contentMatchAt(m.childCount) }), m = m.lastChild;
    this.unplaced = g ? e == 0 ? x.empty : new x(ue(o.content, e - 1, 1), e - 1, h < 0 ? o.openEnd : e - 1) : new x(ue(o.content, e, c), e, o.openEnd);
  }
  mustMoveInline() {
    if (!this.$to.parent.isTextblock)
      return -1;
    let e = this.frontier[this.depth], t;
    if (!e.type.isTextblock || !_e(this.$to, this.$to.depth, e.type, e.match, !1) || this.$to.depth == this.depth && (t = this.findCloseLevel(this.$to)) && t.depth == this.depth)
      return -1;
    let { depth: n } = this.$to, i = this.$to.after(n);
    for (; n > 1 && i == this.$to.end(--n); )
      ++i;
    return i;
  }
  findCloseLevel(e) {
    e: for (let t = Math.min(this.depth, e.depth); t >= 0; t--) {
      let { match: n, type: i } = this.frontier[t], s = t < e.depth && e.end(t + 1) == e.pos + (e.depth - (t + 1)), o = _e(e, t, i, n, s);
      if (o) {
        for (let l = t - 1; l >= 0; l--) {
          let { match: a, type: c } = this.frontier[l], f = _e(e, l, c, a, !0);
          if (!f || f.childCount)
            continue e;
        }
        return { depth: t, fit: o, move: s ? e.doc.resolve(e.after(t + 1)) : e };
      }
    }
  }
  close(e) {
    let t = this.findCloseLevel(e);
    if (!t)
      return null;
    for (; this.depth > t.depth; )
      this.closeFrontierNode();
    t.fit.childCount && (this.placed = he(this.placed, t.depth, t.fit)), e = t.move;
    for (let n = t.depth + 1; n <= e.depth; n++) {
      let i = e.node(n), s = i.type.contentMatch.fillBefore(i.content, !0, e.index(n));
      this.openFrontierNode(i.type, i.attrs, s);
    }
    return e;
  }
  openFrontierNode(e, t = null, n) {
    let i = this.frontier[this.depth];
    i.match = i.match.matchType(e), this.placed = he(this.placed, this.depth, y.from(e.create(t, n))), this.frontier.push({ type: e, match: e.contentMatch });
  }
  closeFrontierNode() {
    let t = this.frontier.pop().match.fillBefore(y.empty, !0);
    t.childCount && (this.placed = he(this.placed, this.frontier.length, t));
  }
}
function ue(r, e, t) {
  return e == 0 ? r.cutByIndex(t, r.childCount) : r.replaceChild(0, r.firstChild.copy(ue(r.firstChild.content, e - 1, t)));
}
function he(r, e, t) {
  return e == 0 ? r.append(t) : r.replaceChild(r.childCount - 1, r.lastChild.copy(he(r.lastChild.content, e - 1, t)));
}
function $t(r, e) {
  for (let t = 0; t < e; t++)
    r = r.firstChild.content;
  return r;
}
function vn(r, e, t) {
  if (e <= 0)
    return r;
  let n = r.content;
  return e > 1 && (n = n.replaceChild(0, vn(n.firstChild, e - 1, n.childCount == 1 ? t - 1 : 0))), e > 0 && (n = r.type.contentMatch.fillBefore(n).append(n), t <= 0 && (n = n.append(r.type.contentMatch.matchFragment(n).fillBefore(y.empty, !0)))), r.copy(n);
}
function _e(r, e, t, n, i) {
  let s = r.node(e), o = i ? r.indexAfter(e) : r.index(e);
  if (o == s.childCount && !t.compatibleContent(s.type))
    return null;
  let l = n.fillBefore(s.content, !0, o);
  return l && !Ur(t, s.content, o) ? l : null;
}
function Ur(r, e, t) {
  for (let n = t; n < e.childCount; n++)
    if (!r.allowsMarks(e.child(n).marks))
      return !0;
  return !1;
}
function Lt(r, e) {
  for (let t = 0; ; t++) {
    let n = e < 0 ? r.firstChild : r.lastChild;
    if (!n || n.isAtom)
      return t;
    r = n.content;
  }
}
class ge extends M {
  /**
  Construct an attribute step.
  */
  constructor(e, t, n) {
    super(), this.pos = e, this.attr = t, this.value = n;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return A.fail("No node at attribute step's position");
    let n = /* @__PURE__ */ Object.create(null);
    for (let s in t.attrs)
      n[s] = t.attrs[s];
    n[this.attr] = this.value;
    let i = t.type.create(n, null, t.marks);
    return A.fromReplace(e, this.pos, this.pos + 1, new x(y.from(i), 0, t.isLeaf ? 0 : 1));
  }
  getMap() {
    return D.empty;
  }
  invert(e) {
    return new ge(this.pos, this.attr, e.nodeAt(this.pos).attrs[this.attr]);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new ge(t.pos, this.attr, this.value);
  }
  toJSON() {
    return { stepType: "attr", pos: this.pos, attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number" || typeof t.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new ge(t.pos, t.attr, t.value);
  }
}
M.jsonID("attr", ge);
class Le extends M {
  /**
  Construct an attribute step.
  */
  constructor(e, t) {
    super(), this.attr = e, this.value = t;
  }
  apply(e) {
    let t = /* @__PURE__ */ Object.create(null);
    for (let i in e.attrs)
      t[i] = e.attrs[i];
    t[this.attr] = this.value;
    let n = e.type.create(t, e.content, e.marks);
    return A.ok(n);
  }
  getMap() {
    return D.empty;
  }
  invert(e) {
    return new Le(this.attr, e.attrs[this.attr]);
  }
  map(e) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new Le(t.attr, t.value);
  }
}
M.jsonID("docAttr", Le);
let Se = class extends Error {
};
Se = function r(e) {
  let t = Error.call(this, e);
  return t.__proto__ = r.prototype, t;
};
Se.prototype = Object.create(Error.prototype);
Se.prototype.constructor = Se;
Se.prototype.name = "TransformError";
const et = /* @__PURE__ */ Object.create(null);
class k {
  /**
  Initialize a selection with the head and anchor and ranges. If no
  ranges are given, constructs a single range across `$anchor` and
  `$head`.
  */
  constructor(e, t, n) {
    this.$anchor = e, this.$head = t, this.ranges = n || [new Vr(e.min(t), e.max(t))];
  }
  /**
  The selection's anchor, as an unresolved position.
  */
  get anchor() {
    return this.$anchor.pos;
  }
  /**
  The selection's head.
  */
  get head() {
    return this.$head.pos;
  }
  /**
  The lower bound of the selection's main range.
  */
  get from() {
    return this.$from.pos;
  }
  /**
  The upper bound of the selection's main range.
  */
  get to() {
    return this.$to.pos;
  }
  /**
  The resolved lower  bound of the selection's main range.
  */
  get $from() {
    return this.ranges[0].$from;
  }
  /**
  The resolved upper bound of the selection's main range.
  */
  get $to() {
    return this.ranges[0].$to;
  }
  /**
  Indicates whether the selection contains any content.
  */
  get empty() {
    let e = this.ranges;
    for (let t = 0; t < e.length; t++)
      if (e[t].$from.pos != e[t].$to.pos)
        return !1;
    return !0;
  }
  /**
  Get the content of this selection as a slice.
  */
  content() {
    return this.$from.doc.slice(this.from, this.to, !0);
  }
  /**
  Replace the selection with a slice or, if no slice is given,
  delete the selection. Will append to the given transaction.
  */
  replace(e, t = x.empty) {
    let n = t.content.lastChild, i = null;
    for (let l = 0; l < t.openEnd; l++)
      i = n, n = n.lastChild;
    let s = e.steps.length, o = this.ranges;
    for (let l = 0; l < o.length; l++) {
      let { $from: a, $to: c } = o[l], f = e.mapping.slice(s);
      e.replaceRange(f.map(a.pos), f.map(c.pos), l ? x.empty : t), l == 0 && Wt(e, s, (n ? n.isInline : i && i.isTextblock) ? -1 : 1);
    }
  }
  /**
  Replace the selection with the given node, appending the changes
  to the given transaction.
  */
  replaceWith(e, t) {
    let n = e.steps.length, i = this.ranges;
    for (let s = 0; s < i.length; s++) {
      let { $from: o, $to: l } = i[s], a = e.mapping.slice(n), c = a.map(o.pos), f = a.map(l.pos);
      s ? e.deleteRange(c, f) : (e.replaceRangeWith(c, f, t), Wt(e, n, t.isInline ? -1 : 1));
    }
  }
  /**
  Find a valid cursor or leaf node selection starting at the given
  position and searching back if `dir` is negative, and forward if
  positive. When `textOnly` is true, only consider cursor
  selections. Will return null when no valid selection position is
  found.
  */
  static findFrom(e, t, n = !1) {
    let i = e.parent.inlineContent ? new C(e) : se(e.node(0), e.parent, e.pos, e.index(), t, n);
    if (i)
      return i;
    for (let s = e.depth - 1; s >= 0; s--) {
      let o = t < 0 ? se(e.node(0), e.node(s), e.before(s + 1), e.index(s), t, n) : se(e.node(0), e.node(s), e.after(s + 1), e.index(s) + 1, t, n);
      if (o)
        return o;
    }
    return null;
  }
  /**
  Find a valid cursor or leaf node selection near the given
  position. Searches forward first by default, but if `bias` is
  negative, it will search backwards first.
  */
  static near(e, t = 1) {
    return this.findFrom(e, t) || this.findFrom(e, -t) || new $(e.node(0));
  }
  /**
  Find the cursor or leaf node selection closest to the start of
  the given document. Will return an
  [`AllSelection`](https://prosemirror.net/docs/ref/#state.AllSelection) if no valid position
  exists.
  */
  static atStart(e) {
    return se(e, e, 0, 0, 1) || new $(e);
  }
  /**
  Find the cursor or leaf node selection closest to the end of the
  given document.
  */
  static atEnd(e) {
    return se(e, e, e.content.size, e.childCount, -1) || new $(e);
  }
  /**
  Deserialize the JSON representation of a selection. Must be
  implemented for custom classes (as a static class method).
  */
  static fromJSON(e, t) {
    if (!t || !t.type)
      throw new RangeError("Invalid input for Selection.fromJSON");
    let n = et[t.type];
    if (!n)
      throw new RangeError(`No selection type ${t.type} defined`);
    return n.fromJSON(e, t);
  }
  /**
  To be able to deserialize selections from JSON, custom selection
  classes must register themselves with an ID string, so that they
  can be disambiguated. Try to pick something that's unlikely to
  clash with classes from other modules.
  */
  static jsonID(e, t) {
    if (e in et)
      throw new RangeError("Duplicate use of selection JSON ID " + e);
    return et[e] = t, t.prototype.jsonID = e, t;
  }
  /**
  Get a [bookmark](https://prosemirror.net/docs/ref/#state.SelectionBookmark) for this selection,
  which is a value that can be mapped without having access to a
  current document, and later resolved to a real selection for a
  given document again. (This is used mostly by the history to
  track and restore old selections.) The default implementation of
  this method just converts the selection to a text selection and
  returns the bookmark for that.
  */
  getBookmark() {
    return C.between(this.$anchor, this.$head).getBookmark();
  }
}
k.prototype.visible = !0;
class Vr {
  /**
  Create a range.
  */
  constructor(e, t) {
    this.$from = e, this.$to = t;
  }
}
let jt = !1;
function Jt(r) {
  !jt && !r.parent.inlineContent && (jt = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + r.parent.type.name + ")"));
}
class C extends k {
  /**
  Construct a text selection between the given points.
  */
  constructor(e, t = e) {
    Jt(e), Jt(t), super(e, t);
  }
  /**
  Returns a resolved position if this is a cursor selection (an
  empty text selection), and null otherwise.
  */
  get $cursor() {
    return this.$anchor.pos == this.$head.pos ? this.$head : null;
  }
  map(e, t) {
    let n = e.resolve(t.map(this.head));
    if (!n.parent.inlineContent)
      return k.near(n);
    let i = e.resolve(t.map(this.anchor));
    return new C(i.parent.inlineContent ? i : n, n);
  }
  replace(e, t = x.empty) {
    if (super.replace(e, t), t == x.empty) {
      let n = this.$from.marksAcross(this.$to);
      n && e.ensureMarks(n);
    }
  }
  eq(e) {
    return e instanceof C && e.anchor == this.anchor && e.head == this.head;
  }
  getBookmark() {
    return new Ge(this.anchor, this.head);
  }
  toJSON() {
    return { type: "text", anchor: this.anchor, head: this.head };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number" || typeof t.head != "number")
      throw new RangeError("Invalid input for TextSelection.fromJSON");
    return new C(e.resolve(t.anchor), e.resolve(t.head));
  }
  /**
  Create a text selection from non-resolved positions.
  */
  static create(e, t, n = t) {
    let i = e.resolve(t);
    return new this(i, n == t ? i : e.resolve(n));
  }
  /**
  Return a text selection that spans the given positions or, if
  they aren't text positions, find a text selection near them.
  `bias` determines whether the method searches forward (default)
  or backwards (negative number) first. Will fall back to calling
  [`Selection.near`](https://prosemirror.net/docs/ref/#state.Selection^near) when the document
  doesn't contain a valid text position.
  */
  static between(e, t, n) {
    let i = e.pos - t.pos;
    if ((!n || i) && (n = i >= 0 ? 1 : -1), !t.parent.inlineContent) {
      let s = k.findFrom(t, n, !0) || k.findFrom(t, -n, !0);
      if (s)
        t = s.$head;
      else
        return k.near(t, n);
    }
    return e.parent.inlineContent || (i == 0 ? e = t : (e = (k.findFrom(e, -n, !0) || k.findFrom(e, n, !0)).$anchor, e.pos < t.pos != i < 0 && (e = t))), new C(e, t);
  }
}
k.jsonID("text", C);
class Ge {
  constructor(e, t) {
    this.anchor = e, this.head = t;
  }
  map(e) {
    return new Ge(e.map(this.anchor), e.map(this.head));
  }
  resolve(e) {
    return C.between(e.resolve(this.anchor), e.resolve(this.head));
  }
}
class S extends k {
  /**
  Create a node selection. Does not verify the validity of its
  argument.
  */
  constructor(e) {
    let t = e.nodeAfter, n = e.node(0).resolve(e.pos + t.nodeSize);
    super(e, n), this.node = t;
  }
  map(e, t) {
    let { deleted: n, pos: i } = t.mapResult(this.anchor), s = e.resolve(i);
    return n ? k.near(s) : new S(s);
  }
  content() {
    return new x(y.from(this.node), 0, 0);
  }
  eq(e) {
    return e instanceof S && e.anchor == this.anchor;
  }
  toJSON() {
    return { type: "node", anchor: this.anchor };
  }
  getBookmark() {
    return new pt(this.anchor);
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number")
      throw new RangeError("Invalid input for NodeSelection.fromJSON");
    return new S(e.resolve(t.anchor));
  }
  /**
  Create a node selection from non-resolved positions.
  */
  static create(e, t) {
    return new S(e.resolve(t));
  }
  /**
  Determines whether the given node may be selected as a node
  selection.
  */
  static isSelectable(e) {
    return !e.isText && e.type.spec.selectable !== !1;
  }
}
S.prototype.visible = !1;
k.jsonID("node", S);
class pt {
  constructor(e) {
    this.anchor = e;
  }
  map(e) {
    let { deleted: t, pos: n } = e.mapResult(this.anchor);
    return t ? new Ge(n, n) : new pt(n);
  }
  resolve(e) {
    let t = e.resolve(this.anchor), n = t.nodeAfter;
    return n && S.isSelectable(n) ? new S(t) : k.near(t);
  }
}
class $ extends k {
  /**
  Create an all-selection over the given document.
  */
  constructor(e) {
    super(e.resolve(0), e.resolve(e.content.size));
  }
  replace(e, t = x.empty) {
    if (t == x.empty) {
      e.delete(0, e.doc.content.size);
      let n = k.atStart(e.doc);
      n.eq(e.selection) || e.setSelection(n);
    } else
      super.replace(e, t);
  }
  toJSON() {
    return { type: "all" };
  }
  /**
  @internal
  */
  static fromJSON(e) {
    return new $(e);
  }
  map(e) {
    return new $(e);
  }
  eq(e) {
    return e instanceof $;
  }
  getBookmark() {
    return qr;
  }
}
k.jsonID("all", $);
const qr = {
  map() {
    return this;
  },
  resolve(r) {
    return new $(r);
  }
};
function se(r, e, t, n, i, s = !1) {
  if (e.inlineContent)
    return C.create(r, t);
  for (let o = n - (i > 0 ? 0 : 1); i > 0 ? o < e.childCount : o >= 0; o += i) {
    let l = e.child(o);
    if (l.isAtom) {
      if (!s && S.isSelectable(l))
        return S.create(r, t - (i < 0 ? l.nodeSize : 0));
    } else {
      let a = se(r, l, t + i, i < 0 ? l.childCount : 0, i, s);
      if (a)
        return a;
    }
    t += l.nodeSize * i;
  }
  return null;
}
function Wt(r, e, t) {
  let n = r.steps.length - 1;
  if (n < e)
    return;
  let i = r.steps[n];
  if (!(i instanceof F || i instanceof P))
    return;
  let s = r.mapping.maps[n], o;
  s.forEach((l, a, c, f) => {
    o == null && (o = f);
  }), r.setSelection(k.near(r.doc.resolve(o), t));
}
function Ut(r, e) {
  return !e || !r ? r : r.bind(e);
}
class Te {
  constructor(e, t, n) {
    this.name = e, this.init = Ut(t.init, n), this.apply = Ut(t.apply, n);
  }
}
new Te("doc", {
  init(r) {
    return r.doc || r.schema.topNodeType.createAndFill();
  },
  apply(r) {
    return r.doc;
  }
}), new Te("selection", {
  init(r, e) {
    return r.selection || k.atStart(e.doc);
  },
  apply(r) {
    return r.selection;
  }
}), new Te("storedMarks", {
  init(r) {
    return r.storedMarks || null;
  },
  apply(r, e, t, n) {
    return n.selection.$cursor ? r.storedMarks : null;
  }
}), new Te("scrollToSelection", {
  init() {
    return 0;
  },
  apply(r, e) {
    return r.scrolledIntoView ? e + 1 : e;
  }
});
function Cn(r, e, t) {
  for (let n in r) {
    let i = r[n];
    i instanceof Function ? i = i.bind(e) : n == "handleDOMEvents" && (i = Cn(i, e, {})), t[n] = i;
  }
  return t;
}
class re {
  /**
  Create a plugin.
  */
  constructor(e) {
    this.spec = e, this.props = {}, e.props && Cn(e.props, this, this.props), this.key = e.key ? e.key.key : En("plugin");
  }
  /**
  Extract the plugin's state field from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const tt = /* @__PURE__ */ Object.create(null);
function En(r) {
  return r in tt ? r + "$" + ++tt[r] : (tt[r] = 0, r + "$");
}
class ie {
  /**
  Create a plugin key.
  */
  constructor(e = "key") {
    this.key = En(e);
  }
  /**
  Get the active plugin with this key, if any, from an editor
  state.
  */
  get(e) {
    return e.config.pluginsByKey[this.key];
  }
  /**
  Get the plugin's state from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const mt = (r, e) => r.selection.empty ? !1 : (e && e(r.tr.deleteSelection().scrollIntoView()), !0);
function An(r, e) {
  let { $cursor: t } = r.selection;
  return !t || (e ? !e.endOfTextblock("backward", r) : t.parentOffset > 0) ? null : t;
}
const Mn = (r, e, t) => {
  let n = An(r, t);
  if (!n)
    return !1;
  let i = gt(n);
  if (!i) {
    let o = n.blockRange(), l = o && fe(o);
    return l == null ? !1 : (e && e(r.tr.lift(o, l).scrollIntoView()), !0);
  }
  let s = i.nodeBefore;
  if (Pn(r, i, e, -1))
    return !0;
  if (n.parent.content.size == 0 && (ae(s, "end") || S.isSelectable(s)))
    for (let o = n.depth; ; o--) {
      let l = dt(r.doc, n.before(o), n.after(o), x.empty);
      if (l && l.slice.size < l.to - l.from) {
        if (e) {
          let a = r.tr.step(l);
          a.setSelection(ae(s, "end") ? k.findFrom(a.doc.resolve(a.mapping.map(i.pos, -1)), -1) : S.create(a.doc, i.pos - s.nodeSize)), e(a.scrollIntoView());
        }
        return !0;
      }
      if (o == 1 || n.node(o - 1).childCount > 1)
        break;
    }
  return s.isAtom && i.depth == n.depth - 1 ? (e && e(r.tr.delete(i.pos - s.nodeSize, i.pos).scrollIntoView()), !0) : !1;
}, Hr = (r, e, t) => {
  let n = An(r, t);
  if (!n)
    return !1;
  let i = gt(n);
  return i ? Tn(r, i, e) : !1;
}, Gr = (r, e, t) => {
  let n = On(r, t);
  if (!n)
    return !1;
  let i = yt(n);
  return i ? Tn(r, i, e) : !1;
};
function Tn(r, e, t) {
  let n = e.nodeBefore, i = n, s = e.pos - 1;
  for (; !i.isTextblock; s--) {
    if (i.type.spec.isolating)
      return !1;
    let f = i.lastChild;
    if (!f)
      return !1;
    i = f;
  }
  let o = e.nodeAfter, l = o, a = e.pos + 1;
  for (; !l.isTextblock; a++) {
    if (l.type.spec.isolating)
      return !1;
    let f = l.firstChild;
    if (!f)
      return !1;
    l = f;
  }
  let c = dt(r.doc, s, a, x.empty);
  if (!c || c.from != s || c instanceof F && c.slice.size >= a - s)
    return !1;
  if (t) {
    let f = r.tr.step(c);
    f.setSelection(C.create(f.doc, s)), t(f.scrollIntoView());
  }
  return !0;
}
function ae(r, e, t = !1) {
  for (let n = r; n; n = e == "start" ? n.firstChild : n.lastChild) {
    if (n.isTextblock)
      return !0;
    if (t && n.childCount != 1)
      return !1;
  }
  return !1;
}
const In = (r, e, t) => {
  let { $head: n, empty: i } = r.selection, s = n;
  if (!i)
    return !1;
  if (n.parent.isTextblock) {
    if (t ? !t.endOfTextblock("backward", r) : n.parentOffset > 0)
      return !1;
    s = gt(n);
  }
  let o = s && s.nodeBefore;
  return !o || !S.isSelectable(o) ? !1 : (e && e(r.tr.setSelection(S.create(r.doc, s.pos - o.nodeSize)).scrollIntoView()), !0);
};
function gt(r) {
  if (!r.parent.type.spec.isolating)
    for (let e = r.depth - 1; e >= 0; e--) {
      if (r.index(e) > 0)
        return r.doc.resolve(r.before(e + 1));
      if (r.node(e).type.spec.isolating)
        break;
    }
  return null;
}
function On(r, e) {
  let { $cursor: t } = r.selection;
  return !t || (e ? !e.endOfTextblock("forward", r) : t.parentOffset < t.parent.content.size) ? null : t;
}
const Nn = (r, e, t) => {
  let n = On(r, t);
  if (!n)
    return !1;
  let i = yt(n);
  if (!i)
    return !1;
  let s = i.nodeAfter;
  if (Pn(r, i, e, 1))
    return !0;
  if (n.parent.content.size == 0 && (ae(s, "start") || S.isSelectable(s))) {
    let o = dt(r.doc, n.before(), n.after(), x.empty);
    if (o && o.slice.size < o.to - o.from) {
      if (e) {
        let l = r.tr.step(o);
        l.setSelection(ae(s, "start") ? k.findFrom(l.doc.resolve(l.mapping.map(i.pos)), 1) : S.create(l.doc, l.mapping.map(i.pos))), e(l.scrollIntoView());
      }
      return !0;
    }
  }
  return s.isAtom && i.depth == n.depth - 1 ? (e && e(r.tr.delete(i.pos, i.pos + s.nodeSize).scrollIntoView()), !0) : !1;
}, Rn = (r, e, t) => {
  let { $head: n, empty: i } = r.selection, s = n;
  if (!i)
    return !1;
  if (n.parent.isTextblock) {
    if (t ? !t.endOfTextblock("forward", r) : n.parentOffset < n.parent.content.size)
      return !1;
    s = yt(n);
  }
  let o = s && s.nodeAfter;
  return !o || !S.isSelectable(o) ? !1 : (e && e(r.tr.setSelection(S.create(r.doc, s.pos)).scrollIntoView()), !0);
};
function yt(r) {
  if (!r.parent.type.spec.isolating)
    for (let e = r.depth - 1; e >= 0; e--) {
      let t = r.node(e);
      if (r.index(e) + 1 < t.childCount)
        return r.doc.resolve(r.after(e + 1));
      if (t.type.spec.isolating)
        break;
    }
  return null;
}
const Kr = (r, e) => {
  let t = r.selection, n = t instanceof S, i;
  if (n) {
    if (t.node.isTextblock || !ne(r.doc, t.from))
      return !1;
    i = t.from;
  } else if (i = He(r.doc, t.from, -1), i == null)
    return !1;
  if (e) {
    let s = r.tr.join(i);
    n && s.setSelection(S.create(s.doc, i - r.doc.resolve(i).nodeBefore.nodeSize)), e(s.scrollIntoView());
  }
  return !0;
}, Zr = (r, e) => {
  let t = r.selection, n;
  if (t instanceof S) {
    if (t.node.isTextblock || !ne(r.doc, t.to))
      return !1;
    n = t.to;
  } else if (n = He(r.doc, t.to, 1), n == null)
    return !1;
  return e && e(r.tr.join(n).scrollIntoView()), !0;
}, Xr = (r, e) => {
  let { $from: t, $to: n } = r.selection, i = t.blockRange(n), s = i && fe(i);
  return s == null ? !1 : (e && e(r.tr.lift(i, s).scrollIntoView()), !0);
}, zn = (r, e) => {
  let { $head: t, $anchor: n } = r.selection;
  return !t.parent.type.spec.code || !t.sameParent(n) ? !1 : (e && e(r.tr.insertText(`
`).scrollIntoView()), !0);
};
function xt(r) {
  for (let e = 0; e < r.edgeCount; e++) {
    let { type: t } = r.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
const Yr = (r, e) => {
  let { $head: t, $anchor: n } = r.selection;
  if (!t.parent.type.spec.code || !t.sameParent(n))
    return !1;
  let i = t.node(-1), s = t.indexAfter(-1), o = xt(i.contentMatchAt(s));
  if (!o || !i.canReplaceWith(s, s, o))
    return !1;
  if (e) {
    let l = t.after(), a = r.tr.replaceWith(l, l, o.createAndFill());
    a.setSelection(k.near(a.doc.resolve(l), 1)), e(a.scrollIntoView());
  }
  return !0;
}, Bn = (r, e) => {
  let t = r.selection, { $from: n, $to: i } = t;
  if (t instanceof $ || n.parent.inlineContent || i.parent.inlineContent)
    return !1;
  let s = xt(i.parent.contentMatchAt(i.indexAfter()));
  if (!s || !s.isTextblock)
    return !1;
  if (e) {
    let o = (!n.parentOffset && i.index() < i.parent.childCount ? n : i).pos, l = r.tr.insert(o, s.createAndFill());
    l.setSelection(C.create(l.doc, o + 1)), e(l.scrollIntoView());
  }
  return !0;
}, Fn = (r, e) => {
  let { $cursor: t } = r.selection;
  if (!t || t.parent.content.size)
    return !1;
  if (t.depth > 1 && t.after() != t.end(-1)) {
    let s = t.before();
    if (q(r.doc, s))
      return e && e(r.tr.split(s).scrollIntoView()), !0;
  }
  let n = t.blockRange(), i = n && fe(n);
  return i == null ? !1 : (e && e(r.tr.lift(n, i).scrollIntoView()), !0);
};
function Qr(r) {
  return (e, t) => {
    if (e.selection instanceof S && e.selection.node.isBlock) {
      let { $from: h } = e.selection;
      return !h.parentOffset || !q(e.doc, h.pos) ? !1 : (t && t(e.tr.split(h.pos).scrollIntoView()), !0);
    }
    if (!e.selection.$from.depth)
      return !1;
    let n = e.tr;
    !e.selection.empty && (e.selection instanceof C || e.selection instanceof $) && n.deleteSelection();
    let { $from: i } = n.selection, s = n.steps.length, o = [], l, a, c = !1, f = !1;
    for (let h = i.depth; ; h--)
      if (i.node(h).isBlock) {
        c = i.end(h) == i.pos + (i.depth - h), f = i.start(h) == i.pos - (i.depth - h), a = xt(i.node(h - 1).contentMatchAt(i.indexAfter(h - 1))), o.unshift(c && a ? { type: a } : null), l = h;
        break;
      } else {
        if (h == 1)
          return !1;
        o.unshift(null);
      }
    let u = i.pos, d = q(n.doc, u, o.length, o);
    if (d || (o[0] = a ? { type: a } : null, d = q(n.doc, u, o.length, o)), !d)
      return !1;
    if (n.split(u, o.length, o), !c && f && i.node(l).type != a) {
      let h = n.mapping.slice(s), g = h.map(i.before(l)), p = n.doc.resolve(g);
      a && i.node(l - 1).canReplaceWith(p.index(), p.index() + 1, a) && n.setNodeMarkup(h.map(i.before(l)), a);
    }
    return t && t(n.scrollIntoView()), !0;
  };
}
const _r = Qr(), ei = (r, e) => {
  let { $from: t, to: n } = r.selection, i, s = t.sharedDepth(n);
  return s == 0 ? !1 : (i = t.before(s), e && e(r.tr.setSelection(S.create(r.doc, i))), !0);
};
function ti(r, e, t) {
  let n = e.nodeBefore, i = e.nodeAfter, s = e.index();
  return !n || !i || !n.type.compatibleContent(i.type) ? !1 : !n.content.size && e.parent.canReplace(s - 1, s) ? (t && t(r.tr.delete(e.pos - n.nodeSize, e.pos).scrollIntoView()), !0) : !e.parent.canReplace(s, s + 1) || !(i.isTextblock || ne(r.doc, e.pos)) ? !1 : (t && t(r.tr.join(e.pos).scrollIntoView()), !0);
}
function Pn(r, e, t, n) {
  let i = e.nodeBefore, s = e.nodeAfter, o, l, a = i.type.spec.isolating || s.type.spec.isolating;
  if (!a && ti(r, e, t))
    return !0;
  let c = !a && e.parent.canReplace(e.index(), e.index() + 1);
  if (c && (o = (l = i.contentMatchAt(i.childCount)).findWrapping(s.type)) && l.matchType(o[0] || s.type).validEnd) {
    if (t) {
      let h = e.pos + s.nodeSize, g = y.empty;
      for (let w = o.length - 1; w >= 0; w--)
        g = y.from(o[w].create(null, g));
      g = y.from(i.copy(g));
      let p = r.tr.step(new P(e.pos - 1, h, e.pos, h, new x(g, 1, 0), o.length, !0)), m = p.doc.resolve(h + 2 * o.length);
      m.nodeAfter && m.nodeAfter.type == i.type && ne(p.doc, m.pos) && p.join(m.pos), t(p.scrollIntoView());
    }
    return !0;
  }
  let f = s.type.spec.isolating || n > 0 && a ? null : k.findFrom(e, 1), u = f && f.$from.blockRange(f.$to), d = u && fe(u);
  if (d != null && d >= e.depth)
    return t && t(r.tr.lift(u, d).scrollIntoView()), !0;
  if (c && ae(s, "start", !0) && ae(i, "end")) {
    let h = i, g = [];
    for (; g.push(h), !h.isTextblock; )
      h = h.lastChild;
    let p = s, m = 1;
    for (; !p.isTextblock; p = p.firstChild)
      m++;
    if (h.canReplace(h.childCount, h.childCount, p.content)) {
      if (t) {
        let w = y.empty;
        for (let T = g.length - 1; T >= 0; T--)
          w = y.from(g[T].copy(w));
        let O = r.tr.step(new P(e.pos - g.length, e.pos + s.nodeSize, e.pos + m, e.pos + s.nodeSize - m, new x(w, g.length, 0), 0, !0));
        t(O.scrollIntoView());
      }
      return !0;
    }
  }
  return !1;
}
function Dn(r) {
  return function(e, t) {
    let n = e.selection, i = r < 0 ? n.$from : n.$to, s = i.depth;
    for (; i.node(s).isInline; ) {
      if (!s)
        return !1;
      s--;
    }
    return i.node(s).isTextblock ? (t && t(e.tr.setSelection(C.create(e.doc, r < 0 ? i.start(s) : i.end(s)))), !0) : !1;
  };
}
const ni = Dn(-1), ri = Dn(1);
function ii(r, e = null) {
  return function(t, n) {
    let { $from: i, $to: s } = t.selection, o = i.blockRange(s), l = o && bn(o, r, e);
    return l ? (n && n(t.tr.wrap(o, l).scrollIntoView()), !0) : !1;
  };
}
function Vt(r, e = null) {
  return function(t, n) {
    let i = !1;
    for (let s = 0; s < t.selection.ranges.length && !i; s++) {
      let { $from: { pos: o }, $to: { pos: l } } = t.selection.ranges[s];
      t.doc.nodesBetween(o, l, (a, c) => {
        if (i)
          return !1;
        if (!(!a.isTextblock || a.hasMarkup(r, e)))
          if (a.type == r)
            i = !0;
          else {
            let f = t.doc.resolve(c), u = f.index();
            i = f.parent.canReplaceWith(u, u + 1, r);
          }
      });
    }
    if (!i)
      return !1;
    if (n) {
      let s = t.tr;
      for (let o = 0; o < t.selection.ranges.length; o++) {
        let { $from: { pos: l }, $to: { pos: a } } = t.selection.ranges[o];
        s.setBlockType(l, a, r, e);
      }
      n(s.scrollIntoView());
    }
    return !0;
  };
}
function wt(...r) {
  return function(e, t, n) {
    for (let i = 0; i < r.length; i++)
      if (r[i](e, t, n))
        return !0;
    return !1;
  };
}
wt(mt, Mn, In);
wt(mt, Nn, Rn);
wt(zn, Bn, Fn, _r);
typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : typeof os < "u" && os.platform && os.platform() == "darwin";
function si(r, e = null) {
  return function(t, n) {
    let { $from: i, $to: s } = t.selection, o = i.blockRange(s);
    if (!o)
      return !1;
    let l = n ? t.tr : null;
    return oi(l, o, r, e) ? (n && n(l.scrollIntoView()), !0) : !1;
  };
}
function oi(r, e, t, n = null) {
  let i = !1, s = e, o = e.$from.doc;
  if (e.depth >= 2 && e.$from.node(e.depth - 1).type.compatibleContent(t) && e.startIndex == 0) {
    if (e.$from.index(e.depth - 1) == 0)
      return !1;
    let a = o.resolve(e.start - 2);
    s = new De(a, a, e.depth), e.endIndex < e.parent.childCount && (e = new De(e.$from, o.resolve(e.$to.end(e.depth)), e.depth)), i = !0;
  }
  let l = bn(s, t, n, e);
  return l ? (r && li(r, e, l, i, t), !0) : !1;
}
function li(r, e, t, n, i) {
  let s = y.empty;
  for (let f = t.length - 1; f >= 0; f--)
    s = y.from(t[f].type.create(t[f].attrs, s));
  r.step(new P(e.start - (n ? 2 : 0), e.end, e.start, e.end, new x(s, 0, 0), t.length, !0));
  let o = 0;
  for (let f = 0; f < t.length; f++)
    t[f].type == i && (o = f + 1);
  let l = t.length - o, a = e.start + t.length - (n ? 2 : 0), c = e.parent;
  for (let f = e.startIndex, u = e.endIndex, d = !0; f < u; f++, d = !1)
    !d && l && q(r.doc, a, l) && (r.split(a, l), a += 2 * l), a += c.child(f).nodeSize;
  return r;
}
function je(r, e) {
  return r instanceof we ? e == r : r.indexOf(e) > -1;
}
function ai(r) {
  return function(e, t) {
    let { $from: n, $to: i } = e.selection, s = n.blockRange(i, (o) => o.childCount > 0 && je(r, o.firstChild.type));
    return s ? t ? je(r, n.node(s.depth - 1).type) ? ci(e, t, s) : fi(e, t, s) : !0 : !1;
  };
}
function ci(r, e, t) {
  let n = r.tr, i = t.end, s = t.$to.end(t.depth), o = t.parent.child(t.endIndex - 1).type;
  i < s && (n.step(new P(i - 1, s, i, s, new x(y.from(o.create(null, t.parent.copy())), 1, 0), 1, !0)), t = new De(n.doc.resolve(t.$from.pos), n.doc.resolve(s), t.depth));
  const l = fe(t);
  if (l == null)
    return !1;
  n.lift(t, l);
  let a = n.doc.resolve(n.mapping.map(i, -1) - 1);
  return ne(n.doc, a.pos) && a.nodeBefore.type == a.nodeAfter.type && n.join(a.pos), e(n.scrollIntoView()), !0;
}
function fi(r, e, t) {
  let n = r.tr, i = t.parent;
  for (let h = t.end, g = t.endIndex - 1, p = t.startIndex; g > p; g--)
    h -= i.child(g).nodeSize, n.delete(h - 1, h + 1);
  let s = n.doc.resolve(t.start), o = s.nodeAfter;
  if (n.mapping.map(t.end) != t.start + s.nodeAfter.nodeSize)
    return !1;
  let l = t.startIndex == 0, a = t.endIndex == i.childCount, c = s.node(-1), f = s.index(-1);
  if (!c.canReplace(f + (l ? 0 : 1), f + 1, o.content.append(a ? y.empty : y.from(i))))
    return !1;
  let u = s.pos, d = u + o.nodeSize;
  return n.step(new P(u - (l ? 1 : 0), d + (a ? 1 : 0), u + 1, d - 1, new x((l ? y.empty : y.from(i.copy(y.empty))).append(a ? y.empty : y.from(i.copy(y.empty))), l ? 0 : 1, a ? 0 : 1), l ? 0 : 1)), e(n.scrollIntoView()), !0;
}
function ui(r) {
  return function(e, t) {
    let { $from: n, $to: i } = e.selection, s = n.blockRange(i, (c) => c.childCount > 0 && je(r, c.firstChild.type));
    if (!s)
      return !1;
    let o = s.startIndex;
    if (o == 0)
      return !1;
    let l = s.parent, a = l.child(o - 1);
    if (!je(r, a.type))
      return !1;
    if (t) {
      let c = a.lastChild && a.lastChild.type == l.type, f = y.from(c ? a.lastChild.lastChild.type.create() : null), u = new x(y.from(a.type.create(null, y.from(l.type.create(null, f)))), c ? 3 : 1, 0), d = s.start, h = s.end;
      t(e.tr.step(new P(d - (c ? 3 : 1), h, d, h, u, 1, !0)).scrollIntoView());
    }
    return !0;
  };
}
function $n(r) {
  const { state: e, transaction: t } = r;
  let { selection: n } = t, { doc: i } = t, { storedMarks: s } = t;
  return {
    ...e,
    apply: e.apply.bind(e),
    applyTransaction: e.applyTransaction.bind(e),
    plugins: e.plugins,
    schema: e.schema,
    reconfigure: e.reconfigure.bind(e),
    toJSON: e.toJSON.bind(e),
    get storedMarks() {
      return s;
    },
    get selection() {
      return n;
    },
    get doc() {
      return i;
    },
    get tr() {
      return n = t.selection, i = t.doc, s = t.storedMarks, t;
    }
  };
}
class hi {
  constructor(e) {
    this.editor = e.editor, this.rawCommands = this.editor.extensionManager.commands, this.customState = e.state;
  }
  get hasCustomState() {
    return !!this.customState;
  }
  get state() {
    return this.customState || this.editor.state;
  }
  get commands() {
    const { rawCommands: e, editor: t, state: n } = this, { view: i } = t, { tr: s } = n, o = this.buildProps(s);
    return Object.fromEntries(Object.entries(e).map(([l, a]) => [l, (...f) => {
      const u = a(...f)(o);
      return !s.getMeta("preventDispatch") && !this.hasCustomState && i.dispatch(s), u;
    }]));
  }
  get chain() {
    return () => this.createChain();
  }
  get can() {
    return () => this.createCan();
  }
  createChain(e, t = !0) {
    const { rawCommands: n, editor: i, state: s } = this, { view: o } = i, l = [], a = !!e, c = e || s.tr, f = () => (!a && t && !c.getMeta("preventDispatch") && !this.hasCustomState && o.dispatch(c), l.every((d) => d === !0)), u = {
      ...Object.fromEntries(Object.entries(n).map(([d, h]) => [d, (...p) => {
        const m = this.buildProps(c, t), w = h(...p)(m);
        return l.push(w), u;
      }])),
      run: f
    };
    return u;
  }
  createCan(e) {
    const { rawCommands: t, state: n } = this, i = !1, s = e || n.tr, o = this.buildProps(s, i);
    return {
      ...Object.fromEntries(Object.entries(t).map(([a, c]) => [a, (...f) => c(...f)({ ...o, dispatch: void 0 })])),
      chain: () => this.createChain(s, i)
    };
  }
  buildProps(e, t = !0) {
    const { rawCommands: n, editor: i, state: s } = this, { view: o } = i, l = {
      tr: e,
      editor: i,
      view: o,
      state: $n({
        state: s,
        transaction: e
      }),
      dispatch: t ? () => {
      } : void 0,
      chain: () => this.createChain(e, t),
      can: () => this.createCan(e),
      get commands() {
        return Object.fromEntries(Object.entries(n).map(([a, c]) => [a, (...f) => c(...f)(l)]));
      }
    };
    return l;
  }
}
function J(r, e, t) {
  return r.config[e] === void 0 && r.parent ? J(r.parent, e, t) : typeof r.config[e] == "function" ? r.config[e].bind({
    ...t,
    parent: r.parent ? J(r.parent, e, t) : null
  }) : r.config[e];
}
function di(r) {
  const e = r.filter((i) => i.type === "extension"), t = r.filter((i) => i.type === "node"), n = r.filter((i) => i.type === "mark");
  return {
    baseExtensions: e,
    nodeExtensions: t,
    markExtensions: n
  };
}
function z(r, e) {
  if (typeof r == "string") {
    if (!e.nodes[r])
      throw Error(`There is no node type named '${r}'. Maybe you forgot to add the extension?`);
    return e.nodes[r];
  }
  return r;
}
function pi(...r) {
  return r.filter((e) => !!e).reduce((e, t) => {
    const n = { ...e };
    return Object.entries(t).forEach(([i, s]) => {
      if (i === "__proto__") {
        Object.defineProperty(n, i, {
          configurable: !0,
          enumerable: !0,
          value: s,
          writable: !0
        });
        return;
      }
      if (!n[i]) {
        n[i] = s;
        return;
      }
      if (i === "class") {
        const l = s ? String(s).split(" ") : [], a = n[i] ? n[i].split(" ") : [], c = l.filter((f) => !a.includes(f));
        n[i] = [...a, ...c].join(" ");
      } else if (i === "style") {
        const l = s ? s.split(";").map((f) => f.trim()).filter(Boolean) : [], a = n[i] ? n[i].split(";").map((f) => f.trim()).filter(Boolean) : [], c = /* @__PURE__ */ new Map();
        a.forEach((f) => {
          const [u, d] = f.split(":").map((h) => h.trim());
          c.set(u, d);
        }), l.forEach((f) => {
          const [u, d] = f.split(":").map((h) => h.trim());
          c.set(u, d);
        }), n[i] = Array.from(c.entries()).map(([f, u]) => `${f}: ${u}`).join("; ");
      } else
        n[i] = s;
    }), n;
  }, {});
}
function mi(r) {
  return typeof r == "function";
}
function V(r, e = void 0, ...t) {
  return mi(r) ? e ? r.bind(e)(...t) : r(...t) : r;
}
function gi(r) {
  return Object.prototype.toString.call(r) === "[object RegExp]";
}
function yi(r) {
  return Object.prototype.toString.call(r).slice(8, -1);
}
function Ie(r) {
  return yi(r) !== "Object" ? !1 : r.constructor === Object && Object.getPrototypeOf(r) === Object.prototype;
}
function kt(r, e) {
  const t = { ...r };
  return Ie(r) && Ie(e) && Object.keys(e).forEach((n) => {
    Ie(e[n]) && Ie(r[n]) ? t[n] = kt(r[n], e[n]) : t[n] = e[n];
  }), t;
}
class W {
  constructor(e = {}) {
    this.type = "extension", this.name = "extension", this.parent = null, this.child = null, this.config = {
      name: this.name,
      defaultOptions: {}
    }, this.config = {
      ...this.config,
      ...e
    }, this.name = this.config.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${this.name}".`), this.options = this.config.defaultOptions, this.config.addOptions && (this.options = V(J(this, "addOptions", {
      name: this.name
    }))), this.storage = V(J(this, "addStorage", {
      name: this.name,
      options: this.options
    })) || {};
  }
  static create(e = {}) {
    return new W(e);
  }
  configure(e = {}) {
    const t = this.extend({
      ...this.config,
      addOptions: () => kt(this.options, e)
    });
    return t.name = this.name, t.parent = this.parent, t;
  }
  extend(e = {}) {
    const t = new W({ ...this.config, ...e });
    return t.parent = this, this.child = t, t.name = e.name ? e.name : t.parent.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${t.name}".`), t.options = V(J(t, "addOptions", {
      name: t.name
    })), t.storage = V(J(t, "addStorage", {
      name: t.name,
      options: t.options
    })), t;
  }
}
function xi(r, e, t) {
  const { from: n, to: i } = e, { blockSeparator: s = `

`, textSerializers: o = {} } = t || {};
  let l = "";
  return r.nodesBetween(n, i, (a, c, f, u) => {
    var d;
    a.isBlock && c > n && (l += s);
    const h = o == null ? void 0 : o[a.type.name];
    if (h)
      return f && (l += h({
        node: a,
        pos: c,
        parent: f,
        index: u,
        range: e
      })), !1;
    a.isText && (l += (d = a == null ? void 0 : a.text) === null || d === void 0 ? void 0 : d.slice(Math.max(n, c) - c, i - c));
  }), l;
}
function wi(r) {
  return Object.fromEntries(Object.entries(r.nodes).filter(([, e]) => e.spec.toText).map(([e, t]) => [e, t.spec.toText]));
}
W.create({
  name: "clipboardTextSerializer",
  addOptions() {
    return {
      blockSeparator: void 0
    };
  },
  addProseMirrorPlugins() {
    return [
      new re({
        key: new ie("clipboardTextSerializer"),
        props: {
          clipboardTextSerializer: () => {
            const { editor: r } = this, { state: e, schema: t } = r, { doc: n, selection: i } = e, { ranges: s } = i, o = Math.min(...s.map((f) => f.$from.pos)), l = Math.max(...s.map((f) => f.$to.pos)), a = wi(t);
            return xi(n, { from: o, to: l }, {
              ...this.options.blockSeparator !== void 0 ? { blockSeparator: this.options.blockSeparator } : {},
              textSerializers: a
            });
          }
        }
      })
    ];
  }
});
const ki = () => ({ editor: r, view: e }) => (requestAnimationFrame(() => {
  var t;
  r.isDestroyed || (e.dom.blur(), (t = window == null ? void 0 : window.getSelection()) === null || t === void 0 || t.removeAllRanges());
}), !0), bi = (r = !1) => ({ commands: e }) => e.setContent("", r), Si = () => ({ state: r, tr: e, dispatch: t }) => {
  const { selection: n } = e, { ranges: i } = n;
  return t && i.forEach(({ $from: s, $to: o }) => {
    r.doc.nodesBetween(s.pos, o.pos, (l, a) => {
      if (l.type.isText)
        return;
      const { doc: c, mapping: f } = e, u = c.resolve(f.map(a)), d = c.resolve(f.map(a + l.nodeSize)), h = u.blockRange(d);
      if (!h)
        return;
      const g = fe(h);
      if (l.type.isTextblock) {
        const { defaultType: p } = u.parent.contentMatchAt(u.index());
        e.setNodeMarkup(h.start, p);
      }
      (g || g === 0) && e.lift(h, g);
    });
  }), !0;
}, vi = (r) => (e) => r(e), Ci = () => ({ state: r, dispatch: e }) => Bn(r, e), Ei = (r, e) => ({ editor: t, tr: n }) => {
  const { state: i } = t, s = i.doc.slice(r.from, r.to);
  n.deleteRange(r.from, r.to);
  const o = n.mapping.map(e);
  return n.insert(o, s.content), n.setSelection(new C(n.doc.resolve(Math.max(o - 1, 0)))), !0;
}, Ai = () => ({ tr: r, dispatch: e }) => {
  const { selection: t } = r, n = t.$anchor.node();
  if (n.content.size > 0)
    return !1;
  const i = r.selection.$anchor;
  for (let s = i.depth; s > 0; s -= 1)
    if (i.node(s).type === n.type) {
      if (e) {
        const l = i.before(s), a = i.after(s);
        r.delete(l, a).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, Mi = (r) => ({ tr: e, state: t, dispatch: n }) => {
  const i = z(r, t.schema), s = e.selection.$anchor;
  for (let o = s.depth; o > 0; o -= 1)
    if (s.node(o).type === i) {
      if (n) {
        const a = s.before(o), c = s.after(o);
        e.delete(a, c).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, Ti = (r) => ({ tr: e, dispatch: t }) => {
  const { from: n, to: i } = r;
  return t && e.delete(n, i), !0;
}, Ii = () => ({ state: r, dispatch: e }) => mt(r, e), Oi = () => ({ commands: r }) => r.keyboardShortcut("Enter"), Ni = () => ({ state: r, dispatch: e }) => Yr(r, e);
function Je(r, e, t = { strict: !0 }) {
  const n = Object.keys(e);
  return n.length ? n.every((i) => t.strict ? e[i] === r[i] : gi(e[i]) ? e[i].test(r[i]) : e[i] === r[i]) : !0;
}
function Ln(r, e, t = {}) {
  return r.find((n) => n.type === e && Je(
    // Only check equality for the attributes that are provided
    Object.fromEntries(Object.keys(t).map((i) => [i, n.attrs[i]])),
    t
  ));
}
function qt(r, e, t = {}) {
  return !!Ln(r, e, t);
}
function jn(r, e, t) {
  var n;
  if (!r || !e)
    return;
  let i = r.parent.childAfter(r.parentOffset);
  if ((!i.node || !i.node.marks.some((f) => f.type === e)) && (i = r.parent.childBefore(r.parentOffset)), !i.node || !i.node.marks.some((f) => f.type === e) || (t = t || ((n = i.node.marks[0]) === null || n === void 0 ? void 0 : n.attrs), !Ln([...i.node.marks], e, t)))
    return;
  let o = i.index, l = r.start() + i.offset, a = o + 1, c = l + i.node.nodeSize;
  for (; o > 0 && qt([...r.parent.child(o - 1).marks], e, t); )
    o -= 1, l -= r.parent.child(o).nodeSize;
  for (; a < r.parent.childCount && qt([...r.parent.child(a).marks], e, t); )
    c += r.parent.child(a).nodeSize, a += 1;
  return {
    from: l,
    to: c
  };
}
function G(r, e) {
  if (typeof r == "string") {
    if (!e.marks[r])
      throw Error(`There is no mark type named '${r}'. Maybe you forgot to add the extension?`);
    return e.marks[r];
  }
  return r;
}
const Ri = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  const s = G(r, n.schema), { doc: o, selection: l } = t, { $from: a, from: c, to: f } = l;
  if (i) {
    const u = jn(a, s, e);
    if (u && u.from <= c && u.to >= f) {
      const d = C.create(o, u.from, u.to);
      t.setSelection(d);
    }
  }
  return !0;
}, zi = (r) => (e) => {
  const t = typeof r == "function" ? r(e) : r;
  for (let n = 0; n < t.length; n += 1)
    if (t[n](e))
      return !0;
  return !1;
};
function Jn(r) {
  return r instanceof C;
}
function X(r = 0, e = 0, t = 0) {
  return Math.min(Math.max(r, e), t);
}
function Bi(r, e = null) {
  if (!e)
    return null;
  const t = k.atStart(r), n = k.atEnd(r);
  if (e === "start" || e === !0)
    return t;
  if (e === "end")
    return n;
  const i = t.from, s = n.to;
  return e === "all" ? C.create(r, X(0, i, s), X(r.content.size, i, s)) : C.create(r, X(e, i, s), X(e, i, s));
}
function Ht() {
  return navigator.platform === "Android" || /android/i.test(navigator.userAgent);
}
function We() {
  return [
    "iPad Simulator",
    "iPhone Simulator",
    "iPod Simulator",
    "iPad",
    "iPhone",
    "iPod"
  ].includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in document;
}
function Fi() {
  return typeof navigator < "u" ? /^((?!chrome|android).)*safari/i.test(navigator.userAgent) : !1;
}
const Pi = (r = null, e = {}) => ({ editor: t, view: n, tr: i, dispatch: s }) => {
  e = {
    scrollIntoView: !0,
    ...e
  };
  const o = () => {
    (We() || Ht()) && n.dom.focus(), requestAnimationFrame(() => {
      t.isDestroyed || (n.focus(), Fi() && !We() && !Ht() && n.dom.focus({ preventScroll: !0 }));
    });
  };
  if (n.hasFocus() && r === null || r === !1)
    return !0;
  if (s && r === null && !Jn(t.state.selection))
    return o(), !0;
  const l = Bi(i.doc, r) || t.state.selection, a = t.state.selection.eq(l);
  return s && (a || i.setSelection(l), a && i.storedMarks && i.setStoredMarks(i.storedMarks), o()), !0;
}, Di = (r, e) => (t) => r.every((n, i) => e(n, { ...t, index: i })), $i = (r, e) => ({ tr: t, commands: n }) => n.insertContentAt({ from: t.selection.from, to: t.selection.to }, r, e), Wn = (r) => {
  const e = r.childNodes;
  for (let t = e.length - 1; t >= 0; t -= 1) {
    const n = e[t];
    n.nodeType === 3 && n.nodeValue && /^(\n\s\s|\n)$/.test(n.nodeValue) ? r.removeChild(n) : n.nodeType === 1 && Wn(n);
  }
  return r;
};
function Oe(r) {
  const e = `<body>${r}</body>`, t = new window.DOMParser().parseFromString(e, "text/html").body;
  return Wn(t);
}
function ve(r, e, t) {
  if (r instanceof _ || r instanceof y)
    return r;
  t = {
    slice: !0,
    parseOptions: {},
    ...t
  };
  const n = typeof r == "object" && r !== null, i = typeof r == "string";
  if (n)
    try {
      if (Array.isArray(r) && r.length > 0)
        return y.fromArray(r.map((l) => e.nodeFromJSON(l)));
      const o = e.nodeFromJSON(r);
      return t.errorOnInvalidContent && o.check(), o;
    } catch (s) {
      if (t.errorOnInvalidContent)
        throw new Error("[tiptap error]: Invalid JSON content", { cause: s });
      return console.warn("[tiptap warn]: Invalid content.", "Passed value:", r, "Error:", s), ve("", e, t);
    }
  if (i) {
    if (t.errorOnInvalidContent) {
      let o = !1, l = "";
      const a = new Ir({
        topNode: e.spec.topNode,
        marks: e.spec.marks,
        // Prosemirror's schemas are executed such that: the last to execute, matches last
        // This means that we can add a catch-all node at the end of the schema to catch any content that we don't know how to handle
        nodes: e.spec.nodes.append({
          __tiptap__private__unknown__catch__all__node: {
            content: "inline*",
            group: "block",
            parseDOM: [
              {
                tag: "*",
                getAttrs: (c) => (o = !0, l = typeof c == "string" ? c : c.outerHTML, null)
              }
            ]
          }
        })
      });
      if (t.slice ? oe.fromSchema(a).parseSlice(Oe(r), t.parseOptions) : oe.fromSchema(a).parse(Oe(r), t.parseOptions), t.errorOnInvalidContent && o)
        throw new Error("[tiptap error]: Invalid HTML content", { cause: new Error(`Invalid element found: ${l}`) });
    }
    const s = oe.fromSchema(e);
    return t.slice ? s.parseSlice(Oe(r), t.parseOptions).content : s.parse(Oe(r), t.parseOptions);
  }
  return ve("", e, t);
}
function Li(r, e, t) {
  const n = r.steps.length - 1;
  if (n < e)
    return;
  const i = r.steps[n];
  if (!(i instanceof F || i instanceof P))
    return;
  const s = r.mapping.maps[n];
  let o = 0;
  s.forEach((l, a, c, f) => {
    o === 0 && (o = f);
  }), r.setSelection(k.near(r.doc.resolve(o), t));
}
const ji = (r) => !("type" in r), Ji = (r, e, t) => ({ tr: n, dispatch: i, editor: s }) => {
  var o;
  if (i) {
    t = {
      parseOptions: s.options.parseOptions,
      updateSelection: !0,
      applyInputRules: !1,
      applyPasteRules: !1,
      ...t
    };
    let l;
    const a = (m) => {
      s.emit("contentError", {
        editor: s,
        error: m,
        disableCollaboration: () => {
          s.storage.collaboration && (s.storage.collaboration.isDisabled = !0);
        }
      });
    }, c = {
      preserveWhitespace: "full",
      ...t.parseOptions
    };
    if (!t.errorOnInvalidContent && !s.options.enableContentCheck && s.options.emitContentError)
      try {
        ve(e, s.schema, {
          parseOptions: c,
          errorOnInvalidContent: !0
        });
      } catch (m) {
        a(m);
      }
    try {
      l = ve(e, s.schema, {
        parseOptions: c,
        errorOnInvalidContent: (o = t.errorOnInvalidContent) !== null && o !== void 0 ? o : s.options.enableContentCheck
      });
    } catch (m) {
      return a(m), !1;
    }
    let { from: f, to: u } = typeof r == "number" ? { from: r, to: r } : { from: r.from, to: r.to }, d = !0, h = !0;
    if ((ji(l) ? l : [l]).forEach((m) => {
      m.check(), d = d ? m.isText && m.marks.length === 0 : !1, h = h ? m.isBlock : !1;
    }), f === u && h) {
      const { parent: m } = n.doc.resolve(f);
      m.isTextblock && !m.type.spec.code && !m.childCount && (f -= 1, u += 1);
    }
    let p;
    if (d) {
      if (Array.isArray(e))
        p = e.map((m) => m.text || "").join("");
      else if (e instanceof y) {
        let m = "";
        e.forEach((w) => {
          w.text && (m += w.text);
        }), p = m;
      } else typeof e == "object" && e && e.text ? p = e.text : p = e;
      n.insertText(p, f, u);
    } else
      p = l, n.replaceWith(f, u, p);
    t.updateSelection && Li(n, n.steps.length - 1, -1), t.applyInputRules && n.setMeta("applyInputRules", { from: f, text: p }), t.applyPasteRules && n.setMeta("applyPasteRules", { from: f, text: p });
  }
  return !0;
}, Wi = () => ({ state: r, dispatch: e }) => Kr(r, e), Ui = () => ({ state: r, dispatch: e }) => Zr(r, e), Vi = () => ({ state: r, dispatch: e }) => Mn(r, e), qi = () => ({ state: r, dispatch: e }) => Nn(r, e), Hi = () => ({ state: r, dispatch: e, tr: t }) => {
  try {
    const n = He(r.doc, r.selection.$from.pos, -1);
    return n == null ? !1 : (t.join(n, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, Gi = () => ({ state: r, dispatch: e, tr: t }) => {
  try {
    const n = He(r.doc, r.selection.$from.pos, 1);
    return n == null ? !1 : (t.join(n, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, Ki = () => ({ state: r, dispatch: e }) => Hr(r, e), Zi = () => ({ state: r, dispatch: e }) => Gr(r, e);
function Un() {
  return typeof navigator < "u" ? /Mac/.test(navigator.platform) : !1;
}
function Xi(r) {
  const e = r.split(/-(?!$)/);
  let t = e[e.length - 1];
  t === "Space" && (t = " ");
  let n, i, s, o;
  for (let l = 0; l < e.length - 1; l += 1) {
    const a = e[l];
    if (/^(cmd|meta|m)$/i.test(a))
      o = !0;
    else if (/^a(lt)?$/i.test(a))
      n = !0;
    else if (/^(c|ctrl|control)$/i.test(a))
      i = !0;
    else if (/^s(hift)?$/i.test(a))
      s = !0;
    else if (/^mod$/i.test(a))
      We() || Un() ? o = !0 : i = !0;
    else
      throw new Error(`Unrecognized modifier name: ${a}`);
  }
  return n && (t = `Alt-${t}`), i && (t = `Ctrl-${t}`), o && (t = `Meta-${t}`), s && (t = `Shift-${t}`), t;
}
const Yi = (r) => ({ editor: e, view: t, tr: n, dispatch: i }) => {
  const s = Xi(r).split(/-(?!$)/), o = s.find((c) => !["Alt", "Ctrl", "Meta", "Shift"].includes(c)), l = new KeyboardEvent("keydown", {
    key: o === "Space" ? " " : o,
    altKey: s.includes("Alt"),
    ctrlKey: s.includes("Ctrl"),
    metaKey: s.includes("Meta"),
    shiftKey: s.includes("Shift"),
    bubbles: !0,
    cancelable: !0
  }), a = e.captureTransaction(() => {
    t.someProp("handleKeyDown", (c) => c(t, l));
  });
  return a == null || a.steps.forEach((c) => {
    const f = c.map(n.mapping);
    f && i && n.maybeStep(f);
  }), !0;
};
function bt(r, e, t = {}) {
  const { from: n, to: i, empty: s } = r.selection, o = e ? z(e, r.schema) : null, l = [];
  r.doc.nodesBetween(n, i, (u, d) => {
    if (u.isText)
      return;
    const h = Math.max(n, d), g = Math.min(i, d + u.nodeSize);
    l.push({
      node: u,
      from: h,
      to: g
    });
  });
  const a = i - n, c = l.filter((u) => o ? o.name === u.node.type.name : !0).filter((u) => Je(u.node.attrs, t, { strict: !1 }));
  return s ? !!c.length : c.reduce((u, d) => u + d.to - d.from, 0) >= a;
}
const Qi = (r, e = {}) => ({ state: t, dispatch: n }) => {
  const i = z(r, t.schema);
  return bt(t, i, e) ? Xr(t, n) : !1;
}, _i = () => ({ state: r, dispatch: e }) => Fn(r, e), es = (r) => ({ state: e, dispatch: t }) => {
  const n = z(r, e.schema);
  return ai(n)(e, t);
}, ts = () => ({ state: r, dispatch: e }) => zn(r, e);
function Vn(r, e) {
  return e.nodes[r] ? "node" : e.marks[r] ? "mark" : null;
}
function Gt(r, e) {
  const t = typeof e == "string" ? [e] : e;
  return Object.keys(r).reduce((n, i) => (t.includes(i) || (n[i] = r[i]), n), {});
}
const ns = (r, e) => ({ tr: t, state: n, dispatch: i }) => {
  let s = null, o = null;
  const l = Vn(typeof r == "string" ? r : r.name, n.schema);
  return l ? (l === "node" && (s = z(r, n.schema)), l === "mark" && (o = G(r, n.schema)), i && t.selection.ranges.forEach((a) => {
    n.doc.nodesBetween(a.$from.pos, a.$to.pos, (c, f) => {
      s && s === c.type && t.setNodeMarkup(f, void 0, Gt(c.attrs, e)), o && c.marks.length && c.marks.forEach((u) => {
        o === u.type && t.addMark(f, f + c.nodeSize, o.create(Gt(u.attrs, e)));
      });
    });
  }), !0) : !1;
}, rs = () => ({ tr: r, dispatch: e }) => (e && r.scrollIntoView(), !0), is = () => ({ tr: r, dispatch: e }) => {
  if (e) {
    const t = new $(r.doc);
    r.setSelection(t);
  }
  return !0;
}, ss = () => ({ state: r, dispatch: e }) => In(r, e), ls = () => ({ state: r, dispatch: e }) => Rn(r, e), as = () => ({ state: r, dispatch: e }) => ei(r, e), cs = () => ({ state: r, dispatch: e }) => ri(r, e), fs = () => ({ state: r, dispatch: e }) => ni(r, e);
function us(r, e, t = {}, n = {}) {
  return ve(r, e, {
    slice: !1,
    parseOptions: t,
    errorOnInvalidContent: n.errorOnInvalidContent
  });
}
const hs = (r, e = !1, t = {}, n = {}) => ({ editor: i, tr: s, dispatch: o, commands: l }) => {
  var a, c;
  const { doc: f } = s;
  if (t.preserveWhitespace !== "full") {
    const u = us(r, i.schema, t, {
      errorOnInvalidContent: (a = n.errorOnInvalidContent) !== null && a !== void 0 ? a : i.options.enableContentCheck
    });
    return o && s.replaceWith(0, f.content.size, u).setMeta("preventUpdate", !e), !0;
  }
  return o && s.setMeta("preventUpdate", !e), l.insertContentAt({ from: 0, to: f.content.size }, r, {
    parseOptions: t,
    errorOnInvalidContent: (c = n.errorOnInvalidContent) !== null && c !== void 0 ? c : i.options.enableContentCheck
  });
};
function ds(r, e) {
  const t = G(e, r.schema), { from: n, to: i, empty: s } = r.selection, o = [];
  s ? (r.storedMarks && o.push(...r.storedMarks), o.push(...r.selection.$head.marks())) : r.doc.nodesBetween(n, i, (a) => {
    o.push(...a.marks);
  });
  const l = o.find((a) => a.type.name === t.name);
  return l ? { ...l.attrs } : {};
}
function ps(r) {
  for (let e = 0; e < r.edgeCount; e += 1) {
    const { type: t } = r.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
function ms(r, e) {
  for (let t = r.depth; t > 0; t -= 1) {
    const n = r.node(t);
    if (e(n))
      return {
        pos: t > 0 ? r.before(t) : 0,
        start: r.start(t),
        depth: t,
        node: n
      };
  }
}
function St(r) {
  return (e) => ms(e.$from, r);
}
function ze(r, e, t) {
  return Object.fromEntries(Object.entries(t).filter(([n]) => {
    const i = r.find((s) => s.type === e && s.name === n);
    return i ? i.attribute.keepOnSplit : !1;
  }));
}
function gs(r, e, t = {}) {
  const { empty: n, ranges: i } = r.selection, s = e ? G(e, r.schema) : null;
  if (n)
    return !!(r.storedMarks || r.selection.$from.marks()).filter((u) => s ? s.name === u.type.name : !0).find((u) => Je(u.attrs, t, { strict: !1 }));
  let o = 0;
  const l = [];
  if (i.forEach(({ $from: u, $to: d }) => {
    const h = u.pos, g = d.pos;
    r.doc.nodesBetween(h, g, (p, m) => {
      if (!p.isText && !p.marks.length)
        return;
      const w = Math.max(h, m), O = Math.min(g, m + p.nodeSize), T = O - w;
      o += T, l.push(...p.marks.map((v) => ({
        mark: v,
        from: w,
        to: O
      })));
    });
  }), o === 0)
    return !1;
  const a = l.filter((u) => s ? s.name === u.mark.type.name : !0).filter((u) => Je(u.mark.attrs, t, { strict: !1 })).reduce((u, d) => u + d.to - d.from, 0), c = l.filter((u) => s ? u.mark.type !== s && u.mark.type.excludes(s) : !0).reduce((u, d) => u + d.to - d.from, 0);
  return (a > 0 ? a + c : a) >= o;
}
function Kt(r, e) {
  const { nodeExtensions: t } = di(e), n = t.find((o) => o.name === r);
  if (!n)
    return !1;
  const i = {
    name: n.name,
    options: n.options,
    storage: n.storage
  }, s = V(J(n, "group", i));
  return typeof s != "string" ? !1 : s.split(" ").includes("list");
}
function qn(r, { checkChildren: e = !0, ignoreWhitespace: t = !1 } = {}) {
  var n;
  if (t) {
    if (r.type.name === "hardBreak")
      return !0;
    if (r.isText)
      return /^\s*$/m.test((n = r.text) !== null && n !== void 0 ? n : "");
  }
  if (r.isText)
    return !r.text;
  if (r.isAtom || r.isLeaf)
    return !1;
  if (r.content.childCount === 0)
    return !0;
  if (e) {
    let i = !0;
    return r.content.forEach((s) => {
      i !== !1 && (qn(s, { ignoreWhitespace: t, checkChildren: e }) || (i = !1));
    }), i;
  }
  return !1;
}
function ys(r, e, t) {
  var n;
  const { selection: i } = e;
  let s = null;
  if (Jn(i) && (s = i.$cursor), s) {
    const l = (n = r.storedMarks) !== null && n !== void 0 ? n : s.marks();
    return !!t.isInSet(l) || !l.some((a) => a.type.excludes(t));
  }
  const { ranges: o } = i;
  return o.some(({ $from: l, $to: a }) => {
    let c = l.depth === 0 ? r.doc.inlineContent && r.doc.type.allowsMarkType(t) : !1;
    return r.doc.nodesBetween(l.pos, a.pos, (f, u, d) => {
      if (c)
        return !1;
      if (f.isInline) {
        const h = !d || d.type.allowsMarkType(t), g = !!t.isInSet(f.marks) || !f.marks.some((p) => p.type.excludes(t));
        c = h && g;
      }
      return !c;
    }), c;
  });
}
const xs = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  const { selection: s } = t, { empty: o, ranges: l } = s, a = G(r, n.schema);
  if (i)
    if (o) {
      const c = ds(n, a);
      t.addStoredMark(a.create({
        ...c,
        ...e
      }));
    } else
      l.forEach((c) => {
        const f = c.$from.pos, u = c.$to.pos;
        n.doc.nodesBetween(f, u, (d, h) => {
          const g = Math.max(h, f), p = Math.min(h + d.nodeSize, u);
          d.marks.find((w) => w.type === a) ? d.marks.forEach((w) => {
            a === w.type && t.addMark(g, p, a.create({
              ...w.attrs,
              ...e
            }));
          }) : t.addMark(g, p, a.create(e));
        });
      });
  return ys(n, t, a);
}, ws = (r, e) => ({ tr: t }) => (t.setMeta(r, e), !0), ks = (r, e = {}) => ({ state: t, dispatch: n, chain: i }) => {
  const s = z(r, t.schema);
  let o;
  return t.selection.$anchor.sameParent(t.selection.$head) && (o = t.selection.$anchor.parent.attrs), s.isTextblock ? i().command(({ commands: l }) => Vt(s, { ...o, ...e })(t) ? !0 : l.clearNodes()).command(({ state: l }) => Vt(s, { ...o, ...e })(l, n)).run() : (console.warn('[tiptap warn]: Currently "setNode()" only supports text block nodes.'), !1);
}, bs = (r) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: n } = e, i = X(r, 0, n.content.size), s = S.create(n, i);
    e.setSelection(s);
  }
  return !0;
}, Ss = (r) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: n } = e, { from: i, to: s } = typeof r == "number" ? { from: r, to: r } : r, o = C.atStart(n).from, l = C.atEnd(n).to, a = X(i, o, l), c = X(s, o, l), f = C.create(n, a, c);
    e.setSelection(f);
  }
  return !0;
}, vs = (r) => ({ state: e, dispatch: t }) => {
  const n = z(r, e.schema);
  return ui(n)(e, t);
};
function Zt(r, e) {
  const t = r.storedMarks || r.selection.$to.parentOffset && r.selection.$from.marks();
  if (t) {
    const n = t.filter((i) => e == null ? void 0 : e.includes(i.type.name));
    r.tr.ensureMarks(n);
  }
}
const Cs = ({ keepMarks: r = !0 } = {}) => ({ tr: e, state: t, dispatch: n, editor: i }) => {
  const { selection: s, doc: o } = e, { $from: l, $to: a } = s, c = i.extensionManager.attributes, f = ze(c, l.node().type.name, l.node().attrs);
  if (s instanceof S && s.node.isBlock)
    return !l.parentOffset || !q(o, l.pos) ? !1 : (n && (r && Zt(t, i.extensionManager.splittableMarks), e.split(l.pos).scrollIntoView()), !0);
  if (!l.parent.isBlock)
    return !1;
  const u = a.parentOffset === a.parent.content.size, d = l.depth === 0 ? void 0 : ps(l.node(-1).contentMatchAt(l.indexAfter(-1)));
  let h = u && d ? [
    {
      type: d,
      attrs: f
    }
  ] : void 0, g = q(e.doc, e.mapping.map(l.pos), 1, h);
  if (!h && !g && q(e.doc, e.mapping.map(l.pos), 1, d ? [{ type: d }] : void 0) && (g = !0, h = d ? [
    {
      type: d,
      attrs: f
    }
  ] : void 0), n) {
    if (g && (s instanceof C && e.deleteSelection(), e.split(e.mapping.map(l.pos), 1, h), d && !u && !l.parentOffset && l.parent.type !== d)) {
      const p = e.mapping.map(l.before()), m = e.doc.resolve(p);
      l.node(-1).canReplaceWith(m.index(), m.index() + 1, d) && e.setNodeMarkup(e.mapping.map(l.before()), d);
    }
    r && Zt(t, i.extensionManager.splittableMarks), e.scrollIntoView();
  }
  return g;
}, Es = (r, e = {}) => ({ tr: t, state: n, dispatch: i, editor: s }) => {
  var o;
  const l = z(r, n.schema), { $from: a, $to: c } = n.selection, f = n.selection.node;
  if (f && f.isBlock || a.depth < 2 || !a.sameParent(c))
    return !1;
  const u = a.node(-1);
  if (u.type !== l)
    return !1;
  const d = s.extensionManager.attributes;
  if (a.parent.content.size === 0 && a.node(-1).childCount === a.indexAfter(-1)) {
    if (a.depth === 2 || a.node(-3).type !== l || a.index(-2) !== a.node(-2).childCount - 1)
      return !1;
    if (i) {
      let w = y.empty;
      const O = a.index(-1) ? 1 : a.index(-2) ? 2 : 3;
      for (let L = a.depth - O; L >= a.depth - 3; L -= 1)
        w = y.from(a.node(L).copy(w));
      const T = a.indexAfter(-1) < a.node(-2).childCount ? 1 : a.indexAfter(-2) < a.node(-3).childCount ? 2 : 3, v = {
        ...ze(d, a.node().type.name, a.node().attrs),
        ...e
      }, B = ((o = l.contentMatch.defaultType) === null || o === void 0 ? void 0 : o.createAndFill(v)) || void 0;
      w = w.append(y.from(l.createAndFill(null, B) || void 0));
      const R = a.before(a.depth - (O - 1));
      t.replace(R, a.after(-T), new x(w, 4 - O, 0));
      let I = -1;
      t.doc.nodesBetween(R, t.doc.content.size, (L, Ee) => {
        if (I > -1)
          return !1;
        L.isTextblock && L.content.size === 0 && (I = Ee + 1);
      }), I > -1 && t.setSelection(C.near(t.doc.resolve(I))), t.scrollIntoView();
    }
    return !0;
  }
  const h = c.pos === a.end() ? u.contentMatchAt(0).defaultType : null, g = {
    ...ze(d, u.type.name, u.attrs),
    ...e
  }, p = {
    ...ze(d, a.node().type.name, a.node().attrs),
    ...e
  };
  t.delete(a.pos, c.pos);
  const m = h ? [
    { type: l, attrs: g },
    { type: h, attrs: p }
  ] : [{ type: l, attrs: g }];
  if (!q(t.doc, a.pos, 2))
    return !1;
  if (i) {
    const { selection: w, storedMarks: O } = n, { splittableMarks: T } = s.extensionManager, v = O || w.$to.parentOffset && w.$from.marks();
    if (t.split(a.pos, 2, m).scrollIntoView(), !v || !i)
      return !0;
    const B = v.filter((R) => T.includes(R.type.name));
    t.ensureMarks(B);
  }
  return !0;
}, nt = (r, e) => {
  const t = St((o) => o.type === e)(r.selection);
  if (!t)
    return !0;
  const n = r.doc.resolve(Math.max(0, t.pos - 1)).before(t.depth);
  if (n === void 0)
    return !0;
  const i = r.doc.nodeAt(n);
  return t.node.type === (i == null ? void 0 : i.type) && ne(r.doc, t.pos) && r.join(t.pos), !0;
}, rt = (r, e) => {
  const t = St((o) => o.type === e)(r.selection);
  if (!t)
    return !0;
  const n = r.doc.resolve(t.start).after(t.depth);
  if (n === void 0)
    return !0;
  const i = r.doc.nodeAt(n);
  return t.node.type === (i == null ? void 0 : i.type) && ne(r.doc, n) && r.join(n), !0;
}, As = (r, e, t, n = {}) => ({ editor: i, tr: s, state: o, dispatch: l, chain: a, commands: c, can: f }) => {
  const { extensions: u, splittableMarks: d } = i.extensionManager, h = z(r, o.schema), g = z(e, o.schema), { selection: p, storedMarks: m } = o, { $from: w, $to: O } = p, T = w.blockRange(O), v = m || p.$to.parentOffset && p.$from.marks();
  if (!T)
    return !1;
  const B = St((R) => Kt(R.type.name, u))(p);
  if (T.depth >= 1 && B && T.depth - B.depth <= 1) {
    if (B.node.type === h)
      return c.liftListItem(g);
    if (Kt(B.node.type.name, u) && h.validContent(B.node.content) && l)
      return a().command(() => (s.setNodeMarkup(B.pos, h), !0)).command(() => nt(s, h)).command(() => rt(s, h)).run();
  }
  return !t || !v || !l ? a().command(() => f().wrapInList(h, n) ? !0 : c.clearNodes()).wrapInList(h, n).command(() => nt(s, h)).command(() => rt(s, h)).run() : a().command(() => {
    const R = f().wrapInList(h, n), I = v.filter((L) => d.includes(L.type.name));
    return s.ensureMarks(I), R ? !0 : c.clearNodes();
  }).wrapInList(h, n).command(() => nt(s, h)).command(() => rt(s, h)).run();
}, Ms = (r, e = {}, t = {}) => ({ state: n, commands: i }) => {
  const { extendEmptyMarkRange: s = !1 } = t, o = G(r, n.schema);
  return gs(n, o, e) ? i.unsetMark(o, { extendEmptyMarkRange: s }) : i.setMark(o, e);
}, Ts = (r, e, t = {}) => ({ state: n, commands: i }) => {
  const s = z(r, n.schema), o = z(e, n.schema), l = bt(n, s, t);
  let a;
  return n.selection.$anchor.sameParent(n.selection.$head) && (a = n.selection.$anchor.parent.attrs), l ? i.setNode(o, a) : i.setNode(s, { ...a, ...t });
}, Is = (r, e = {}) => ({ state: t, commands: n }) => {
  const i = z(r, t.schema);
  return bt(t, i, e) ? n.lift(i) : n.wrapIn(i, e);
}, Os = () => ({ state: r, dispatch: e }) => {
  const t = r.plugins;
  for (let n = 0; n < t.length; n += 1) {
    const i = t[n];
    let s;
    if (i.spec.isInputRules && (s = i.getState(r))) {
      if (e) {
        const o = r.tr, l = s.transform;
        for (let a = l.steps.length - 1; a >= 0; a -= 1)
          o.step(l.steps[a].invert(l.docs[a]));
        if (s.text) {
          const a = o.doc.resolve(s.from).marks();
          o.replaceWith(s.from, s.to, r.schema.text(s.text, a));
        } else
          o.delete(s.from, s.to);
      }
      return !0;
    }
  }
  return !1;
}, Ns = () => ({ tr: r, dispatch: e }) => {
  const { selection: t } = r, { empty: n, ranges: i } = t;
  return n || e && i.forEach((s) => {
    r.removeMark(s.$from.pos, s.$to.pos);
  }), !0;
}, Rs = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  var s;
  const { extendEmptyMarkRange: o = !1 } = e, { selection: l } = t, a = G(r, n.schema), { $from: c, empty: f, ranges: u } = l;
  if (!i)
    return !0;
  if (f && o) {
    let { from: d, to: h } = l;
    const g = (s = c.marks().find((m) => m.type === a)) === null || s === void 0 ? void 0 : s.attrs, p = jn(c, a, g);
    p && (d = p.from, h = p.to), t.removeMark(d, h, a);
  } else
    u.forEach((d) => {
      t.removeMark(d.$from.pos, d.$to.pos, a);
    });
  return t.removeStoredMark(a), !0;
}, zs = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  let s = null, o = null;
  const l = Vn(typeof r == "string" ? r : r.name, n.schema);
  return l ? (l === "node" && (s = z(r, n.schema)), l === "mark" && (o = G(r, n.schema)), i && t.selection.ranges.forEach((a) => {
    const c = a.$from.pos, f = a.$to.pos;
    let u, d, h, g;
    t.selection.empty ? n.doc.nodesBetween(c, f, (p, m) => {
      s && s === p.type && (h = Math.max(m, c), g = Math.min(m + p.nodeSize, f), u = m, d = p);
    }) : n.doc.nodesBetween(c, f, (p, m) => {
      m < c && s && s === p.type && (h = Math.max(m, c), g = Math.min(m + p.nodeSize, f), u = m, d = p), m >= c && m <= f && (s && s === p.type && t.setNodeMarkup(m, void 0, {
        ...p.attrs,
        ...e
      }), o && p.marks.length && p.marks.forEach((w) => {
        if (o === w.type) {
          const O = Math.max(m, c), T = Math.min(m + p.nodeSize, f);
          t.addMark(O, T, o.create({
            ...w.attrs,
            ...e
          }));
        }
      }));
    }), d && (u !== void 0 && t.setNodeMarkup(u, void 0, {
      ...d.attrs,
      ...e
    }), o && d.marks.length && d.marks.forEach((p) => {
      o === p.type && t.addMark(h, g, o.create({
        ...p.attrs,
        ...e
      }));
    }));
  }), !0) : !1;
}, Bs = (r, e = {}) => ({ state: t, dispatch: n }) => {
  const i = z(r, t.schema);
  return ii(i, e)(t, n);
}, Fs = (r, e = {}) => ({ state: t, dispatch: n }) => {
  const i = z(r, t.schema);
  return si(i, e)(t, n);
};
var Ps = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  blur: ki,
  clearContent: bi,
  clearNodes: Si,
  command: vi,
  createParagraphNear: Ci,
  cut: Ei,
  deleteCurrentNode: Ai,
  deleteNode: Mi,
  deleteRange: Ti,
  deleteSelection: Ii,
  enter: Oi,
  exitCode: Ni,
  extendMarkRange: Ri,
  first: zi,
  focus: Pi,
  forEach: Di,
  insertContent: $i,
  insertContentAt: Ji,
  joinBackward: Vi,
  joinDown: Ui,
  joinForward: qi,
  joinItemBackward: Hi,
  joinItemForward: Gi,
  joinTextblockBackward: Ki,
  joinTextblockForward: Zi,
  joinUp: Wi,
  keyboardShortcut: Yi,
  lift: Qi,
  liftEmptyBlock: _i,
  liftListItem: es,
  newlineInCode: ts,
  resetAttributes: ns,
  scrollIntoView: rs,
  selectAll: is,
  selectNodeBackward: ss,
  selectNodeForward: ls,
  selectParentNode: as,
  selectTextblockEnd: cs,
  selectTextblockStart: fs,
  setContent: hs,
  setMark: xs,
  setMeta: ws,
  setNode: ks,
  setNodeSelection: bs,
  setTextSelection: Ss,
  sinkListItem: vs,
  splitBlock: Cs,
  splitListItem: Es,
  toggleList: As,
  toggleMark: Ms,
  toggleNode: Ts,
  toggleWrap: Is,
  undoInputRule: Os,
  unsetAllMarks: Ns,
  unsetMark: Rs,
  updateAttributes: zs,
  wrapIn: Bs,
  wrapInList: Fs
});
W.create({
  name: "commands",
  addCommands() {
    return {
      ...Ps
    };
  }
});
W.create({
  name: "drop",
  addProseMirrorPlugins() {
    return [
      new re({
        key: new ie("tiptapDrop"),
        props: {
          handleDrop: (r, e, t, n) => {
            this.editor.emit("drop", {
              editor: this.editor,
              event: e,
              slice: t,
              moved: n
            });
          }
        }
      })
    ];
  }
});
W.create({
  name: "editable",
  addProseMirrorPlugins() {
    return [
      new re({
        key: new ie("editable"),
        props: {
          editable: () => this.editor.options.editable
        }
      })
    ];
  }
});
const Ds = new ie("focusEvents");
W.create({
  name: "focusEvents",
  addProseMirrorPlugins() {
    const { editor: r } = this;
    return [
      new re({
        key: Ds,
        props: {
          handleDOMEvents: {
            focus: (e, t) => {
              r.isFocused = !0;
              const n = r.state.tr.setMeta("focus", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(n), !1;
            },
            blur: (e, t) => {
              r.isFocused = !1;
              const n = r.state.tr.setMeta("blur", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(n), !1;
            }
          }
        }
      })
    ];
  }
});
W.create({
  name: "keymap",
  addKeyboardShortcuts() {
    const r = () => this.editor.commands.first(({ commands: o }) => [
      () => o.undoInputRule(),
      // maybe convert first text block node to default node
      () => o.command(({ tr: l }) => {
        const { selection: a, doc: c } = l, { empty: f, $anchor: u } = a, { pos: d, parent: h } = u, g = u.parent.isTextblock && d > 0 ? l.doc.resolve(d - 1) : u, p = g.parent.type.spec.isolating, m = u.pos - u.parentOffset, w = p && g.parent.childCount === 1 ? m === u.pos : k.atStart(c).from === d;
        return !f || !h.type.isTextblock || h.textContent.length || !w || w && u.parent.type.name === "paragraph" ? !1 : o.clearNodes();
      }),
      () => o.deleteSelection(),
      () => o.joinBackward(),
      () => o.selectNodeBackward()
    ]), e = () => this.editor.commands.first(({ commands: o }) => [
      () => o.deleteSelection(),
      () => o.deleteCurrentNode(),
      () => o.joinForward(),
      () => o.selectNodeForward()
    ]), n = {
      Enter: () => this.editor.commands.first(({ commands: o }) => [
        () => o.newlineInCode(),
        () => o.createParagraphNear(),
        () => o.liftEmptyBlock(),
        () => o.splitBlock()
      ]),
      "Mod-Enter": () => this.editor.commands.exitCode(),
      Backspace: r,
      "Mod-Backspace": r,
      "Shift-Backspace": r,
      Delete: e,
      "Mod-Delete": e,
      "Mod-a": () => this.editor.commands.selectAll()
    }, i = {
      ...n
    }, s = {
      ...n,
      "Ctrl-h": r,
      "Alt-Backspace": r,
      "Ctrl-d": e,
      "Ctrl-Alt-Backspace": e,
      "Alt-Delete": e,
      "Alt-d": e,
      "Ctrl-a": () => this.editor.commands.selectTextblockStart(),
      "Ctrl-e": () => this.editor.commands.selectTextblockEnd()
    };
    return We() || Un() ? s : i;
  },
  addProseMirrorPlugins() {
    return [
      // With this plugin we check if the whole document was selected and deleted.
      // In this case we will additionally call `clearNodes()` to convert e.g. a heading
      // to a paragraph if necessary.
      // This is an alternative to ProseMirror's `AllSelection`, which doesn’t work well
      // with many other commands.
      new re({
        key: new ie("clearDocument"),
        appendTransaction: (r, e, t) => {
          if (r.some((p) => p.getMeta("composition")))
            return;
          const n = r.some((p) => p.docChanged) && !e.doc.eq(t.doc), i = r.some((p) => p.getMeta("preventClearDocument"));
          if (!n || i)
            return;
          const { empty: s, from: o, to: l } = e.selection, a = k.atStart(e.doc).from, c = k.atEnd(e.doc).to;
          if (s || !(o === a && l === c) || !qn(t.doc))
            return;
          const d = t.tr, h = $n({
            state: t,
            transaction: d
          }), { commands: g } = new hi({
            editor: this.editor,
            state: h
          });
          if (g.clearNodes(), !!d.steps.length)
            return d;
        }
      })
    ];
  }
});
W.create({
  name: "paste",
  addProseMirrorPlugins() {
    return [
      new re({
        key: new ie("tiptapPaste"),
        props: {
          handlePaste: (r, e, t) => {
            this.editor.emit("paste", {
              editor: this.editor,
              event: e,
              slice: t
            });
          }
        }
      })
    ];
  }
});
W.create({
  name: "tabindex",
  addProseMirrorPlugins() {
    return [
      new re({
        key: new ie("tabindex"),
        props: {
          attributes: () => this.editor.isEditable ? { tabindex: "0" } : {}
        }
      })
    ];
  }
});
class Ue {
  constructor(e = {}) {
    this.type = "node", this.name = "node", this.parent = null, this.child = null, this.config = {
      name: this.name,
      defaultOptions: {}
    }, this.config = {
      ...this.config,
      ...e
    }, this.name = this.config.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${this.name}".`), this.options = this.config.defaultOptions, this.config.addOptions && (this.options = V(J(this, "addOptions", {
      name: this.name
    }))), this.storage = V(J(this, "addStorage", {
      name: this.name,
      options: this.options
    })) || {};
  }
  static create(e = {}) {
    return new Ue(e);
  }
  configure(e = {}) {
    const t = this.extend({
      ...this.config,
      addOptions: () => kt(this.options, e)
    });
    return t.name = this.name, t.parent = this.parent, t;
  }
  extend(e = {}) {
    const t = new Ue(e);
    return t.parent = this, this.child = t, t.name = e.name ? e.name : t.parent.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${t.name}".`), t.options = V(J(t, "addOptions", {
      name: t.name
    })), t.storage = V(J(t, "addStorage", {
      name: t.name,
      options: t.options
    })), t;
  }
}
const Ve = (r) => Hn.t(r, { ns: ce });
function $s(r) {
  const e = Ce(r), t = U(r.label || Ve("block.title")), n = e.poster ? `<img src="${U(e.poster)}" alt="" style="display:block;width:100%;height:auto;min-height:60px;object-fit:cover;background:#1b1c22" onerror="this.style.display='none'">` : "", i = e.src ? U(e.src) : U(Ve("block.noScene"));
  return `<div style="position:relative;border:1px solid rgba(127,127,127,.35);border-radius:8px;overflow:hidden;background:#111216;color:#e8e8ee;font:13px/1.4 system-ui,sans-serif">${n}<div style="display:flex;gap:8px;align-items:center;padding:8px 10px"><strong>&#9651; ${t}</strong><span style="opacity:.7;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${i}</span></div></div>`;
}
function Ls(r, e) {
  const t = Ce(e);
  if (!t.src || !t.runtime) return;
  const n = r.ownerDocument;
  if (!n.querySelector(`script[data-agent3d-runtime="${CSS.escape(t.runtime)}"]`)) {
    const o = n.createElement("script");
    o.type = "module", o.src = t.runtime, o.setAttribute("data-agent3d-runtime", t.runtime), n.head.appendChild(o);
  }
  const i = n.createElement("agent3d-scene");
  i.setAttribute("src", t.src), t.poster && i.setAttribute("poster", t.poster);
  const s = qe(e.aspect);
  s && i.setAttribute("aspect", s), i.setAttribute("aria-label", e.label || "3D scene"), i.style.cssText = "display:block;width:100%;border-radius:8px;overflow:hidden", r.replaceChildren(i);
}
const js = Ue.create({
  name: de,
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addAttributes() {
    return {
      // ONE attribute holding every field, stored base64 in data-attrs.
      attrs: {
        default: le,
        parseHTML: (r) => Yt(r.getAttribute("data-attrs")),
        renderHTML: (r) => ({ "data-attrs": nr(r.attrs ?? le) })
      }
    };
  },
  parseHTML() {
    return [{ tag: `div[data-cms-block="${st}"]` }];
  },
  renderHTML({ HTMLAttributes: r }) {
    return ["div", pi(r, { "data-cms-block": st })];
  },
  addNodeView() {
    return ({ node: r }) => {
      const e = document.createElement("div");
      e.contentEditable = "false";
      let t = r.attrs.attrs;
      const n = () => {
        var s;
        e.innerHTML = $s(t);
        const i = Ce(t);
        if (i.src && i.runtime) {
          const o = document.createElement("button");
          o.type = "button", o.className = "btn-secondary", o.style.cssText = "position:absolute;top:8px;right:8px", o.textContent = Ve("block.play"), o.addEventListener("click", (l) => {
            l.preventDefault(), l.stopPropagation(), Ls(e, t);
          }), (s = e.firstElementChild) == null || s.appendChild(o);
        }
      };
      return n(), {
        dom: e,
        update(i) {
          return i.type.name !== de ? !1 : (t = i.attrs.attrs, n(), !0);
        },
        stopEvent: (i) => i.target instanceof HTMLButtonElement,
        ignoreMutation: () => !0
      };
    };
  }
});
function Js({ className: r }) {
  return /* @__PURE__ */ j("svg", { viewBox: "0 0 24 24", width: 16, height: 16, fill: "none", stroke: "currentColor", strokeWidth: 2, className: r, "aria-hidden": "true", children: [
    /* @__PURE__ */ E("path", { d: "M12 2 3 7v10l9 5 9-5V7l-9-5Z" }),
    /* @__PURE__ */ E("path", { d: "m3 7 9 5 9-5M12 12v10" })
  ] });
}
function Ws() {
  var t;
  const { settings: r } = Gn(), e = ((t = r.pluginConfigs) == null ? void 0 : t[ce]) ?? {};
  return { ...Be, ...e, scenes: Array.isArray(e.scenes) ? e.scenes : [] };
}
function Us({ attrs: r, updateAttrs: e }) {
  var f;
  const { t } = Xt(ce), n = Ws(), i = { ...le, ...r.attrs ?? {} }, [s, o] = Ne(i);
  it(() => o(i), [i.src, i.poster, i.runtime, i.label, i.caption, i.aspect]);
  const l = (u) => e({ attrs: { ...i, ...u } }), a = (u, d) => /* @__PURE__ */ j("label", { className: "block space-y-1", children: [
    /* @__PURE__ */ E("span", { className: "label", children: t(`block.${u}`) }),
    /* @__PURE__ */ E(
      "input",
      {
        className: "input w-full",
        value: s[u],
        placeholder: d,
        onChange: (h) => o({ ...s, [u]: h.target.value }),
        onBlur: () => s[u] !== i[u] && l({ [u]: s[u] })
      }
    )
  ] }, u), c = Ce(s);
  return /* @__PURE__ */ j("div", { className: "space-y-3", children: [
    n.scenes.length > 0 && /* @__PURE__ */ j("label", { className: "block space-y-1", children: [
      /* @__PURE__ */ E("span", { className: "label", children: t("block.uploaded") }),
      /* @__PURE__ */ j(
        "select",
        {
          className: "input w-full",
          value: ((f = n.scenes.find((u) => u.src === i.src)) == null ? void 0 : f.name) ?? "",
          onChange: (u) => {
            const d = n.scenes.find((h) => h.name === u.target.value);
            d && l({ src: d.src, poster: d.poster, runtime: d.runtime, aspect: d.aspect ?? "", label: i.label || d.label || d.name });
          },
          children: [
            /* @__PURE__ */ E("option", { value: "", children: t("block.custom") }),
            n.scenes.map((u) => /* @__PURE__ */ E("option", { value: u.name, children: u.name }, u.name))
          ]
        }
      )
    ] }),
    a("src", "/agent3d/my-scene/scene.json"),
    a("label", t("block.labelPlaceholder")),
    a("caption"),
    a("aspect", "16:9"),
    a("poster", c.poster),
    a("runtime", c.runtime),
    /* @__PURE__ */ E("p", { className: "text-xs text-surface-500", children: t("block.help") })
  ] });
}
const Vs = {
  id: st,
  // The Tiptap node name: required for ids containing "/".
  nodeName: de,
  titleKey: "block.title",
  namespace: ce,
  icon: Js,
  category: "embed",
  extensions: [js],
  // Asks for the scene URL (prefilled with the upload folder); the Block tab
  // (opened on insert) also lists the scenes uploaded in the settings page.
  insert: (r) => {
    let e = "/agent3d/my-scene/scene.json";
    try {
      const t = typeof window < "u" && typeof window.prompt == "function" ? window.prompt(Ve("block.prompt"), e) : null;
      t && t.trim() && (e = t.trim());
    } catch {
    }
    return r.insertContent({ type: de, attrs: { attrs: { ...le, src: e, label: "3D scene" } } }).run();
  },
  isActive: (r) => r.isActive(de),
  inspector: Us,
  attrsSchema: {
    src: { description: "URL of the exported scene.json: a root-absolute site path such as /agent3d/<name>/scene.json (as uploaded by the settings page), a relative path, or an https URL.", format: "url" },
    poster: { description: "Poster image URL shown before the first frame and without WebGL. Empty = poster.webp next to scene.json.", format: "url" },
    runtime: { description: "URL of agent3d-runtime.js. Empty = ../agent3d-runtime/agent3d-runtime.js from the scene folder (the embed export layout).", format: "url" },
    label: { description: "Accessible label: one sentence describing the scene (read by screen readers)." },
    caption: { description: "Optional caption shown under the scene (plain text)." },
    aspect: { description: `Aspect ratio "W:H" (e.g. 4:1, 16:9) reserved before the scene loads, so the page does not jump. Empty = the scene's target.aspect once loaded (set automatically for uploaded scenes).` }
  }
}, qs = /\.(json|js|mjs|html|txt|svg|gltf|css)$/i;
function Hs({ config: r, save: e }) {
  const { t } = Xt(ce), n = { ...Be, ...r, scenes: Array.isArray(r.scenes) ? r.scenes : [] }, [i, s] = Ne(n.folder), [o, l] = Ne(""), [a, c] = Ne(!1), f = Qn(null);
  it(() => s(n.folder), [n.folder]), it(() => {
    var h;
    (h = f.current) == null || h.setAttribute("webkitdirectory", "");
  }, []);
  async function u(h) {
    var O, T;
    if (!(h != null && h.length)) return;
    const g = (i || Be.folder).replace(/^\/+|\/+$/g, ""), p = Array.from(h).map((v) => ({ file: v, rel: fr(v.webkitRelativePath || v.name) })), m = {};
    for (const { file: v, rel: B } of p) {
      const R = (O = /^([^/]+)\/scene\.json$/.exec(B)) == null ? void 0 : O[1];
      R && (m[R] = rr(await v.text()));
    }
    const w = cr(p.map((v) => v.rel), g, m);
    if (!w.length) {
      Ke.error(t("settings.noScene"));
      return;
    }
    c(!0);
    try {
      const v = p.filter((I) => hr(I.rel));
      let B = 0;
      await Kn(async () => {
        for (const { file: I, rel: L } of v) {
          l(t("settings.uploading", { done: B, total: v.length }));
          const Ee = `${g}/${L}`;
          qs.test(L) ? await vt({ path: Ee, content: await I.text() }) : await vt({ path: Ee, content: await Zn(I), encoding: "base64" }), B++;
        }
      });
      const R = new Map(n.scenes.map((I) => [I.name, I]));
      for (const I of w) R.set(I.name, { ...I, label: ((T = R.get(I.name)) == null ? void 0 : T.label) ?? "" });
      await e({ ...n, folder: g, scenes: [...R.values()] }), l(t("settings.done", { count: w.length, files: v.length })), Ke.success(t("settings.done", { count: w.length, files: v.length }));
    } catch (v) {
      l(""), Ke.error(`${t("settings.failed")} ${v.message}`);
    } finally {
      c(!1), f.current && (f.current.value = "");
    }
  }
  async function d(h) {
    await e({ ...n, scenes: n.scenes.filter((g) => g.name !== h) });
  }
  return /* @__PURE__ */ j("form", { "data-form-type": "other", className: "max-w-2xl space-y-4", onSubmit: (h) => h.preventDefault(), children: [
    /* @__PURE__ */ E("p", { className: "text-sm text-surface-500", children: t("settings.intro") }),
    /* @__PURE__ */ j("label", { className: "block space-y-1", children: [
      /* @__PURE__ */ E("span", { className: "label", children: t("settings.folder") }),
      /* @__PURE__ */ E("input", { className: "input w-full", value: i, onChange: (h) => s(h.target.value), onBlur: () => i !== n.folder && e({ ...n, folder: i }) })
    ] }),
    /* @__PURE__ */ j("label", { className: "block space-y-1", children: [
      /* @__PURE__ */ E("span", { className: "label", children: t("settings.pick") }),
      /* @__PURE__ */ E("input", { ref: f, type: "file", multiple: !0, disabled: a, className: "input w-full", onChange: (h) => u(h.target.files) })
    ] }),
    /* @__PURE__ */ E("p", { className: "text-sm", "aria-live": "polite", children: o }),
    /* @__PURE__ */ j("div", { className: "card p-4 space-y-2", children: [
      /* @__PURE__ */ E("span", { className: "font-medium", children: t("settings.scenes") }),
      n.scenes.length === 0 ? /* @__PURE__ */ E("p", { className: "text-sm text-surface-500", children: t("settings.empty") }) : n.scenes.map((h) => /* @__PURE__ */ j("div", { className: "flex items-center justify-between gap-2", children: [
        /* @__PURE__ */ j("span", { className: "text-sm", children: [
          /* @__PURE__ */ E("strong", { children: h.name }),
          " ",
          /* @__PURE__ */ E("code", { style: { opacity: 0.7 }, children: h.src })
        ] }),
        /* @__PURE__ */ E("button", { type: "button", className: "btn-ghost", onClick: () => d(h.name), children: /* @__PURE__ */ E("span", { children: t("settings.forget") }) })
      ] }, h.name))
    ] }),
    /* @__PURE__ */ E("p", { className: "text-xs text-surface-500", children: t("settings.regenerate") })
  ] });
}
const Gs = {
  folder: { description: "Site folder (no leading slash) where the settings page uploads Agent3D export folders. Default: agent3d." },
  scenes: { description: "Scenes uploaded through the settings page (name, src, poster, runtime, label). Managed by the plugin — don't set.", format: "array of objects" }
}, Qs = {
  id: ce,
  name: "Agent3D scene",
  version: "1.1.0",
  description: "Embed 3D scenes made with Agent3D (banners, heroes, characters, product showcases, mini games) in posts and pages.",
  author: "fleox",
  readme: _n,
  i18n: er,
  settings: { navLabelKey: "settings.navLabel", defaultConfig: Be, component: Hs, schema: Gs },
  register(r) {
    r.registerBlock(Vs), r.addFilter("post.html.body", (e) => {
      var n;
      if (!e.includes('data-cms-block="agent3d-scene/scene"')) return e;
      const t = Xn();
      return ar(e, Yn((n = t == null ? void 0 : t.settings) == null ? void 0 : n.baseUrl));
    });
  }
};
export {
  Qs as default
};
